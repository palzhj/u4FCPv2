#!/usr/bin/python
# This is tcal6416.py
# TI TCAL6416 16-bit translating I2C/SMBus I/O expander driver
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
# based on TCAL6416 datasheet (TI SCPS276)

from ..bus.i2c import i2c

# Debug switches, independent of each other:
#   DEBUG     = 1 -> print high-level per-operation info
#   DEBUG_LOW_LEVEL = 1 -> print low-level register/bus transactions
# Set either to 0 to silence that level only.
DEBUG     = 0
DEBUG_LOW_LEVEL = 0


def _debug(msg):
    """Print a high-level debug message when DEBUG is enabled."""
    if DEBUG:
        print("[tcal6416] " + msg)


def _debug_low_level(msg):
    """Print a low-level debug message when DEBUG_LOW_LEVEL is enabled."""
    if DEBUG_LOW_LEVEL:
        print("[tcal6416-low-level] " + msg)


# ---------------------------------------------------------------------------
# Device address (datasheet Figure 7-7 and Table 7-3)
#
#   7-bit target address = 0100 000 AD, where AD is the hardware address pin:
#     AD = L -> 0x20       AD = H -> 0x21
#   The hardware on this board is strapped with AD = L (default 0x20); the
#   8-bit write byte on the bus is then 0x40, read byte 0x41.
# ---------------------------------------------------------------------------
TCAL6416_ADDR_DEFAULT = 0b010_0000  # 7-bit address 0x20, AD = L


def addr7_to_addr8(addr7):
    """Convert a 7-bit target address to the 8-bit address byte sent on the
    bus with the R/W bit cleared (0x40 for TCAL6416 at 0x20)."""
    return ((addr7 & 0x7F) << 1) & 0xFE


# ---------------------------------------------------------------------------
# Register map (datasheet Table 7-4 "Command Byte")
#   Registers come in pairs: register N holds port-0 data, register N+1 holds
#   port-1 data. Command byte selects which register is accessed next.
# ---------------------------------------------------------------------------
REG_INPUT_PORT_0   = 0x00  # Input Port 0, read only, P07..P00
REG_INPUT_PORT_1   = 0x01  # Input Port 1, read only, P17..P10
REG_OUTPUT_PORT_0  = 0x02  # Output Port 0, read/write, default 0xFF
REG_OUTPUT_PORT_1  = 0x03  # Output Port 1, read/write, default 0xFF
REG_POLARITY_0     = 0x04  # Polarity inversion 0, read/write, default 0x00
REG_POLARITY_1     = 0x05  # Polarity inversion 1, read/write, default 0x00
REG_CONFIG_0       = 0x06  # Configuration 0, read/write, default 0xFF (all inputs)
REG_CONFIG_1       = 0x07  # Configuration 1, read/write, default 0xFF (all inputs)

# Agile I/O (extended) registers, 0x40..0x4F
REG_OUTPUT_DRIVE_0 = 0x40  # Output drive strength for P03..P00 / P07..P04 area
REG_OUTPUT_DRIVE_1 = 0x41
REG_OUTPUT_DRIVE_2 = 0x42
REG_OUTPUT_DRIVE_3 = 0x43
REG_INPUT_LATCH_0  = 0x44  # Input latch register 0
REG_INPUT_LATCH_1  = 0x45  # Input latch register 1
REG_PULL_EN_0      = 0x46  # Pull-up/pull-down enable register 0
REG_PULL_EN_1      = 0x47  # Pull-up/pull-down enable register 1
REG_PULL_SEL_0     = 0x48  # Pull-up/pull-down selection register 0
REG_PULL_SEL_1     = 0x49  # Pull-up/pull-down selection register 1
REG_INT_MASK_0     = 0x4A  # Interrupt mask register 0
REG_INT_MASK_1     = 0x4B  # Interrupt mask register 1
REG_INT_STATUS_0   = 0x4C  # Interrupt status register 0, read only
REG_INT_STATUS_1   = 0x4D  # Interrupt status register 1, read only
REG_OUTPUT_CONFIG  = 0x4F  # Output port configuration (ODEN0/ODEN1)

PORT0 = 0  # port index: registers N    (P07..P00)
PORT1 = 1  # port index: registers N+1  (P17..P10)


def _reg_for(port, base_reg):
    """Return the command byte for a port: port 0 -> base, port 1 -> base+1."""
    if port not in (PORT0, PORT1):
        raise ValueError("port must be 0 or 1, got %r" % (port,))
    return base_reg + port


class tcal6416(object):
    """Class for communicating with a TCAL6416 16-bit I/O expander.

    Register access is via the I2C command byte (the register pointer), so
    every operation passes the command byte as leading data:

      * write: START -> <addr|W> -> <command byte> -> <data> -> STOP
      * read : START -> <addr|W> -> <command byte> -> RESTART ->
               <addr|R> -> <data> -> NACK -> STOP

    Configuration register bit = 1 means the pin is an input (default),
    bit = 0 means the pin is an output (datasheet 7.6.3, Table 7-8).
    """

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = TCAL6416_ADDR_DEFAULT,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create a TCAL6416 instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        i2c_addr : 7-bit target address (0x20, 0x21, default 0x20); it is
                   shifted up internally to the 8-bit bus address byte.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency.
        """
        if not (0x00 <= i2c_addr <= 0x7F):
            raise ValueError("i2c_addr must be a 7-bit address (0x00..0x7F), "
                             "got 0x%02X" % i2c_addr)
        i2c_addr = addr7_to_addr8(i2c_addr)  # 7-bit -> bus address byte
        self.i2c_addr = i2c_addr
        self.i2c = i2c(device_ip, udp_port, base_address, i2c_addr,
                       clk_freq, i2c_freq)
        _debug("init: 8-bit addr=0x%02X (7-bit 0x%02X), base=0x%08X, "
               "clk=%dMHz, i2c=%dKHz, ip=%s:%d"
               % (i2c_addr, i2c_addr >> 1, base_address, clk_freq, i2c_freq,
                  device_ip, udp_port))

    # ------------------------------------------------------------------
    # low level: raw register transactions (debug via _debug_low_level)
    # ------------------------------------------------------------------
    def _read_register(self, reg):
        """Read one register (command byte reg): returns 8-bit value."""
        value = self.i2c.readBytes(reg, 1)[0]
        _debug_low_level("read reg 0x%02X -> 0x%02X" % (reg, value))
        return value

    def _write_register(self, reg, value):
        """Write one register (command byte reg): value & 0xFF."""
        value = value & 0xFF
        _debug_low_level("write reg 0x%02X <- 0x%02X" % (reg, value))
        self.i2c.writeBytes([reg, value])
        return value

    # ------------------------------------------------------------------
    # input / output ports
    # ------------------------------------------------------------------
    def read_input(self, port = PORT0, mask = 0xFF):
        """Read the Input Port register of port (0 or 1).

        mask selects which pin bits are returned: read_input(port, 0xFF) reads
        all eight pins of the port (the default), a narrower mask isolates the
        pins of interest."""
        _debug("read_input(port %d, mask 0x%02X)" % (port, mask))
        return self._read_register(_reg_for(port, REG_INPUT_PORT_0)) & mask & 0xFF

    def read_output(self, port = PORT0):
        """Read the Output Port register of port (0 or 1)."""
        _debug("read_output(port %d)" % port)
        return self._read_register(_reg_for(port, REG_OUTPUT_PORT_0))

    def write_output(self, port, value):
        """Write the Output Port register of port (0 or 1)."""
        value = value & 0xFF
        _debug("write_output(port %d, 0x%02X)" % (port, value))
        return self._write_register(_reg_for(port, REG_OUTPUT_PORT_0), value)

    # ------------------------------------------------------------------
    # polarity inversion
    # ------------------------------------------------------------------
    def read_polarity(self, port = PORT0):
        """Read the Polarity Inversion register of port (0 or 1)."""
        return self._read_register(_reg_for(port, REG_POLARITY_0))

    def write_polarity(self, port, value):
        """Write the Polarity Inversion register of port (0 or 1)."""
        value = value & 0xFF
        _debug("write_polarity(port %d, 0x%02X)" % (port, value))
        return self._write_register(_reg_for(port, REG_POLARITY_0), value)

    # ------------------------------------------------------------------
    # direction configuration (bit = 1 -> input, bit = 0 -> output)
    # ------------------------------------------------------------------
    def read_config(self, port = PORT0):
        """Read the Configuration register of port (0 or 1):
        returned bit = 1 means the pin is an input."""
        return self._read_register(_reg_for(port, REG_CONFIG_0))

    def write_config(self, port, value):
        """Write the Configuration register of port (0 or 1):
        value bit = 1 makes the pin an input, bit = 0 an output."""
        value = value & 0xFF
        _debug("write_config(port %d, 0x%02X)" % (port, value))
        return self._write_register(_reg_for(port, REG_CONFIG_0), value)

    def set_pin_direction(self, pin, is_input):
        """Set the direction of a single pin (0..15) without touching the
        other pins. Pin 0..7 belong to port 0, pin 8..15 to port 1.

        is_input : True -> pin becomes an input (high-Z),
                   False -> pin becomes an output."""
        if not (0 <= pin <= 15):
            raise ValueError("pin must be in 0..15, got %r" % (pin,))
        port = pin >> 3
        bit  = 1 << (pin & 0x07)
        temp = self.read_config(port)
        value = temp | bit if is_input else temp & ~bit
        _debug("set_pin_direction(pin %d -> %s)" % (pin,
               "input" if is_input else "output"))
        return self._write_register(_reg_for(port, REG_CONFIG_0), value)

    # ------------------------------------------------------------------
    # interrupt (mask 0x4A/0x4B, status 0x4C/0x4D read-only)
    #   mask bit = 1 -> interrupt masked/disabled, bit = 0 -> enabled
    # ------------------------------------------------------------------
    def read_interrupt_mask(self, port = PORT0):
        """Read the Interrupt Mask register of port (0 or 1):
        bit = 1 means the pin's interrupt is masked (disabled)."""
        return self._read_register(_reg_for(port, REG_INT_MASK_0))

    def write_interrupt_mask(self, port, value):
        """Write the Interrupt Mask register of port (0 or 1):
        value bit = 1 masks (disables) the pin's interrupt, 0 enables it."""
        value = value & 0xFF
        _debug("write_interrupt_mask(port %d, 0x%02X)" % (port, value))
        return self._write_register(_reg_for(port, REG_INT_MASK_0), value)

    def enable_interrupt(self, port, mask):
        """Enable the interrupts of the pins given by mask on port (0 or 1)
        by clearing the mask bits (read-modify-write)."""
        temp = self.read_interrupt_mask(port)
        value = temp & ~(mask & 0xFF)
        _debug("enable_interrupt(port %d, mask 0x%02X)" % (port, mask))
        return self._write_register(_reg_for(port, REG_INT_MASK_0), value)

    def disable_interrupt(self, port, mask):
        """Disable (mask) the interrupts of the pins given by mask on port
        (0 or 1) by setting the mask bits (read-modify-write)."""
        temp = self.read_interrupt_mask(port)
        value = temp | (mask & 0xFF)
        _debug("disable_interrupt(port %d, mask 0x%02X)" % (port, mask))
        return self._write_register(_reg_for(port, REG_INT_MASK_0), value)

    def set_pin_interrupt(self, pin, enabled):
        """Enable (True) or disable (False) the interrupt of one pin (0..15)
        without touching the other pins."""
        if not (0 <= pin <= 15):
            raise ValueError("pin must be in 0..15, got %r" % (pin,))
        port = pin >> 3
        bit  = 1 << (pin & 0x07)
        temp = self.read_interrupt_mask(port)
        value = temp & ~bit if enabled else temp | bit
        _debug("set_pin_interrupt(pin %d -> %s)" % (pin,
               "enabled" if enabled else "disabled"))
        return self._write_register(_reg_for(port, REG_INT_MASK_0), value)

    def read_interrupt_status(self, port = PORT0):
        """Read the Interrupt Status register of port (0 or 1):
        bit = 1 means the pin is the source of an interrupt."""
        return self._read_register(_reg_for(port, REG_INT_STATUS_0))

    # ------------------------------------------------------------------
    # pull-up/pull-down (enable 0x46/0x47, selection 0x48/0x49)
    #   enable bit = 1 -> internal resistor connected (only for inputs)
    #   select bit = 1 -> pull-up, bit = 0 -> pull-down (10k, if enabled)
    # ------------------------------------------------------------------
    def read_pull_enable(self, port = PORT0):
        """Read the Pull-Up/Pull-Down Enable register of port (0 or 1):
        bit = 1 means the pin's internal resistor is enabled."""
        return self._read_register(_reg_for(port, REG_PULL_EN_0))

    def write_pull_enable(self, port, value):
        """Write the Pull-Up/Pull-Down Enable register of port (0 or 1):
        value bit = 1 connects the pin's internal resistor, 0 disconnects."""
        value = value & 0xFF
        _debug("write_pull_enable(port %d, 0x%02X)" % (port, value))
        return self._write_register(_reg_for(port, REG_PULL_EN_0), value)

    def enable_pull(self, port, mask):
        """Enable the internal pull resistors of the pins given by mask on
        port (0 or 1), keeping the other pins as-is."""
        temp = self.read_pull_enable(port)
        value = temp | (mask & 0xFF)
        _debug("enable_pull(port %d, mask 0x%02X)" % (port, mask))
        return self._write_register(_reg_for(port, REG_PULL_EN_0), value)

    def disable_pull(self, port, mask):
        """Disable the internal pull resistors of the pins given by mask on
        port (0 or 1), keeping the other pins as-is."""
        temp = self.read_pull_enable(port)
        value = temp & ~(mask & 0xFF)
        _debug("disable_pull(port %d, mask 0x%02X)" % (port, mask))
        return self._write_register(_reg_for(port, REG_PULL_EN_0), value)

    def read_pull_select(self, port = PORT0):
        """Read the Pull-Up/Pull-Down Selection register of port (0 or 1):
        bit = 1 selects a pull-up, bit = 0 a pull-down."""
        return self._read_register(_reg_for(port, REG_PULL_SEL_0))

    def write_pull_select(self, port, value):
        """Write the Pull-Up/Pull-Down Selection register of port (0 or 1):
        value bit = 1 selects a pull-up, bit = 0 a pull-down (only has
        effect while the resistor is enabled)."""
        value = value & 0xFF
        _debug("write_pull_select(port %d, 0x%02X)" % (port, value))
        return self._write_register(_reg_for(port, REG_PULL_SEL_0), value)

    def set_pin_pull(self, pin, enabled, pull_up = True):
        """Enable/disable the internal pull resistor of one pin (0..15).

        enabled : True -> connect the resistor (pin must be an input),
                  False -> disconnect it.
        pull_up : True -> pull-up, False -> pull-down (used when enabled)."""
        if not (0 <= pin <= 15):
            raise ValueError("pin must be in 0..15, got %r" % (pin,))
        port = pin >> 3
        bit  = 1 << (pin & 0x07)
        if enabled:
            temp = self.read_pull_select(port)
            select = temp | bit if pull_up else temp & ~bit
            self._write_register(_reg_for(port, REG_PULL_SEL_0), select)
        temp = self.read_pull_enable(port)
        value = temp | bit if enabled else temp & ~bit
        _debug("set_pin_pull(pin %d -> %s)" % (pin,
               ("pull-up" if pull_up else "pull-down") if enabled
               else "disabled"))
        return self._write_register(_reg_for(port, REG_PULL_EN_0), value)

    # ------------------------------------------------------------------
    # output drive strength (registers 0x40..0x43)
    #   two bits per pin: 00=0.25x, 01=0.5x, 10=0.75x, 11=1x (default)
    #   register = 0x40 + (pin >> 2); pin field at bits[(pin&3)*2+1 : (pin&3)*2]
    # ------------------------------------------------------------------
    DRIVE_0_25X = 0x0
    DRIVE_0_5X  = 0x1
    DRIVE_0_75X = 0x2
    DRIVE_1X    = 0x3

    def get_drive_strength(self, pin):
        """Return the output drive strength level (0..3) of one pin (0..15):
        0=0.25x, 1=0.5x, 2=0.75x, 3=1x (datasheet Table 7-9)."""
        if not (0 <= pin <= 15):
            raise ValueError("pin must be in 0..15, got %r" % (pin,))
        reg = REG_OUTPUT_DRIVE_0 + (pin >> 2)
        shift = (pin & 0x03) * 2
        value = self._read_register(reg)
        return (value >> shift) & 0x03

    def set_drive_strength(self, pin, level):
        """Set the output drive strength of one pin (0..15) to level 0..3
        (0=0.25x, 1=0.5x, 2=0.75x, 3=1x), keeping the other pins as-is."""
        if not (0 <= pin <= 15):
            raise ValueError("pin must be in 0..15, got %r" % (pin,))
        level = level & 0x03
        reg = REG_OUTPUT_DRIVE_0 + (pin >> 2)
        shift = (pin & 0x03) * 2
        temp = self._read_register(reg)
        value = (temp & ~(0x03 << shift)) | (level << shift)
        _debug("set_drive_strength(pin %d, level %d)" % (pin, level))
        return self._write_register(reg, value)

    def read_drive_strength(self, reg):
        """Read a whole Output Drive Strength register (0x40..0x43)."""
        if not (REG_OUTPUT_DRIVE_0 <= reg <= REG_OUTPUT_DRIVE_3):
            raise ValueError("drive-strength reg must be 0x40..0x43, got %r"
                             % (reg,))
        return self._read_register(reg)

    def write_drive_strength(self, reg, value):
        """Write a whole Output Drive Strength register (0x40..0x43)."""
        if not (REG_OUTPUT_DRIVE_0 <= reg <= REG_OUTPUT_DRIVE_3):
            raise ValueError("drive-strength reg must be 0x40..0x43, got %r"
                             % (reg,))
        value = value & 0xFF
        _debug("write_drive_strength(reg 0x%02X, 0x%02X)" % (reg, value))
        return self._write_register(reg, value)

    # ------------------------------------------------------------------
    # input latch (registers 0x44/0x45, Table 7-10)
    #   latch bit = 1 -> input pin state is latched; a state change then
    #   generates an interrupt and holds the value until the input port is
    #   read (only effective when the pin is configured as an input)
    # ------------------------------------------------------------------
    def read_input_latch(self, port = PORT0):
        """Read the Input Latch register of port (0 or 1):
        bit = 1 means the pin's input is latched."""
        return self._read_register(_reg_for(port, REG_INPUT_LATCH_0))

    def write_input_latch(self, port, value):
        """Write the Input Latch register of port (0 or 1):
        value bit = 1 latches the pin's input, 0 disables latching."""
        value = value & 0xFF
        _debug("write_input_latch(port %d, 0x%02X)" % (port, value))
        return self._write_register(_reg_for(port, REG_INPUT_LATCH_0), value)

    def enable_input_latch(self, port, mask):
        """Enable the input latch of the pins given by mask on port (0 or 1),
        keeping the other pins as-is."""
        temp = self.read_input_latch(port)
        value = temp | (mask & 0xFF)
        _debug("enable_input_latch(port %d, mask 0x%02X)" % (port, mask))
        return self._write_register(_reg_for(port, REG_INPUT_LATCH_0), value)

    def disable_input_latch(self, port, mask):
        """Disable the input latch of the pins given by mask on port (0 or 1),
        keeping the other pins as-is."""
        temp = self.read_input_latch(port)
        value = temp & ~(mask & 0xFF)
        _debug("disable_input_latch(port %d, mask 0x%02X)" % (port, mask))
        return self._write_register(_reg_for(port, REG_INPUT_LATCH_0), value)

    def set_pin_input_latch(self, pin, enabled):
        """Enable (True) or disable (False) the input latch of one pin (0..15)
        without touching the other pins."""
        if not (0 <= pin <= 15):
            raise ValueError("pin must be in 0..15, got %r" % (pin,))
        port = pin >> 3
        bit  = 1 << (pin & 0x07)
        temp = self.read_input_latch(port)
        value = temp | bit if enabled else temp & ~bit
        _debug("set_pin_input_latch(pin %d -> %s)" % (pin,
               "enabled" if enabled else "disabled"))
        return self._write_register(_reg_for(port, REG_INPUT_LATCH_0), value)

    # ------------------------------------------------------------------
    # output port configuration (push-pull vs open-drain, register 0x4F)
    # ------------------------------------------------------------------
    #   bit 0 = ODEN0 (port 0), bit 1 = ODEN1 (port 1)
    #   bit = 0 -> push-pull (both transistors active, default)
    #   bit = 1 -> open-drain (pull-up transistor disabled, only pull-down)
    #   Program this register BEFORE the Configuration register turns the pins
    #   into outputs (datasheet 7.6.3).
    # ------------------------------------------------------------------
    def read_output_config(self):
        """Read the Output Port Configuration register (0x4F):
        returns the ODEN0/ODEN1 bits of both ports."""
        return self._read_register(REG_OUTPUT_CONFIG)

    def write_output_config(self, port, open_drain):
        """Set the output stage of a whole port to push-pull (False) or
        open-drain (True), register 0x4F (ODEN0/ODEN1, datasheet 7.6.3)."""
        if port not in (PORT0, PORT1):
            raise ValueError("port must be 0 or 1, got %r" % (port,))
        temp = self._read_register(REG_OUTPUT_CONFIG)
        value = temp | (1 << port) if open_drain else temp & ~(1 << port)
        _debug("write_output_config(port %d, open_drain=%s)" % (port,
               open_drain))
        return self._write_register(REG_OUTPUT_CONFIG, value)
