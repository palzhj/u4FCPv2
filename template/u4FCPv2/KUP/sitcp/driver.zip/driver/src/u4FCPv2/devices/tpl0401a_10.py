#!/usr/bin/python
# This is tpl0401a_10.py
# TI TPL0401A-10 128-tap single-channel digital potentiometer driver
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
# based on TPL0401x-10 datasheet (TI SLIS144)

from ..bus.i2c import i2c

# Debug switches, independent of each other:
#   DEBUG     = 1 -> print high-level per-operation info
#   DEBUG_LOW_LEVEL = 1 -> print low-level register/bus transactions
# Set either to 0 to silence that level only.
DEBUG            = 0
DEBUG_LOW_LEVEL  = 0


def _debug(msg):
    """Print a high-level debug message when DEBUG is enabled."""
    if DEBUG:
        print("[tpl0401a] " + msg)


def _debug_low_level(msg):
    """Print a low-level debug message when DEBUG_LOW_LEVEL is enabled."""
    if DEBUG_LOW_LEVEL:
        print("[tpl0401a-low-level] " + msg)


# ---------------------------------------------------------------------------
# Device address (datasheet 9.6.1, orderable addendum). The device has one
# fixed address per variant, listed as the 7-bit address in the datasheet:
#   TPL0401A-10DCKR -> 0101110b = 0x2E   (8-bit write byte 0x5C)
#   TPL0401B-10DCKR -> 0111110b = 0x3E   (8-bit write byte 0x7C)
# ---------------------------------------------------------------------------
TPL0401A_ADDR_DEFAULT = 0b010_1110  # 7-bit address 0x2E (TPL0401A-10)

# wiper resistance, end-to-end
RESISTANCE_OHM = 10000.0
NUM_TAPS       = 128


def addr7_to_addr8(addr7):
    """Convert a 7-bit target address to the 8-bit address byte sent on the
    bus with the R/W bit cleared (0x5C for TPL0401A-10 at 0x2E)."""
    return ((addr7 & 0x7F) << 1) & 0xFE


# ---------------------------------------------------------------------------
# Register map (datasheet 9.6.2, Table 4)
# ---------------------------------------------------------------------------
REG_WIPER = 0x00  # wiper position register, read/write byte,
                  # power-up default 0x40 (mid-scale). Only bits [6:0]
                  # are used; the MSB (bit 7) is discarded on writes.


class tpl0401a(object):
    """Class for communicating with a TPL0401A-10 digital potentiometer.

    The TPL0401x-10 has a single wiper-position register, but every I2C
    access still carries the register-address (command) byte 0x00:

      * write: START -> <addr|W> -> <0x00> -> <wiper> -> STOP
      * read : START -> <addr|W> -> <0x00> -> RESTART ->
               <addr|R> -> <wiper> -> NACK -> STOP

    The MSB of a written wiper value is discarded, so only bits [6:0]
    (taps 0..127) are stored (datasheet 9.6.2).
    """

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = TPL0401A_ADDR_DEFAULT,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create a TPL0401A-10 instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        i2c_addr : 7-bit target address (0x2E for A-10, 0x3E for B-10,
                   default 0x2E); it is shifted up internally to the 8-bit
                   bus address byte.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency.
        """
        if not (0x00 <= i2c_addr <= 0x7F):
            raise ValueError("i2c_addr must be a 7-bit address (0x00..0x7F), "
                             "got 0x%02X" % i2c_addr)
        i2c_addr = addr7_to_addr8(i2c_addr)  # 7-bit -> bus address byte
        self.i2c_addr = i2c_addr
        self.i2c = i2c(device_ip, udp_port, base_address, i2c_addr,
                       clk_freq, i2c_freq)
        _debug("init: 8-bit addr=0x%02X (7-bit 0x%02X), base=0x%08X, "
               "clk=%dMHz, i2c=%dKHz, ip=%s:%d"
               % (i2c_addr, i2c_addr >> 1, base_address, clk_freq, i2c_freq,
                  device_ip, udp_port))

    # ------------------------------------------------------------------
    # low level: raw register transactions (debug via _debug_low_level)
    # ------------------------------------------------------------------
    def _read_wiper_raw(self):
        """Read the raw wiper-position register byte."""
        value = self.i2c.readBytes(REG_WIPER, 1)[0]
        _debug_low_level("read wiper register -> 0x%02X" % value)
        return value

    def _write_wiper_raw(self, value):
        """Write the raw wiper-position register byte (MSB discarded by
        the device)."""
        value = value & 0xFF
        _debug_low_level("write wiper register <- 0x%02X" % value)
        self.i2c.writeBytes([REG_WIPER, value])
        return value

    # ------------------------------------------------------------------
    # wiper position
    # ------------------------------------------------------------------
    def read_wiper(self):
        """Read the current wiper position (0..127)."""
        value = self._read_wiper_raw() & 0x7F
        _debug("read_wiper: %d (0x%02X)" % (value, value))
        return value

    def write_wiper(self, position):
        """Set the wiper position (0..127). Position 0 is near GND/L
        terminal, 127 near the H terminal. Returns the stored value."""
        if not (0 <= position <= 127):
            raise ValueError("wiper position must be 0..127, got %r"
                             % (position,))
        _debug("write_wiper: %d (0x%02X)" % (position, position))
        self._write_wiper_raw(position)
        return position

    # ------------------------------------------------------------------
    # resistance helpers
    # ------------------------------------------------------------------
    def read_resistance(self):
        """Compute the wiper-to-ground resistance in ohms from the current
        position: R = position/127 * 10k (ideal, 10k end-to-end)."""
        position = self.read_wiper()
        resistance = position * RESISTANCE_OHM / (NUM_TAPS - 1)
        _debug("read_resistance: position %d -> %.1f ohm"
               % (position, resistance))
        return resistance

    def write_resistance(self, resistance_ohm):
        """Set the wiper to give the requested wiper-to-ground resistance
        in ohms (0..10k). Returns the stored wiper position."""
        ratio = float(resistance_ohm) / RESISTANCE_OHM
        position = int(round(ratio * (NUM_TAPS - 1)))
        position = max(0, min(NUM_TAPS - 1, position))
        _debug("write_resistance: %.1f ohm -> position %d"
               % (resistance_ohm, position))
        self._write_wiper_raw(position)
        return position
