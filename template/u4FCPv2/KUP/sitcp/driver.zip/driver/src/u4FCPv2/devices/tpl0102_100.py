#!/usr/bin/python
# This is tpl0102_100.py
# TI TPL0102-100 two 256-tap digital potentiometers with non-volatile memory driver
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
# based on TPL0102 datasheet (TI SLIS134)

from ..bus.i2c import i2c
import time

# Debug switches, independent of each other:
#   DEBUG     = 1 -> print high-level per-operation info
#   DEBUG_LOW_LEVEL = 1 -> print low-level register/bus transactions
# Set either to 0 to silence that level only.
DEBUG            = 0
DEBUG_LOW_LEVEL  = 0


def _debug(msg):
    """Print a high-level debug message when DEBUG is enabled."""
    if DEBUG:
        print("[tpl0102] " + msg)


def _debug_low_level(msg):
    """Print a low-level debug message when DEBUG_LOW_LEVEL is enabled."""
    if DEBUG_LOW_LEVEL:
        print("[tpl0102-low-level] " + msg)


# ---------------------------------------------------------------------------
# Device address (datasheet 7.6.1). The 7-bit target address is 1010 A2 A1 A0,
# so the three address pins select one of eight addresses 0x50..0x57:
#   A2 A1 A0 = GND GND GND -> 1010 000b = 0x50
#   A2 A1 A0 = VDD GND VDD -> 1010 101b = 0x55 (this board)
#   A2 A1 A0 = VDD VDD VDD -> 1010 111b = 0x57
# ---------------------------------------------------------------------------
TPL0102_ADDR_DEFAULT = 0b1010_101  # 7-bit address 0x55, A2 = A0 = VDD, A1 = GND

# potentiometer selection
POT_A = 0
POT_B = 1

RESISTANCE_OHM  = 100000.0  # end-to-end resistance R_TOT (TPL0102-100), +/-20%
NUM_TAPS        = 256       # 256 positions, wiper code 0..255
WRITE_CYCLE_S   = 0.020     # tWC, unit: s, non-volatile write cycle time
WRITE_TIMEOUT_S = 0.100     # give up on a non-volatile write after 5 * tWC


def addr7_to_addr8(addr7):
    """Convert a 7-bit target address to the 8-bit address byte sent on the
    bus with the R/W bit cleared (0xAA for the TPL0102 at 0x55)."""
    return ((addr7 & 0x7F) << 1) & 0xFE


# ---------------------------------------------------------------------------
# Register map (datasheet 7.6.2). Registers 0x02..0x0E are general purpose
# non-volatile bytes that do not affect the potentiometers and 0x0F is
# reserved, so only the four registers below are used. The volatile and the
# non-volatile register of a potentiometer share one address; which of them an
# access reaches is selected by the VOL bit of the ACR.
# ---------------------------------------------------------------------------
REG_WIPER_A = 0x00  # WRA (volatile) / IVRA (non-volatile), factory 0x80
REG_WIPER_B = 0x01  # WRB (volatile) / IVRB (non-volatile), factory 0x80
REG_ACR     = 0x10  # Access Control Register, reset 0x40

# --- ACR bit masks (datasheet 7.6.7, reset value 0x40) ---------------------
ACR_VOL  = 0x80  # 0 = IVR accessible (a write also loads WR, reads report
                 #     the IVR); 1 = only the volatile WR is accessible
ACR_SHDN = 0x40  # 0 = shutdown mode enabled, 1 = shutdown mode disabled
ACR_WIP  = 0x20  # read only: 1 = non-volatile write in progress


def _reg_for(pot):
    """Return the wiper register address of a potentiometer."""
    if pot not in (POT_A, POT_B):
        raise ValueError("pot must be POT_A or POT_B, got %r" % (pot,))
    return REG_WIPER_A if pot == POT_A else REG_WIPER_B


class tpl0102_100(object):
    """Class for communicating with a TPL0102-100 dual digital potentiometer.

    The device holds two independent 256-tap potentiometers. Each operation is
    a single I2C transaction that starts with the register address
    (datasheet 7.5.2):

      * write: START -> <addr|W> -> <register> -> <data> -> STOP
      * read : START -> <addr|W> -> <register> -> RESTART ->
               <addr|R> -> <data> -> NACK -> STOP

    implemented with u4FCPv2.bus.i2c writeBytes()/readBytes(); the register
    address is passed as the leading data byte.

    The wiper code 0 places the wiper at the L terminal, 255 at the H terminal,
    so the wiper-to-L resistance is R_TOT * D / 256 and the wiper-to-H
    resistance R_TOT * (1 - D / 256) (datasheet 7.4.3, equations 3 and 4).
    Both exclude the wiper resistance itself (25 ohm typical, 100 ohm max).

    Every wiper position also exists in non-volatile memory (IVRA/IVRB), which
    is loaded into the volatile register at power-up, so a position written
    with store = True survives a power cycle (datasheet 7.1).
    """

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = TPL0102_ADDR_DEFAULT,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create a TPL0102-100 instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        i2c_addr : 7-bit target address (0x50..0x57, default 0x55 for
                   A2 = A0 = VDD, A1 = GND); it is shifted up internally to the
                   8-bit bus address byte.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency.
        """
        if not (0x00 <= i2c_addr <= 0x7F):
            raise ValueError("i2c_addr must be a 7-bit address (0x00..0x7F), "
                             "got 0x%02X" % i2c_addr)
        i2c_addr = addr7_to_addr8(i2c_addr)  # 7-bit -> bus address byte
        self.i2c_addr = i2c_addr
        self.i2c = i2c(device_ip, udp_port, base_address, i2c_addr,
                       clk_freq, i2c_freq)
        _debug("init: 8-bit addr=0x%02X (7-bit 0x%02X), base=0x%08X, "
               "clk=%dMHz, i2c=%dKHz, ip=%s:%d"
               % (i2c_addr, i2c_addr >> 1, base_address, clk_freq, i2c_freq,
                  device_ip, udp_port))

    # ------------------------------------------------------------------
    # low level: raw register transactions (debug via _debug_low_level)
    # ------------------------------------------------------------------
    def _read_register(self, reg):
        """Read one 8-bit register selected by the register address."""
        value = self.i2c.readBytes(reg, 1)[0]
        _debug_low_level("read register 0x%02X -> 0x%02X" % (reg, value))
        return value

    def _write_register(self, reg, value):
        """Write one 8-bit register selected by the register address."""
        value = value & 0xFF
        _debug_low_level("write register 0x%02X <- 0x%02X" % (reg, value))
        self.i2c.writeBytes([reg, value])
        return value

    # ------------------------------------------------------------------
    # access control register (register bank, shutdown, write in progress)
    # ------------------------------------------------------------------
    def read_acr(self):
        """Read the Access Control Register (bits defined by ACR_*)."""
        value = self._read_register(REG_ACR)
        _debug("read_acr: 0x%02X (VOL=%d SHDN=%d WIP=%d)"
               % (value, 1 if value & ACR_VOL else 0,
                  1 if value & ACR_SHDN else 0, 1 if value & ACR_WIP else 0))
        return value

    def write_acr(self, value):
        """Write the Access Control Register (VOL and SHDN are writable, WIP
        is read only)."""
        value = value & ~ACR_WIP
        _debug("write_acr: 0x%02X" % value)
        return self._write_register(REG_ACR, value)

    def _set_bank(self, volatile):
        """Select which register of a potentiometer an access reaches, keeping
        the shutdown setting: volatile (True) exposes WRA/WRB, the
        non-volatile bank (False) exposes IVRA/IVRB and makes a write load the
        volatile register as well."""
        acr = self.read_acr()
        value = (acr | ACR_VOL) if volatile else (acr & ~ACR_VOL)
        if value != acr:
            self.write_acr(value)
        return value

    def write_in_progress(self):
        """Return True while a non-volatile write cycle is running (WIP)."""
        return bool(self.read_acr() & ACR_WIP)

    def wait_write_done(self, timeout = WRITE_TIMEOUT_S):
        """Wait for a running non-volatile write cycle to finish.

        Nothing else can be written while WIP is set (datasheet 7.6.7), so
        this must be called before the next write; the cycle itself takes at
        most WRITE_CYCLE_S (tWC = 20 ms) and the default timeout leaves a
        margin for the polling itself."""
        deadline = time.time() + timeout
        while self.write_in_progress():
            if time.time() > deadline:
                raise IOError("TPL0102 ERROR: non-volatile write still in "
                              "progress after %.3f s" % timeout)

    # ------------------------------------------------------------------
    # wiper position
    # ------------------------------------------------------------------
    def read_wiper(self, pot = POT_A):
        """Read the volatile wiper code (0..255) of a potentiometer, i.e. the
        position the wiper currently has."""
        self._set_bank(volatile = True)
        value = self._read_register(_reg_for(pot))
        _debug("read_wiper(pot %c): %d (0x%02X)"
               % ("AB"[pot], value, value))
        return value

    def write_wiper(self, position, pot = POT_A, store = False):
        """Set the wiper code (0..255) of a potentiometer and return it.

        position : 0 = wiper at the L terminal, 255 = at the H terminal.
        store    : False writes the volatile register only, so the position is
                   lost at power-down; True also writes the non-volatile
                   register, which survives a power cycle but costs a write
                   cycle (tWC = 20 ms, 100k cycle endurance)."""
        if not isinstance(position, int) or not (0 <= position < NUM_TAPS):
            raise ValueError("wiper position must be an integer 0..%d, got %r"
                             % (NUM_TAPS - 1, position))
        if store:
            self.wait_write_done()          # ACR/WR writes are blocked by WIP
        self._set_bank(volatile = not store)
        self._write_register(_reg_for(pot), position)
        if store:
            self.wait_write_done()
        _debug("write_wiper(pot %c): %d (0x%02X)%s"
               % ("AB"[pot], position, position,
                  " stored in non-volatile memory" if store else ""))
        return position

    def read_stored_wiper(self, pot = POT_A):
        """Read the non-volatile (IVR) wiper code (0..255) of a potentiometer,
        i.e. the position that is recalled at power-up."""
        self._set_bank(volatile = False)
        value = self._read_register(_reg_for(pot))
        _debug("read_stored_wiper(pot %c): %d (0x%02X)"
               % ("AB"[pot], value, value))
        return value

    def store_wiper(self, pot = POT_A):
        """Save the current wiper position of a potentiometer in non-volatile
        memory and return it (read the volatile register, then write it back
        with the non-volatile register selected)."""
        position = self.read_wiper(pot)
        _debug("store_wiper(pot %c): storing %d" % ("AB"[pot], position))
        return self.write_wiper(position, pot = pot, store = True)

    # ------------------------------------------------------------------
    # shutdown mode (both potentiometers together)
    # ------------------------------------------------------------------
    def set_shutdown(self, enabled):
        """Enable (True) or disable (False) shutdown mode.

        In shutdown mode the H terminal of both potentiometers becomes high
        impedance (datasheet 7.4.1). Leaving shutdown recalls the stored wiper
        position, so a position that was only written to the volatile register
        is replaced by the non-volatile one (t(SR) = 800 ns)."""
        acr = self.read_acr()
        value = (acr & ~ACR_SHDN) if enabled else (acr | ACR_SHDN)
        _debug("set_shutdown: %s" % ("enabled" if enabled else "disabled"))
        return self.write_acr(value)

    def get_shutdown(self):
        """Return True when shutdown mode is enabled."""
        return not (self.read_acr() & ACR_SHDN)

    # ------------------------------------------------------------------
    # resistance helpers (R_TOT = 100 kohm, wiper resistance excluded)
    # ------------------------------------------------------------------
    def read_resistance(self, pot = POT_A, to_low = True):
        """Return the wiper resistance in ohms of a potentiometer, computed
        from the current wiper code (datasheet 7.4.3, equations 3 and 4):

            to_low = True  -> R_WL = R_TOT * D / 256
            to_low = False -> R_HW = R_TOT * (1 - D / 256)
        """
        position = self.read_wiper(pot)
        ratio = position / float(NUM_TAPS)
        resistance = RESISTANCE_OHM * (ratio if to_low else 1.0 - ratio)
        _debug("read_resistance(pot %c, to_low=%s): %d -> %.1f ohm"
               % ("AB"[pot], to_low, position, resistance))
        return resistance

    def write_resistance(self, resistance_ohm, pot = POT_A, to_low = True,
                         store = False):
        """Set the wiper of a potentiometer to the nearest code giving the
        requested wiper resistance in ohms and return that code.

        resistance_ohm : ideal resistance, clamped to 0..R_TOT; note that
                         code 255 leaves R_TOT/256 in the opposite direction,
                         since the wiper never reaches a terminal exactly."""
        ratio = float(resistance_ohm) / RESISTANCE_OHM
        ratio = ratio if to_low else 1.0 - ratio
        position = int(round(ratio * NUM_TAPS))
        position = max(0, min(NUM_TAPS - 1, position))
        _debug("write_resistance(%.1f ohm, pot %c, to_low=%s) -> position %d"
               % (resistance_ohm, "AB"[pot], to_low, position))
        return self.write_wiper(position, pot = pot, store = store)
