#!/usr/bin/python
# This is hv_power.py file
# high voltage control and monitoring for the u4FCPv2 board
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
"""High voltage control and monitoring.

The high-voltage chain has its own FPGA I2C core: base address 0x00020200,
while the low-voltage devices (lv power, monitors, NTC) sit behind
0x00020100.

* the level is set by a TPL0401B-10 digital potentiometer
  (i2c_addr = 0b011_1110, 0x3E) used as a rheostat: wiper position 0 gives the
  lowest output (0 V) and the full-scale resistance 10 kohm the maximum
  (600 V), so the output is linear in the resistance

      R = HV_R_FULL * voltage / HV_VOLTAGE_MAX

* the output is measured through a divider by another ADS1114
  (i2c_addr = 0b1001_000, 0x48): 0 V at its input is 0 V of output and
  HV_MONITOR_V_FULL (2.5 V) is HV_VOLTAGE_MAX, so

      voltage = monitor_voltage * HV_VOLTAGE_MAX / HV_MONITOR_V_FULL

  its Config register is programmed by init(): PGA +/-4.096 V so
  the 0..2.5 V of the divider fits, continuous conversion so read_voltage()
  always returns a fresh sample, and the comparator enabled in window mode. The
  window itself is written into the threshold registers by write_thresholds(),
  which defaults to the reset pair - a window so wide that it never asserts.

* switching is the board register hv (0x0d, see board.reg and reg_table.md):
  bit 0 is the emergency STOP - 1 = shut down, 0 = high voltage on - and bit 1
  the automatic power off on over-current. The register table gives that stop
  bit a reset value of 1, so the high voltage already powers up shut down, and
  the potentiometer comes up at a mid-scale wiper; the driver still writes the
  stop explicitly when it is created (see hv_power.__init__ and emergency_stop() /
  release_stop()).

* a high-voltage over-current alarm is reported by the module status registers
  mod_sta (0x09, live) and mod_sta_lch (0x0a, latched and cleared by reading
  it) as the hv_alm bit.
"""
from ..devices.tpl0401a_10 import (tpl0401a, RESISTANCE_OHM as HV_R_FULL,
                                   NUM_TAPS as POT_NUM_TAPS)
from ..devices.ads1114 import (ads1114, PGA_4_096V, PGA_FSR_V, DR_128SPS,
                               LO_THRESH_RESET, HI_THRESH_RESET,
                               volt_to_code, code_to_volt)
from .reg import reg, BIT_HV_STOP, BIT_HV_OC_AUTO_OFF

DEFAULT_BASE_ADDRESS = 0x00020200

ADDR_POT     = 0b011_1110  # TPL0401B-10 setting the high-voltage level (0x3E)
ADDR_MONITOR = 0b1001_000  # ADS1114 measuring the high-voltage divider (0x48)

HV_VOLTAGE_MAX    = 600.0   # output at the full-scale pot resistance, V
HV_MONITOR_V_FULL = 2.5     # monitor voltage at HV_VOLTAGE_MAX, V
HV_VOLTAGE_PER_V  = HV_VOLTAGE_MAX / HV_MONITOR_V_FULL     # 240 V per volt

# --- monitor ads1114 configuration, written by init() and
# --- write_thresholds() ------------------------------------------------------
# The divider output spans 0 V (no output) to HV_MONITOR_V_FULL (2.5 V, i.e.
# HV_VOLTAGE_MAX of output), so the PGA full-scale range has to reach 2.5 V: the
# reset range of +/-2.048 V clips above about 491 V, which is why HV_MONITOR_PGA
# replaces it with +/-4.096 V (125 uV per LSB, i.e. 30 mV of high voltage per
# LSB).
HV_MONITOR_PGA       = PGA_4_096V
HV_MONITOR_DATA_RATE = DR_128SPS    # 128 samples/s, ~7.8 ms per conversion

# comparator settings written by init(), which always leaves the
# comparator enabled. Datasheet 7.3.7: it works in window mode here, so
# ALERT/RDY asserts when the measured output exceeds Hi_thresh or falls below
# Lo_thresh, and it is LATCHED (COMP_LAT = 1): once asserted the pin stays
# asserted - so a window excursion that has already passed is not lost - until
# the Conversion register is read, which is what read_voltage() and
# read_monitor_voltage() do (and therefore print_status() as a side effect).
# init() reads it once, so the monitor starts from a released latch. COMP_QUE
# counts the successive readings beyond a threshold needed to assert: 0 = 1
# reading (fastest, ~7.8 ms at HV_MONITOR_DATA_RATE), 1 = 2, 2 = 4 for a noisy
# divider; 3 would disable the comparator and park ALERT/RDY high, which is
# never used here.
HV_MONITOR_COMP_MODE = 1            # 1 = window comparator, 0 = traditional
HV_MONITOR_QUEUE     = 0            # assert ALERT/RDY after 1 conversion
HV_MONITOR_POLARITY  = 0            # active low, open drain into the FPGA
HV_MONITOR_LATCHING  = 1            # COMP_LAT: hold the pin until it is read


class hv_power(object):
    """Control and monitor the board high voltage.

    The level is set by the potentiometer (set_voltage), the output is read
    back through the monitor ADC (read_voltage) and the supply is switched by
    the board hv register (emergency_stop / release_stop); hv_alarm() reports a
    high-voltage over-current. The monitor ADS1114 itself is set up by
    init() (default window, PGA, data rate, continuous conversion and the
    latched window comparator) and the limits of that window by
    write_thresholds(), which has to be called after it."""

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = DEFAULT_BASE_ADDRESS,
                 pot_addr = ADDR_POT,
                 monitor_addr = ADDR_MONITOR,
                 main = None,
                 shutdown = True,
                 auto_off = None):
        """Create an hv_power instance.

        device_ip / udp_port : SiTCP target (FPGA) used by every device and by
                       the board register.
        base_address : FPGA I2C-core base address of the high-voltage devices.
        pot_addr     : 7-bit address of the TPL0401B-10 setting the level.
        monitor_addr : 7-bit address of the ADS1114 measuring the output.
        main         : board register object used for the hv register and the
                       status registers (created when None), so a caller can
                       share one RBCP connection.
        shutdown     : True (default) engages the emergency stop, so the high
                       voltage is off as soon as this object exists. The
                       register itself powers up with stop = 1 (the safe
                       default of the register table) and the potentiometer with
                       a mid-scale wiper (about half of HV_VOLTAGE_MAX), so this
                       is what keeps "off" explicit; pass False to leave the
                       supply as it is.
        auto_off     : 0/1 to program the automatic power off on over-current
                       (hv register bit 1) while the supply is set up, or None
                       (default) to leave that bit as the board has it. It is
                       written with the emergency stop when shutdown is True,
                       and on its own - leaving the stop bit as it is - when
                       shutdown is False, so the bit can be set on a supply that
                       is left running.

        The monitor ADC is set up by init() (PGA, data rate,
        continuous conversion and the comparator) and its window by
        write_thresholds(); both are separate calls, so a caller that only reads
        read_voltage() should call init() first to get fresh,
        in-range samples.
        """
        self.pot = tpl0401a(device_ip, udp_port, base_address, pot_addr)
        self.monitor = ads1114(device_ip, udp_port, base_address, monitor_addr)
        self.base_address = base_address
        self.pot_addr     = pot_addr
        self.monitor_addr = monitor_addr
        self.device_ip    = device_ip
        self.udp_port     = udp_port
        self.main = main if main is not None else reg(device_ip, udp_port)
        if shutdown:
            self.emergency_stop(auto_off)   # safety first, then the monitors
        elif auto_off is not None:
            self._write_hv(self.hv_stopped(), auto_off)  # auto-off bit only
        self.under_voltage = None       # both set by write_thresholds()
        self.over_voltage  = None

    # ------------------------------------------------------------------
    # level: tpl0401b-10 rheostat in the feedback divider
    # ------------------------------------------------------------------
    @staticmethod
    def voltage_of_position(position):
        """Return the output voltage a wiper position stands for, in volts."""
        return HV_VOLTAGE_MAX * position / (POT_NUM_TAPS - 1)

    def read_setpoint(self):
        """Return the voltage the potentiometer is set to, in volts, computed
        from the wiper position it reports."""
        return self.voltage_of_position(self.pot.read_wiper())

    def set_voltage(self, voltage):
        """Set the high voltage level and return the value reached.

        The output is linear in the pot resistance, so the position is written
        for R = HV_R_FULL * voltage / HV_VOLTAGE_MAX. The pot has POT_NUM_TAPS
        taps, i.e. one tap of HV_VOLTAGE_MAX / (POT_NUM_TAPS - 1) (about 4.7 V),
        and the reached value (voltage_of_position(position)) is what is
        returned - the requested voltage is quantized to the nearest tap.

        The setting is volatile: the pot powers up at its mid-scale wiper
        (register 0x00 defaults to 0x40, about half of HV_VOLTAGE_MAX), so the
        voltage has to be set again after a power cycle of the board. Set the
        level while the supply is stopped and only then call release_stop(), so
        the output comes up at the wanted level instead of at the old one."""
        if not (0.0 <= voltage <= HV_VOLTAGE_MAX):
            raise ValueError("high voltage must be 0..%g V, got %r"
                             % (HV_VOLTAGE_MAX, voltage))
        resistance = HV_R_FULL * voltage / HV_VOLTAGE_MAX
        position = self.pot.write_resistance(resistance)
        return self.voltage_of_position(position)

    # ------------------------------------------------------------------
    # monitoring: ads1114 behind the high-voltage divider
    # ------------------------------------------------------------------
    @staticmethod
    def voltage_to_code(voltage):
        """Return the monitor code a high voltage corresponds to: the code for
        the divider output (voltage / HV_VOLTAGE_PER_V) at the PGA full-scale
        range the monitor is configured with, i.e. the value written into the
        ADS1114 threshold registers by write_thresholds().

        One code is PGA_FSR_V[HV_MONITOR_PGA] * HV_VOLTAGE_PER_V / 32768 of
        high voltage (30 mV with HV_MONITOR_PGA), and values outside what the
        PGA can represent are clamped by the conversion."""
        return volt_to_code(voltage / HV_VOLTAGE_PER_V,
                            PGA_FSR_V[HV_MONITOR_PGA])

    @staticmethod
    def code_to_voltage(code):
        """Return the high voltage an ADS1114 monitor code stands for, i.e. the
        inverse of voltage_to_code() - the code read back from a threshold
        register or from the Conversion register."""
        return code_to_volt(code, PGA_FSR_V[HV_MONITOR_PGA]) * HV_VOLTAGE_PER_V

    def write_thresholds(self, under_voltage = None, over_voltage = None):
        """Write the monitor window into the ADS1114 threshold registers and
        return it as (under_voltage, over_voltage), or None when neither limit
        was given.

        This is the only place that programmes Lo_thresh and Hi_thresh, and it
        can be called on its own: the limits are checked, converted with
        voltage_to_code() and written, while the rest of the monitor setup (PGA,
        data rate, continuous conversion, comparator) is left as it is - that is
        what init() is for.

        under_voltage / over_voltage : the two limits of the window, in volts
                       of output. A limit that cannot be used is not an error -
                       it is reported and dropped to None, i.e. treated as if it
                       had not been given, so the register on that side keeps
                       its reset value. That covers a value that is not a
                       number, one above HV_VOLTAGE_MAX, an under_voltage of 0 V
                       or more (whose code would fall below LO_THRESH_RESET),
                       and a pair with under_voltage >= over_voltage, which
                       drops both sides.
                       None for a limit means that side of the window is not
                       bounded, and its register gets the reset value -
                       Lo_thresh LO_THRESH_RESET (0x8000, -FSR) below and
                       Hi_thresh HI_THRESH_RESET (0x7FFF, +FSR - 1 LSB) above
                       (datasheet 8.1.4). None for both (the default) therefore
                       writes that reset pair, a window so wide that it never
                       asserts, which is how a window set earlier is undone.

        The thresholds are in the ADC code domain, so they are limited by the
        PGA range: one LSB is 30 mV of high voltage at HV_MONITOR_PGA."""
        # --- checks: a limit that cannot be used becomes None ------------
        limits = [under_voltage, over_voltage]
        for index, name in ((0, "under-voltage"), (1, "over-voltage")):
            if limits[index] is None:
                continue
            try:
                limits[index] = float(limits[index])
            except (TypeError, ValueError):
                print("hv_power: %s limit %r is not a number, using the reset "
                      "value" % (name, limits[index]))
                limits[index] = None
                continue
            if limits[index] > HV_VOLTAGE_MAX:
                print("hv_power: %s limit %.2f V is above HV_VOLTAGE_MAX "
                      "(%g V), using the reset value"
                      % (name, limits[index], HV_VOLTAGE_MAX))
                limits[index] = None
        under_voltage, over_voltage = limits
        # the code written into Lo_thresh has to stay at or above the reset
        # value, i.e. in the negative half of the signed code range: 0x8000 is
        # -FSR and the codes above it are the negative voltages, so the limit
        # itself has to be below 0 V
        if (under_voltage is not None
                and self.voltage_to_code(under_voltage) < LO_THRESH_RESET):
            print("hv_power: under-voltage limit %.2f V would put Lo_thresh "
                  "below LO_THRESH_RESET (0x%04X, -FSR), using the reset value"
                  % (under_voltage, LO_THRESH_RESET))
            under_voltage = None
        if (under_voltage is not None and over_voltage is not None
                and under_voltage >= over_voltage):
            print("hv_power: under-voltage limit %.2f V is not below the "
                  "over-voltage limit %.2f V, using the reset value on both "
                  "sides" % (under_voltage, over_voltage))
            under_voltage = over_voltage = None
        # --- write ------------------------------------------------------
        # A limit that was not given keeps its reset value, which leaves that
        # side of the window open; otherwise the limit is converted to the code
        # written into the threshold register.
        self.under_voltage = under_voltage
        self.over_voltage  = over_voltage
        self.monitor.write_lo_thresh(LO_THRESH_RESET if under_voltage is None
                                     else self.voltage_to_code(under_voltage))
        self.monitor.write_hi_thresh(HI_THRESH_RESET if over_voltage is None
                                     else self.voltage_to_code(over_voltage))
        if under_voltage is None and over_voltage is None:
            return None
        return self.under_voltage, self.over_voltage

    def init(self):
        """Bring the high-voltage side to its initial state.

        It

          1. puts the monitor window back to its default: write_thresholds()
             with no limits writes the reset pair, a window so wide that it
             never asserts. Call write_thresholds(under, over) after this to arm
             a real window - doing it before would be undone here,
          2. sets the monitor ADS1114 up:

             * the PGA full-scale range: HV_MONITOR_PGA = +/-4.096 V, because
               the divider delivers 0..HV_MONITOR_V_FULL (2.5 V) for
               0..HV_VOLTAGE_MAX and the reset +/-2.048 V would clip above about
               491 V,
             * the data rate: HV_MONITOR_DATA_RATE (128 samples/s),
             * the comparator, always enabled: it works in window mode
               (HV_MONITOR_COMP_MODE), so ALERT/RDY is driven low when the
               measured output leaves the window held in the threshold
               registers, i.e. when the supply drops below the under-voltage
               limit or runs above the over-voltage limit (datasheet 7.3.7). It
               is latched (HV_MONITOR_LATCHING, COMP_LAT = 1), so an excursion
               that has already passed is not lost: the pin stays asserted until
               the Conversion register is read, which read_voltage() /
               read_monitor_voltage() do (and print_status() with them).
               HV_MONITOR_QUEUE successive readings past a threshold are needed
               to assert (2 or 4 of them make it immune to a noisy divider), and
               the pin follows HV_MONITOR_POLARITY (0 = active low) and needs a
               pull-up,
             * continuous conversion, written last so that the monitor is left
               converting whatever else was programmed: the reset value is
               single-shot, which takes one sample after power-up and then
               sleeps, so read_voltage() would keep returning that first
               (stale) sample forever,
          3. engages the emergency stop (emergency_stop()): the supply is off.
             The hv register resets with stop = 1, i.e. already shut down, but
             the stop is still driven here so the state does not depend on the
             reset value, and the potentiometer comes up at a mid-scale wiper,
          4. drives the level to 0 V (set_voltage(0)), so a later release_stop()
             cannot bring the output up at an old setpoint.

        The latched alarms are left alone: mod_sta_lch (0x0a) is read-to-clear
        and shared by every module flag, so reading it here would also consume
        the low-voltage and over-temperature latches. hv_alarm_latch() returns
        the high-voltage bit of that register - the LV side (lv_power.init())
        drops and reports the latched flags for the whole board.

        Note that the ALERT/RDY pin itself cannot be read back over I2C, so this
        only reports the alarm if the pin is wired to the FPGA or a controller;
        without it, compare read_voltage() against the window in software. With
        the comparator latched (HV_MONITOR_LATCHING), only a read of the
        Conversion register - read_voltage() / read_monitor_voltage() - releases
        the pin again."""
        self.write_thresholds()             # 1. default window: the reset pair
        self.monitor.set_pga(HV_MONITOR_PGA)        # 2. monitor normal state
        self.monitor.set_data_rate(HV_MONITOR_DATA_RATE)
        self.monitor.set_comparator(True, mode = HV_MONITOR_COMP_MODE,
                                    polarity = HV_MONITOR_POLARITY,
                                    latching = HV_MONITOR_LATCHING,
                                    queue = HV_MONITOR_QUEUE)
        self.monitor.set_mode(single_shot = False)
        self.clear_monitor_int()            # release a latch left by a past run

        self.emergency_stop()               # 3. high voltage OFF
        self.set_voltage(0)                 # 4. start from 0 V

    def read_monitor_voltage(self):
        """Return the ADS1114 voltage of the high-voltage divider, in volts:
        0 V for 0 V of output, HV_MONITOR_V_FULL for HV_VOLTAGE_MAX."""
        return self.monitor.read_voltage()

    def clear_monitor_int(self):
        """Release a latched interrupt of the monitor ADS1114 and return what
        the conversion register held.

        The window comparator is latched (HV_MONITOR_LATCHING), so ALERT/RDY
        stays asserted - also after the output is back inside the window -
        until the Conversion register is read, which is what this does (see
        ads1114.clear_int()). Reading the output, read_voltage() /
        read_monitor_voltage(), releases it as well, so this is for a bring-up
        that wants to leave the pin released."""
        return self.monitor.clear_int()

    def read_voltage(self):
        """Return the measured high voltage, in volts.

        The divider ratio is HV_VOLTAGE_PER_V (240 V per monitor volt). The
        ADS1114 clips at the full-scale voltage of the PGA configured in its
        Config register: init() sets +/-4.096 V
        (HV_MONITOR_PGA), which covers the whole 0..2.5 V of the divider, so a
        reading at the full-scale code (see PGA_FSR_V) means the divider output
        went above 4.096 V, i.e. above about 983 V of output - not reachable
        from the supply (a lower HV_MONITOR_PGA would clip earlier: the reset
        +/-2.048 V at about 491 V)."""
        return self.read_monitor_voltage() * HV_VOLTAGE_PER_V

    # ------------------------------------------------------------------
    # control: board register hv (0x0d)
    # ------------------------------------------------------------------
    # Bit 0 is the emergency STOP of the high voltage (reg_table.md: 0 = high
    # voltage ON, 1 = emergency shut down) and it RESETS TO 1, so the supply is
    # off after a board reset and stays that way until a 0 is written. The
    # constructor writes it anyway, so the state never depends on the reset
    # value, and the state here is reported as "stopped" rather than as an
    # enable.
    # ------------------------------------------------------------------
    def get_hv(self):
        """Return (stopped, auto_off) of the hv control register (0x0d) as 0/1:
        stopped = 1 means the emergency stop is engaged, so the high voltage is
        off, and stopped = 0 means it is on (the default state)."""
        value = self.main.read_hv()
        return (1 if value & BIT_HV_STOP else 0,
                1 if value & BIT_HV_OC_AUTO_OFF else 0)

    def hv_stopped(self):
        """Return True when the emergency stop is engaged."""
        return bool(self.get_hv()[0])

    def hv_ready(self):
        """Return True when the high voltage is on, i.e. not stopped."""
        return not self.hv_stopped()

    def _write_hv(self, stop, auto_off = None):
        """Write the hv register, keeping the auto-off bit unless it is given."""
        if auto_off is None:
            auto_off = self.get_hv()[1]
        return self.main.set_hv(1 if stop else 0, auto_off)

    def emergency_stop(self, auto_off = None):
        """Engage the emergency stop: the high voltage goes off (hv register
        bit 0).

        auto_off : 0/1 to also set the automatic power off on over-current, or
                   None (default) to leave that bit as it is."""
        return self._write_hv(1, auto_off)

    def release_stop(self, auto_off = None):
        """Clear the emergency stop, which brings the high voltage back on
        (hv register bit 0 = 0).

        auto_off : as in emergency_stop()."""
        return self._write_hv(0, auto_off)

    # ------------------------------------------------------------------
    # high-voltage over-current alarm (mod_sta 0x09 / mod_sta_lch 0x0a)
    # ------------------------------------------------------------------
    def hv_alarm(self):
        """Return True while the high-voltage over-current alarm is active
        (mod_sta bit 2, register 0x09)."""
        return self.main.read_mod_sta()["hv_alm"]

    def hv_alarm_latch(self):
        """Return True when a high-voltage over-current alarm has been latched,
        and clear it: mod_sta_lch (register 0x0a) is read-to-clear, so one call
        consumes every latched module status flag."""
        return self.main.read_mod_sta_latch()["hv_alm"]

    # ------------------------------------------------------------------
    # summary
    # ------------------------------------------------------------------
    def print_status(self, marker = None):
        """Print the high-voltage state: control register, pot setpoint and
        measured output.

        marker : optional callable (name, value, text) -> text, called for every
        value with its formatted text, so a caller can decorate the ones it
        wants to point out (hv_monitor.py uses it to highlight the values that
        changed since the previous refresh). The default prints the plain text,
        and this module stays free of any terminal escape codes.

        The over-current flags are not shown here: the live one is read with
        hv_alarm() and the latched one with hv_alarm_latch(), which is
        read-to-clear - a status print that consumed it would wipe the record of
        an alarm that has come and gone, so a refreshing caller keeps them
        apart. Note that reading the measured output does release the latched
        window comparator of the monitor ADS1114 (see HV_MONITOR_LATCHING), so
        this print clears that one alarm as a side effect."""
        def cell(name, value, text):
            return marker(name, value, text) if marker is not None else text

        stopped, auto_off = self.get_hv()
        position = self.pot.read_wiper()
        setpoint = self.voltage_of_position(position)
        resistance = HV_R_FULL * position / (POT_NUM_TAPS - 1)
        monitor = self.read_monitor_voltage()
        measured = monitor * HV_VOLTAGE_PER_V
        on = 0 if stopped else 1
        print("HV control: on = %s  auto_off = %s"
              % (cell("on", on, "%d" % on),
                 cell("auto_off", auto_off, "%d" % auto_off)))
        print("  %-9s: pot %s/%d  R =%s ohm  ->  %s V"
              % ("setpoint", cell("position", position, "%3d" % position),
                 POT_NUM_TAPS - 1,
                 cell("resistance", resistance, "%8.1f" % resistance),
                 cell("setpoint", setpoint, "%7.2f" % setpoint)))
        print("  %-9s: monitor %s V  ->  %s V"
              % ("measured", cell("monitor_v", monitor, "%.4f" % monitor),
                 cell("measured", measured, "%7.2f" % measured)))
        print("")
