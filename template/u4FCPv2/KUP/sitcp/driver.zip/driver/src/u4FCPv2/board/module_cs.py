#!/usr/bin/python
# This is module_cs.py file
# front-end module chip-select lines (TCAL6416 on the lv I2C core)
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
from ..devices.tcal6416 import tcal6416, PORT0, PORT1

# The 16 chip-select lines hang on one TCAL6416 I/O expander of the
# low-voltage I2C core: port 0 drives modules 0..7 and port 1 modules 8..15,
# one line per module, so a module number maps to (port, bit) exactly as the
# lv power enables of lv_power do.
MODULE_COUNT = 16
MODULE_MIN   = 0
MODULE_MAX   = MODULE_COUNT - 1

# FPGA I2C-core base address of the low-voltage devices (the same core the lv
# power enable expander sits on).
DEFAULT_BASE_ADDRESS = 0x00020100

# 7-bit address of the expander carrying the CS lines (TCAL6416 with AD = L).
ADDR_CS = 0b0100_000

# The CS lines are active low: a bit of 0 pulls the line low, which asserts it
# (module selected), and a bit of 1 releases it to its pull-up (deselected).
# The expander powers up with every pin an input, so nothing drives a line
# before init().
CS_SELECTED       = 0
CS_DESELECTED     = 1
CS_ALL_SELECTED   = 0x00
CS_ALL_DESELECTED = 0xFF


class module_cs(object):
    """Drive and read the 16 front-end module chip-select lines.

    The lines are the outputs of a single TCAL6416 expander (ADDR_CS) on the
    low-voltage I2C core (DEFAULT_BASE_ADDRESS); see the module docstring of
    lv_power for how those devices are reached. Because an expander powers up
    with every pin an input, init() has to turn them into outputs before
    anything is driven, and the value written to the output latch is what the
    line carries (active low, see CS_SELECTED)."""

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = DEFAULT_BASE_ADDRESS,
                 cs_addr = ADDR_CS,
                 clk_freq = 125,   # unit: MHz
                 i2c_freq = 100):  # unit: KHz
        """Create a module_cs instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        cs_addr      : 7-bit address of the TCAL6416 driving the CS lines.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency."""
        self.base_address = base_address
        self.cs_addr      = cs_addr
        self.cs = tcal6416(device_ip, udp_port, base_address, cs_addr,
                           clk_freq, i2c_freq)

    # ------------------------------------------------------------------
    # bring-up
    # ------------------------------------------------------------------
    def init(self):
        """Configure the 16 CS lines as outputs, all deselected.

        The deselected level is loaded into the output latch before the pins
        are turned into outputs, so a line never glitches to the power-up value
        of the output register while the direction changes (the same order
        lv_power.init() uses for the lv enables). It is safe to call again."""
        for port in (PORT0, PORT1):
            self.cs.write_output(port, CS_ALL_DESELECTED)
            self.cs.write_config(port, 0x00)     # 0 = output
        return CS_ALL_DESELECTED

    # ------------------------------------------------------------------
    # module -> hardware mapping
    # ------------------------------------------------------------------
    @staticmethod
    def check_module(module):
        """Raise ValueError unless module is a valid module number (0..15)."""
        if not (MODULE_MIN <= module <= MODULE_MAX):
            raise ValueError("module must be in %d..%d, got %r"
                             % (MODULE_MIN, MODULE_MAX, module))
        return module

    @staticmethod
    def port_pin(module):
        """Return (port, pin) of the CS bit driving a module."""
        module_cs.check_module(module)
        return module // 8, module % 8

    # ------------------------------------------------------------------
    # one line
    # ------------------------------------------------------------------
    def set(self, module, selected):
        """Assert (selected = True) or release (selected = False) one module's
        CS line, and return the new output latch byte of its port."""
        module_cs.check_module(module)
        port, pin = self.port_pin(module)
        value = self.cs.read_output(port)
        if selected:
            value &= ~(1 << pin)            # active low: 0 asserts the line
        else:
            value |= (1 << pin)
        return self.cs.write_output(port, value)

    def select(self, module):
        """Assert one module's CS line (drive it low)."""
        return self.set(module, True)

    def deselect(self, module):
        """Release one module's CS line (let its pull-up take it high)."""
        return self.set(module, False)

    def get(self, module):
        """Return the level a module's CS line reads back: 0 = asserted (the
        line is low, module selected), 1 = released. This is the raw pin level,
        the same value print_status() shows for the line."""
        module_cs.check_module(module)
        port, pin = self.port_pin(module)
        return 1 if self.cs.read_input(port) & (1 << pin) else 0

    # ------------------------------------------------------------------
    # all lines
    # ------------------------------------------------------------------
    def read(self):
        """Read the 16 lines and return (port0, port1) input bytes."""
        return self.cs.read_input(PORT0), self.cs.read_input(PORT1)

    def read_output(self):
        """Read the two output latch bytes, as (port0, port1)."""
        return self.cs.read_output(PORT0), self.cs.read_output(PORT1)

    def write(self, value):
        """Drive all 16 lines from one byte written to both ports."""
        value &= 0xFF
        for port in (PORT0, PORT1):
            self.cs.write_output(port, value)
        return value

    def select_all(self):
        """Assert every CS line."""
        return self.write(CS_ALL_SELECTED)

    def deselect_all(self):
        """Release every CS line."""
        return self.write(CS_ALL_DESELECTED)

    # ------------------------------------------------------------------
    # summary
    # ------------------------------------------------------------------
    def print_status(self):
        """Print the state of the 16 CS lines.

        Each line is shown as what it READS back from the expander input
        registers, as the raw pin level: 0 when the line is low, i.e. asserted
        (module selected), and 1 when it is released - the same value get()
        returns. The output latch and input bytes of both ports are printed
        below, so a line that does not follow its latch is visible."""
        latch0, latch1 = self.read_output()
        input0, input1 = self.read()
        lines = []
        for module in range(MODULE_COUNT):
            port, pin = self.port_pin(module)
            value = input0 if port == PORT0 else input1
            lines.append(str((value >> pin) & 0x01))
        print("module CS: tcal6416 @0x%02X, base 0x%08X, %d active-low lines "
              "(0 = asserted, 1 = released)"
              % (self.cs_addr, self.base_address, MODULE_COUNT))
        print("  module : " + "".join("%3d" % m for m in range(MODULE_COUNT)))
        print("  line   : " + "".join("%3s" % s for s in lines))
        print("  latch  : port0 0x%02X  port1 0x%02X     "
              "input : port0 0x%02X  port1 0x%02X"
              % (latch0, latch1, input0, input1))
