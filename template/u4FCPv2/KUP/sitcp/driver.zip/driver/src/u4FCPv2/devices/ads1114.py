#!/usr/bin/python
# This is ads1114.py
# TI ADS1114 16-bit ADC with PGA and programmable comparator driver
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
# based on ADS111x datasheet (TI SBAS444)

from ..bus.i2c import i2c

# Debug switches, independent of each other:
#   DEBUG     = 1 -> print high-level per-operation info
#   DEBUG_LOW_LEVEL = 1 -> print low-level register/bus transactions
# Set either to 0 to silence that level only.
DEBUG            = 0
DEBUG_LOW_LEVEL  = 0


def _debug(msg):
    """Print a high-level debug message when DEBUG is enabled."""
    if DEBUG:
        print("[ads1114] " + msg)


def _debug_low_level(msg):
    """Print a low-level debug message when DEBUG_LOW_LEVEL is enabled."""
    if DEBUG_LOW_LEVEL:
        print("[ads1114-low-level] " + msg)


# ---------------------------------------------------------------------------
# Device address (datasheet Table 7-2). The single ADDR pin selects one of
# four 7-bit target addresses; the 8-bit write byte is (addr << 1).
#   ADDR = GND -> 0x48 (default)      ADDR = SDA -> 0x4A
#   ADDR = VDD -> 0x49                ADDR = SCL -> 0x4B
# ---------------------------------------------------------------------------
ADS1114_ADDR_DEFAULT = 0b100_1000  # 7-bit address 0x48, ADDR = GND


def addr7_to_addr8(addr7):
    """Convert a 7-bit target address to the 8-bit address byte sent on the
    bus with the R/W bit cleared (0x90 for ADS1114 at 0x48)."""
    return ((addr7 & 0x7F) << 1) & 0xFE


# ---------------------------------------------------------------------------
# Register address pointer P[1:0] (datasheet Table 8-1). All registers are
# 16-bit, accessed MSB first, in a single I2C transaction.
# ---------------------------------------------------------------------------
REG_CONVERSION = 0x00  # Conversion register (read)
REG_CONFIG     = 0x01  # Config register (read/write)
REG_LO_THRESH  = 0x02  # Lo_thresh register (read/write)
REG_HI_THRESH  = 0x03  # Hi_thresh register (read/write)

# --- Config register (datasheet Table 8-3) bit masks ----------------------
CFG_OS         = 0x8000  # bit15: write 1 = start single conversion; read 1 = idle
CFG_MUX        = 0x7000  # bits14:12 MUX (ADS1115 only; no function on ADS1114)
CFG_PGA        = 0x0E00  # bits11:9  programmable gain amplifier (full-scale)
CFG_MODE       = 0x0100  # bit8: 0 = continuous, 1 = single-shot/power-down
CFG_DR         = 0x00E0  # bits7:5  data rate
CFG_COMP_MODE  = 0x0010  # bit4: 0 = traditional, 1 = window comparator
CFG_COMP_POL   = 0x0008  # bit3: 0 = active low, 1 = active high
CFG_COMP_LAT   = 0x0004  # bit2: 0 = non-latching, 1 = latching comparator
CFG_COMP_QUE   = 0x0003  # bits1:0 comparator queue / disable (11 = disabled)

# --- PGA full-scale range codes (bits 11:9) -------------------------------
PGA_6_144V = 0x0  # FSR = ±6.144 V, LSB = 187.5 uV
PGA_4_096V = 0x1  # FSR = ±4.096 V, LSB = 125 uV
PGA_2_048V = 0x2  # FSR = ±2.048 V, LSB = 62.5 uV  (default)
PGA_1_024V = 0x3  # FSR = ±1.024 V, LSB = 31.25 uV
PGA_0_512V = 0x4  # FSR = ±0.512 V, LSB = 15.625 uV
PGA_0_256V = 0x5  # FSR = ±0.256 V, LSB = 7.8125 uV

# half-scale FSR in volts for each PGA code (Table 7-1)
PGA_FSR_V = {PGA_6_144V: 6.144, PGA_4_096V: 4.096, PGA_2_048V: 2.048,
             PGA_1_024V: 1.024, PGA_0_512V: 0.512, PGA_0_256V: 0.256,
             # codes 110b/111b also select ±0.256 V
             0x6: 0.256, 0x7: 0.256}

# --- data rate codes (bits 7:5, Table 8-3) --------------------------------
DR_8SPS   = 0x0
DR_16SPS  = 0x1
DR_32SPS  = 0x2
DR_64SPS  = 0x3
DR_128SPS = 0x4  # default
DR_250SPS = 0x5
DR_475SPS = 0x6
DR_860SPS = 0x7

CONFIG_RESET = 0x8583  # default config register value after reset

# Threshold register values after reset (datasheet 8.1.4, Table 8-5): the pair
# makes the comparator assert-never, i.e. -FSR for Lo_thresh and +FSR - 1 LSB
# for Hi_thresh. Swapping them (Hi_thresh 0x8000, Lo_thresh 0x7FFF) turns
# ALERT/RDY into a conversion-ready output instead.
LO_THRESH_RESET = 0x8000
HI_THRESH_RESET = 0x7FFF


def _s16(value):
    """Interpret a 16-bit value as a signed (two's complement) integer."""
    value &= 0xFFFF
    return value - 0x10000 if value & 0x8000 else value


def code_to_volt(code, fsr):
    """Convert a raw 16-bit code to volts for the given half-scale FSR:
    V = code * FSR / 32768  (LSB = FSR / 32768, datasheet 7.3.3)."""
    return _s16(code) * fsr / 32768.0


def volt_to_code(volt, fsr):
    """Convert a voltage to the nearest 16-bit code for the given FSR.
    Clamped to the representable range [-32768, 32767]: +FSR itself is not
    reachable (max code 0x7FFF = FSR - 1 LSB)."""
    code = int(round(volt * 32768.0 / fsr))
    code = max(-32768, min(32767, code))
    return code & 0xFFFF


class ads1114(object):
    """Class for communicating with an ADS1114 16-bit ADC.

    All registers are 16-bit and are selected through the 2-bit Address
    Pointer register (datasheet 8.1.1). Each access is a single I2C
    transaction with the data bytes sent MSB first:

      * write: START -> <addr|W> -> <pointer> -> <MSB> -> <LSB> -> STOP
      * read : START -> <addr|W> -> <pointer> -> RESTART ->
               <addr|R> -> <MSB> -> <LSB> -> NACK -> STOP

    implemented with u4FCPv2.bus.i2c writeBytes()/readBytes(); the register
    pointer byte is passed as the leading data byte.
    """

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = ADS1114_ADDR_DEFAULT,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create an ADS1114 instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        i2c_addr : 7-bit target address (0x48..0x4B, default 0x48 for
                   ADDR=GND); it is shifted up internally to the 8-bit bus
                   address byte.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency.
        """
        if not (0x00 <= i2c_addr <= 0x7F):
            raise ValueError("i2c_addr must be a 7-bit address (0x00..0x7F), "
                             "got 0x%02X" % i2c_addr)
        i2c_addr = addr7_to_addr8(i2c_addr)  # 7-bit -> bus address byte
        self.i2c_addr = i2c_addr
        self.i2c = i2c(device_ip, udp_port, base_address, i2c_addr,
                       clk_freq, i2c_freq)
        _debug("init: 8-bit addr=0x%02X (7-bit 0x%02X), base=0x%08X, "
               "clk=%dMHz, i2c=%dKHz, ip=%s:%d"
               % (i2c_addr, i2c_addr >> 1, base_address, clk_freq, i2c_freq,
                  device_ip, udp_port))

    # ------------------------------------------------------------------
    # low level: raw 16-bit register transactions (debug via _debug_low_level)
    # ------------------------------------------------------------------
    def _read_register16(self, pointer):
        """Read one 16-bit register selected by the address pointer."""
        data = self.i2c.readBytes(pointer, 2)
        value = ((data[0] & 0xFF) << 8) | (data[1] & 0xFF)
        _debug_low_level("read pointer 0x%02X -> 0x%04X" % (pointer, value))
        return value

    def _write_register16(self, pointer, value):
        """Write one 16-bit register selected by the address pointer,
        MSB first."""
        value = value & 0xFFFF
        _debug_low_level("write pointer 0x%02X <- 0x%04X" % (pointer, value))
        self.i2c.writeBytes([pointer, (value >> 8) & 0xFF,
                            value & 0xFF])
        return value

    # ------------------------------------------------------------------
    # conversion result
    # ------------------------------------------------------------------
    def read_conversion(self):
        """Read the last conversion result as a raw signed 16-bit code."""
        value = self._read_register16(REG_CONVERSION)
        _debug("read_conversion: 0x%04X (%d)" % (value, _s16(value)))
        return _s16(value)

    def read_voltage(self, pga = None):
        """Read the last conversion and convert it to volts.

        pga : optional PGA code (PGA_*_V) used for scaling; if None the
              current PGA setting is read from the Config register.
        """
        if pga is None:
            config = self.read_config()
            pga = (config & CFG_PGA) >> 9
        fsr = PGA_FSR_V[pga]
        volt = code_to_volt(self.read_conversion(), fsr)
        _debug("read_voltage: %.6f V (pga 0x%X, FSR +/-%g V)" % (volt, pga,
               fsr))
        return volt

    # ------------------------------------------------------------------
    # config register
    # ------------------------------------------------------------------
    def read_config(self):
        """Read the 16-bit Config register."""
        value = self._read_register16(REG_CONFIG)
        _debug("read_config: 0x%04X" % value)
        return value

    def write_config(self, value):
        """Write the 16-bit Config register (see the CFG_* masks)."""
        value = value & 0xFFFF
        _debug("write_config: 0x%04X" % value)
        return self._write_register16(REG_CONFIG, value)

    def read_config_fields(self):
        """Return the decoded Config register as a dict:
        {'pga': code, 'fsr': V, 'data_rate': sps, 'mode': 0|1, ...}."""
        c = self.read_config()
        pga = (c & CFG_PGA) >> 9
        return {
            "os":            bool(c & CFG_OS),
            "pga":           pga,
            "fsr":           PGA_FSR_V[pga],
            "mode":          1 if (c & CFG_MODE) else 0,
            "data_rate":     (c & CFG_DR) >> 5,
            "comp_mode":     1 if (c & CFG_COMP_MODE) else 0,
            "comp_pol":      1 if (c & CFG_COMP_POL) else 0,
            "comp_lat":      1 if (c & CFG_COMP_LAT) else 0,
            "comp_que":      c & CFG_COMP_QUE,
        }

    # ------------------------------------------------------------------
    # gain (PGA), data rate, mode - modify only the relevant bits
    # ------------------------------------------------------------------
    def set_pga(self, pga):
        """Set the PGA full-scale range code (PGA_*_V constants)."""
        if pga not in PGA_FSR_V:
            raise ValueError("invalid PGA code %r" % (pga,))
        temp = self.read_config()
        value = (temp & ~CFG_PGA) | ((pga & 0x07) << 9)
        _debug("set_pga: code 0x%X (FSR +/-%g V)" % (pga, PGA_FSR_V[pga]))
        return self._write_register16(REG_CONFIG, value)

    def set_data_rate(self, rate):
        """Set the data-rate code (DR_*SPS constants, 0..7)."""
        if not (0 <= rate <= 7):
            raise ValueError("data rate must be 0..7, got %r" % (rate,))
        temp = self.read_config()
        value = (temp & ~CFG_DR) | ((rate & 0x07) << 5)
        _debug("set_data_rate: code %d" % rate)
        return self._write_register16(REG_CONFIG, value)

    def set_mode(self, single_shot):
        """Set the operating mode: single_shot=True -> single-shot /
        power-down (default), False -> continuous conversion."""
        temp = self.read_config()
        value = temp | CFG_MODE if single_shot else temp & ~CFG_MODE
        _debug("set_mode: %s" % ("single-shot" if single_shot
               else "continuous"))
        return self._write_register16(REG_CONFIG, value)

    def start_conversion(self):
        """Start a single conversion (write OS=1). Returns immediately;
        poll is_conversion_done() or read the result."""
        temp = self.read_config()
        temp = (temp | CFG_MODE) & ~CFG_OS   # single-shot mode, OS=0 then 1
        value = temp | CFG_OS                # set OS to start conversion
        _debug("start_conversion: 0x%04X" % value)
        return self._write_register16(REG_CONFIG, value)

    def is_conversion_done(self):
        """Return True when the ADC is idle (no conversion running),
        i.e. the OS bit reads back 1."""
        return bool(self.read_config() & CFG_OS)

    # ------------------------------------------------------------------
    # comparator (ADS1114) - Lo_thresh / Hi_thresh and Config COMP bits
    # ------------------------------------------------------------------
    def read_lo_thresh(self):
        """Read the Lo_thresh register as a raw signed 16-bit code."""
        value = self._read_register16(REG_LO_THRESH)
        _debug("read_lo_thresh: 0x%04X (%d)" % (value, _s16(value)))
        return _s16(value)

    def read_hi_thresh(self):
        """Read the Hi_thresh register as a raw signed 16-bit code."""
        value = self._read_register16(REG_HI_THRESH)
        _debug("read_hi_thresh: 0x%04X (%d)" % (value, _s16(value)))
        return _s16(value)

    def write_lo_thresh(self, code):
        """Write the Lo_thresh register (16-bit two's complement code)."""
        code = code & 0xFFFF
        _debug("write_lo_thresh: 0x%04X (%d)" % (code, _s16(code)))
        return self._write_register16(REG_LO_THRESH, code)

    def write_hi_thresh(self, code):
        """Write the Hi_thresh register (16-bit two's complement code)."""
        code = code & 0xFFFF
        _debug("write_hi_thresh: 0x%04X (%d)" % (code, _s16(code)))
        return self._write_register16(REG_HI_THRESH, code)

    def set_comparator(self, enabled, mode = 0, polarity = 0, latching = 0,
                       queue = 1):
        """Configure the digital comparator.

        enabled : True to enable the comparator, False to disable it
                  (COMP_QUE = 11, ALERT/RDY high-impedance).
        mode    : 0 = traditional comparator, 1 = window comparator.
        polarity: 0 = ALERT/RDY active low, 1 = active high.
        latching: 0 = non-latching, 1 = latching comparator.
        queue   : 0, 1, 2 = assert after 1, 2, 4 conversions.
        """
        temp = self.read_config()
        value = temp & ~(CFG_COMP_MODE | CFG_COMP_POL | CFG_COMP_LAT |
                         CFG_COMP_QUE)
        if not enabled:
            value |= CFG_COMP_QUE  # 11b disables the comparator
        else:
            value |= (mode & 0x1) << 4
            value |= (polarity & 0x1) << 3
            value |= (latching & 0x1) << 2
            value |= (queue & 0x3)
        _debug("set_comparator: enabled=%s mode=%d pol=%d lat=%d que=%d"
               % (enabled, mode, polarity, latching, queue))
        return self._write_register16(REG_CONFIG, value)

    def clear_int(self):
        """Release a latched ALERT/RDY, i.e. clear the comparator interrupt.

        With COMP_LAT = 1 (see set_comparator) the pin holds an assertion -
        also after the input has come back inside the window - until the
        Conversion register is read (datasheet 7.3.7), and this read is what
        clears it. The returned value is a normal conversion result, not a
        status byte, and the pin asserts again only if a later conversion is
        outside the window.

        Reading the Conversion register also clears the latch as a side effect
        of every read_conversion() / read_voltage(), so this method is only
        needed where the interrupt should be dropped explicitly (a bring-up
        that wants to start from a released pin)."""
        _debug("clear_int: reading the Conversion register")
        return self.read_conversion()

    # ------------------------------------------------------------------
    # high-level helpers
    # ------------------------------------------------------------------
    def read_voltage_single(self, pga = None, data_rate = None):
        """Perform a one-shot conversion and return the voltage:
        set single-shot mode + data rate + pga, start, wait for done and
        read the result."""
        if pga is not None:
            self.set_pga(pga)
        if data_rate is not None:
            self.set_data_rate(data_rate)
        self.set_mode(single_shot = True)
        self.start_conversion()
        while not self.is_conversion_done():
            pass
        return self.read_voltage(pga = pga)

    def set_threshold_voltage(self, lo_volt, hi_volt, pga = None):
        """Set both comparator thresholds from voltages, using the given
        (or the current) PGA full-scale range for the code conversion."""
        if pga is None:
            config = self.read_config()
            pga = (config & CFG_PGA) >> 9
        fsr = PGA_FSR_V[pga]
        self.write_lo_thresh(volt_to_code(lo_volt, fsr))
        self.write_hi_thresh(volt_to_code(hi_volt, fsr))
        _debug("set_threshold_voltage: lo=%.6f V hi=%.6f V (FSR +/-%g V)"
               % (lo_volt, hi_volt, fsr))
