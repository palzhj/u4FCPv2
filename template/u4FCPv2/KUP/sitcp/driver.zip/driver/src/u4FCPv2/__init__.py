# package
# u4FCPv2/__init__.py
"""u4FCPv2 board support package: layered drivers for the FPGA board.

Layers, highest call priority first (see docs/architecture.md):
    cli        - application entry points
    board      - board-specific composition (registers, jtag switch, sysmon)
    devices    - chip drivers (I2C/SMBus devices)
    bus        - bus controllers (I2C, SPI)
    transport  - SiTCP RBCP transport over UDP

An import may only point downward: a module may use its own layer or a lower
one, never a higher one.
"""

__version__ = "0.1.0"
