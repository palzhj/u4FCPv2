#!/usr/bin/python
# This is jtag_switch.py file
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
from ..devices.tca9554a import tca9554a

GPIO_PIN_0  = 0x01
GPIO_PIN_1  = 0x02
GPIO_PIN_2  = 0x04
GPIO_PIN_3  = 0x08
GPIO_PIN_4  = 0x10
GPIO_PIN_5  = 0x20
GPIO_PIN_6  = 0x40
GPIO_PIN_7  = 0x80

RTM_DIS       = GPIO_PIN_7
FMC1_DIS      = GPIO_PIN_6
FMC0_DIS      = GPIO_PIN_5
CON_DIS       = GPIO_PIN_4
NC2           = GPIO_PIN_3
NC1           = GPIO_PIN_2
AMC_RX_EN17   = GPIO_PIN_1
AMC_TX_EN17   = GPIO_PIN_0

class jtag_sw(object):
  """Class for communicating with an I2C IO expasion using TCA9554A."""
  def __init__(self, device_ip = "192.168.10.16", udp_port = 4660,
               base_address = 0x00020000, i2c_addr = 0b011_1001,
               clk_freq = 125, i2c_freq = 100):
    """Create the JTAG switch. device_ip/udp_port select the SiTCP target
    (FPGA), base_address the I2C core, i2c_addr the TCA9554A on the bus."""
    self.jtag_sw = tca9554a(device_ip, udp_port, base_address, i2c_addr,
                   clk_freq, i2c_freq)
    self.jtag_sw.write_polarity(0)
    self.jtag_sw.write_output(RTM_DIS|FMC1_DIS|FMC0_DIS|CON_DIS)  # eable AMC
    self.jtag_sw.write_config(0)  # set all as output

  def get_status(self):
    temp = self.jtag_sw.read_input()
    print("JTAG\tRTM\tFMC1\tFMC0\tCON\tNC2\tNC1\tRX17\tTX17")
    print("Switch\t%d  \t%d  \t%d  \t%d  \t%d \t%d \t%d  \t%d"%(\
      0 if temp&RTM_DIS else 1, 0 if temp&FMC1_DIS else 1,
      0 if temp&FMC0_DIS else 1, 0 if temp&CON_DIS else 1,
      1 if temp&NC2  else 0, 1 if temp&NC1  else 0,
      1 if temp&AMC_RX_EN17 else 0, 1 if temp&AMC_TX_EN17 else 0))

  def disable_rtm(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp|RTM_DIS)

  def disable_fmc1(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp|FMC1_DIS)

  def disable_fmc0(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp|FMC0_DIS)

  def disable_con(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp|CON_DIS)

  def enable_rx17(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp|AMC_RX_EN17)

  def enable_tx17(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp|AMC_TX_EN17)


  def enable_rtm(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp&~RTM_DIS)

  def enable_fmc1(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp&~FMC1_DIS)

  def enable_fmc0(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp&~FMC0_DIS)

  def enable_con(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp&~CON_DIS)

  def disable_rx17(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp&~AMC_RX_EN17)

  def disable_tx17(self):
    temp = self.jtag_sw.read_output()
    self.jtag_sw.write_output(temp&~AMC_TX_EN17)
