#!/usr/bin/python
# This is tmp4718.py
# TI TMP4718 high-accuracy remote and local temperature sensor driver
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
# based on TMP4718 datasheet (TI SBOSA41A)

from ..bus.i2c import i2c

# Debug switches, independent of each other:
#   DEBUG     = 1 -> print high-level per-operation info
#   DEBUG_LOW_LEVEL = 1 -> print low-level register/bus transactions
# Set either to 0 to silence that level only.
DEBUG            = 0
DEBUG_LOW_LEVEL  = 0


def _debug(msg):
    """Print a high-level debug message when DEBUG is enabled."""
    if DEBUG:
        print("[tmp4718] " + msg)


def _debug_low_level(msg):
    """Print a low-level debug message when DEBUG_LOW_LEVEL is enabled."""
    if DEBUG_LOW_LEVEL:
        print("[tmp4718-low-level] " + msg)


# ---------------------------------------------------------------------------
# Device address (datasheet 8.5.3)
#   TMP4718A -> 0x4C        TMP4718B -> 0x4D
# The 8-bit write byte on the bus is then 0x98 (TMP4718A) / 0x9A (TMP4718B).
# ---------------------------------------------------------------------------
TMP4718_ADDR_DEFAULT = 0b1001_100  # 7-bit address 0x4C (TMP4718A)


def addr7_to_addr8(addr7):
    """Convert a 7-bit target address to the 8-bit address byte sent on the
    bus with the R/W bit cleared (0x98 for TMP4718 at 0x4C)."""
    return ((addr7 & 0x7F) << 1) & 0xFE


# ---------------------------------------------------------------------------
# Register map (datasheet Table 8-4). Access is one register per I2C
# transaction: START -> <addr|W> -> <pointer> -> ... -> STOP (Fig 8-12/8-13).
# ---------------------------------------------------------------------------
REG_TEMP_LOCAL        = 0x00  # local temperature, 8-bit 2's complement, 1 C/LSB
REG_TEMP_REMOTE_MSB   = 0x01  # remote temperature MSB, bits [10:3]
REG_ALERT_STATUS      = 0x02  # alert status (read)
REG_CONFIG            = 0x03  # configuration (also 0x09)
REG_CONV_PERIOD       = 0x04  # conversion period (also 0x0A)
REG_THIGH_LIMIT_LOCAL = 0x05  # local high alert limit (also 0x0B)
REG_THIGH_LIMIT_REMOTE_MSB = 0x07  # remote high alert limit MSB (also 0x0D)
REG_TLOW_LIMIT_REMOTE_MSB  = 0x08  # remote low alert limit MSB (also 0x0E)
REG_ONE_SHOT          = 0x0F  # one-shot conversion trigger (write only)
REG_TEMP_REMOTE_LSB   = 0x10  # remote temperature LSB, bits [2:0] at [7:5]
REG_REMOTE_OFFSET_MSB = 0x11  # remote temperature offset MSB
REG_REMOTE_OFFSET_LSB = 0x12  # remote temperature offset LSB
REG_THIGH_LIMIT_REMOTE_LSB = 0x13  # remote high alert limit LSB
REG_TLOW_LIMIT_REMOTE_LSB  = 0x14  # remote low alert limit LSB
REG_ALERT_MASK        = 0x16  # alert mask
REG_THIGH_CRIT_REMOTE = 0x19  # remote critical limit, 8-bit 1 C/LSB
REG_THIGH_CRIT_LOCAL  = 0x20  # local critical limit, 8-bit 1 C/LSB
REG_CRIT_HYSTERESIS   = 0x21  # critical hysteresis, 5-bit 1 C/LSB
REG_LOG1              = 0x2D  # general purpose log registers
REG_LOG2              = 0x2E
REG_LOG3              = 0x2F
REG_FILTER_ALERT_MODE = 0xBF  # remote filter level and alert mode
REG_CHIP_ID           = 0xFD  # chip id (0x50)
REG_VENDOR_ID         = 0xFE  # vendor id (0x60)
REG_DEVICE_REV_ID     = 0xFF  # device and revision id (0x90)

# --- Configuration register (0x03) bits -----------------------------------
CFG_ALERT_MASK = 0x80  # 1 = ALERT pin masked
CFG_MODE       = 0x40  # 1 = shutdown mode, 0 = continuous mode
CFG_REMOTE_EN  = 0x04  # 1 = remote channel enabled
CFG_WTC_EN     = 0x02  # 1 = T_CRIT limits can be changed
CFG_FAULT_Q    = 0x01  # 1 = fault queue enabled (remote channel)

# --- Alert status register (0x02) bits ------------------------------------
ALERT_ADC_BUSY   = 0x80  # ADC is converting
ALERT_THIGH_LA   = 0x40  # local temp > local high limit
ALERT_THIGH_RA   = 0x10  # remote temp > remote high limit
ALERT_TLOW_RA    = 0x08  # remote temp < remote low limit
ALERT_REMOTE_DC  = 0x04  # remote channel disconnected
ALERT_TCRIT_R    = 0x02  # remote temp > remote crit limit
ALERT_TCRIT_L    = 0x01  # local temp > local crit limit

# --- Alert mask register (0x16) bits --------------------------------------
MASK_THIGH_LA = 0x80
MASK_THIGH_RA = 0x10
MASK_TLOW_RA  = 0x08
MASK_TCRIT_R  = 0x02
MASK_TCRIT_L  = 0x01

# --- Filter and alert mode register (0xBF) --------------------------------
FILTER_LEVEL_0   = 0x00  # no averaging (default)
FILTER_LEVEL_4   = 0x02  # 4-sample moving average
FILTER_LEVEL_8   = 0x06  # 8-sample moving average
ALERT_MODE_INT   = 0x00  # interrupt / SMBus alert mode (default)
ALERT_MODE_COMP  = 0x01  # comparator mode

# Remote temperature fractional resolution
REMOTE_LSB_C = 0.125  # 11-bit value, 0.125 C per LSB


def _s8(value):
    """Interpret an 8-bit byte as a signed (two's complement) integer."""
    value &= 0xFF
    return value - 0x100 if value & 0x80 else value


def _s11(value):
    """Interpret an 11-bit value as a signed (two's complement) integer."""
    value &= 0x7FF
    return value - 0x800 if value & 0x400 else value


def _local_to_reg(temp_c):
    """Encode a local temperature (C) into the 8-bit 1 C/LSB format."""
    return int(round(temp_c)) & 0xFF


def _remote_to_regs(temp_c):
    """Encode a remote temperature (C) into the 11-bit 0.125 C/LSB format.
    Returns (msb, lsb_byte) where msb holds bits [10:3] and the lsb byte
    holds bits [2:0] shifted left into register bits [7:5]."""
    code = int(round(temp_c / REMOTE_LSB_C)) & 0x7FF
    return (code >> 3) & 0xFF, (code & 0x07) << 5


class tmp4718(object):
    """Class for communicating with a TMP4718 temperature sensor.

    Every register is accessed in a single-byte I2C transaction:
      * write: START -> <addr|W> -> <pointer> -> <data> -> STOP
      * read : START -> <addr|W> -> <pointer> -> RESTART ->
               <addr|R> -> <data> -> NACK -> STOP
    (datasheet 8.5.4, implemented by i2c.readBytes(data, len)/writeBytes
    with the register pointer as leading data). The device does not
    support multi-byte
    register reads or writes.
    """

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = TMP4718_ADDR_DEFAULT,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create a TMP4718 instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        i2c_addr : 7-bit target address (0x4C for TMP4718A or 0x4D for
                   TMP4718B, default 0x4C); it is shifted up internally to
                   the 8-bit bus address byte.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency.
        """
        if not (0x00 <= i2c_addr <= 0x7F):
            raise ValueError("i2c_addr must be a 7-bit address (0x00..0x7F), "
                             "got 0x%02X" % i2c_addr)
        i2c_addr = addr7_to_addr8(i2c_addr)  # 7-bit -> bus address byte
        self.i2c_addr = i2c_addr
        self.i2c = i2c(device_ip, udp_port, base_address, i2c_addr,
                       clk_freq, i2c_freq)
        _debug("init: 8-bit addr=0x%02X (7-bit 0x%02X), base=0x%08X, "
               "clk=%dMHz, i2c=%dKHz, ip=%s:%d"
               % (i2c_addr, i2c_addr >> 1, base_address, clk_freq, i2c_freq,
                  device_ip, udp_port))

    # ------------------------------------------------------------------
    # low level: raw register transactions (debug via _debug_low_level)
    # ------------------------------------------------------------------
    def _read_register(self, reg):
        """Read one 8-bit register selected by the pointer byte."""
        value = self.i2c.readBytes(reg, 1)[0]
        _debug_low_level("read reg 0x%02X -> 0x%02X" % (reg, value))
        return value

    def _write_register(self, reg, value):
        """Write one 8-bit register selected by the pointer byte."""
        value = value & 0xFF
        _debug_low_level("write reg 0x%02X <- 0x%02X" % (reg, value))
        self.i2c.writeBytes([reg, value])
        return value

    # ------------------------------------------------------------------
    # temperatures
    # ------------------------------------------------------------------
    def read_local_temp(self):
        """Read the local temperature in degrees Celsius (1 C/LSB)."""
        code = self._read_register(REG_TEMP_LOCAL)
        temp = float(_s8(code))
        _debug("read_local_temp: 0x%02X -> %.1f C" % (code, temp))
        return temp

    def read_remote_temp(self):
        """Read the remote temperature in degrees Celsius (0.125 C/LSB).
        Returns None if the remote channel is disconnected."""
        status = self.read_alert_status()
        if status & ALERT_REMOTE_DC:
            _debug("read_remote_temp: remote channel disconnected")
            return None
        msb = self._read_register(REG_TEMP_REMOTE_MSB)
        lsb = self._read_register(REG_TEMP_REMOTE_LSB)
        code = _s11((msb << 3) | (lsb >> 5))
        temp = code * REMOTE_LSB_C
        _debug("read_remote_temp: 0x%02X 0x%02X -> %.3f C"
               % (msb, lsb, temp))
        return temp

    # ------------------------------------------------------------------
    # alert status and masks
    # ------------------------------------------------------------------
    def read_alert_status(self):
        """Read the Alert Status register (bits defined by ALERT_*)."""
        status = self._read_register(REG_ALERT_STATUS)
        _debug("alert_status: 0x%02X" % status)
        return status

    def read_alert_mask(self):
        """Read the Alert Mask register (bits defined by MASK_*)."""
        return self._read_register(REG_ALERT_MASK)

    def write_alert_mask(self, value):
        """Write the Alert Mask register: a set bit masks (disables) that
        alert from asserting the ALERT pin."""
        value = value & 0xFF
        _debug("write_alert_mask: 0x%02X" % value)
        return self._write_register(REG_ALERT_MASK, value)

    # ------------------------------------------------------------------
    # configuration and conversion
    # ------------------------------------------------------------------
    def read_config(self):
        """Read the Configuration register (bits defined by CFG_*)."""
        return self._read_register(REG_CONFIG)

    def write_config(self, value):
        """Write the Configuration register."""
        value = value & 0xFF
        _debug("write_config: 0x%02X" % value)
        return self._write_register(REG_CONFIG, value)

    def set_shutdown(self, enabled):
        """Put the device into Shutdown mode (True) or Continuous mode
        (False). In shutdown mode trigger conversions with one_shot()."""
        temp = self.read_config()
        value = temp | CFG_MODE if enabled else temp & ~CFG_MODE
        _debug("set_shutdown: %s" % enabled)
        return self._write_register(REG_CONFIG, value)

    def set_remote_enable(self, enabled):
        """Enable (True) or disable (False) the remote temperature channel."""
        temp = self.read_config()
        value = temp | CFG_REMOTE_EN if enabled else temp & ~CFG_REMOTE_EN
        _debug("set_remote_enable: %s" % enabled)
        return self._write_register(REG_CONFIG, value)

    def set_fault_queue(self, enabled):
        """Enable (True) / disable (False) the fault queue (remote channel):
        three successive out-of-limit results needed to assert ALERT."""
        temp = self.read_config()
        value = temp | CFG_FAULT_Q if enabled else temp & ~CFG_FAULT_Q
        _debug("set_fault_queue: %s" % enabled)
        return self._write_register(REG_CONFIG, value)

    def set_wtc_enable(self, enabled):
        """Allow (True) / disallow (False) changing the T_CRIT limits.
        Must be True before writing THigh_Crit_Remote/Local."""
        temp = self.read_config()
        value = temp | CFG_WTC_EN if enabled else temp & ~CFG_WTC_EN
        _debug("set_wtc_enable: %s" % enabled)
        return self._write_register(REG_CONFIG, value)

    def read_conv_period(self):
        """Read the conversion period register: 0=16s ... 8=62.5ms (default)."""
        return self._read_register(REG_CONV_PERIOD) & 0x0F

    def write_conv_period(self, period):
        """Set the conversion period code (0..8), datasheet Table 8-10."""
        if not (0 <= period <= 8):
            raise ValueError("conversion period must be 0..8, got %r"
                             % (period,))
        _debug("write_conv_period: %d" % period)
        return self._write_register(REG_CONV_PERIOD, period & 0x0F)

    def one_shot(self):
        """Trigger a one-shot conversion (device must be in shutdown mode)."""
        _debug("one_shot")
        return self._write_register(REG_ONE_SHOT, 0xFF)

    # ------------------------------------------------------------------
    # local high alert limit (8-bit, 1 C/LSB)
    # ------------------------------------------------------------------
    def read_local_high_limit(self):
        """Read the local high alert limit in degrees Celsius."""
        code = self._read_register(REG_THIGH_LIMIT_LOCAL)
        return float(_s8(code))

    def write_local_high_limit(self, temp_c):
        """Set the local high alert limit in degrees Celsius."""
        code = _local_to_reg(temp_c)
        _debug("write_local_high_limit: %.1f C -> 0x%02X" % (temp_c, code))
        return self._write_register(REG_THIGH_LIMIT_LOCAL, code)

    # ------------------------------------------------------------------
    # remote high/low alert limits (11-bit, 0.125 C/LSB, two registers)
    # ------------------------------------------------------------------
    def _read_remote_limit(self, msb_reg, lsb_reg):
        msb = self._read_register(msb_reg)
        lsb = self._read_register(lsb_reg)
        code = _s11((msb << 3) | (lsb >> 5))
        return code * REMOTE_LSB_C

    def _write_remote_limit(self, msb_reg, lsb_reg, temp_c):
        msb, lsb = _remote_to_regs(temp_c)
        _debug("write_remote_limit 0x%02X/0x%02X: %.1f C -> msb 0x%02X, "
               "lsb 0x%02X" % (msb_reg, lsb_reg, temp_c, msb, lsb))
        self._write_register(msb_reg, msb)
        return self._write_register(lsb_reg, lsb)

    def read_remote_high_limit(self):
        """Read the remote high alert limit in degrees Celsius."""
        return self._read_remote_limit(REG_THIGH_LIMIT_REMOTE_MSB,
                                       REG_THIGH_LIMIT_REMOTE_LSB)

    def write_remote_high_limit(self, temp_c):
        """Set the remote high alert limit in degrees Celsius."""
        return self._write_remote_limit(REG_THIGH_LIMIT_REMOTE_MSB,
                                        REG_THIGH_LIMIT_REMOTE_LSB, temp_c)

    def read_remote_low_limit(self):
        """Read the remote low alert limit in degrees Celsius."""
        return self._read_remote_limit(REG_TLOW_LIMIT_REMOTE_MSB,
                                       REG_TLOW_LIMIT_REMOTE_LSB)

    def write_remote_low_limit(self, temp_c):
        """Set the remote low alert limit in degrees Celsius."""
        return self._write_remote_limit(REG_TLOW_LIMIT_REMOTE_MSB,
                                        REG_TLOW_LIMIT_REMOTE_LSB, temp_c)

    # ------------------------------------------------------------------
    # critical limits (8-bit, 1 C/LSB; need WTC_En set before writing)
    # ------------------------------------------------------------------
    def read_crit_remote(self):
        """Read the remote critical (T_CRIT) limit in degrees Celsius."""
        return float(_s8(self._read_register(REG_THIGH_CRIT_REMOTE)))

    def write_crit_remote(self, temp_c):
        """Set the remote critical limit (enables WTC first)."""
        self.set_wtc_enable(True)
        code = _local_to_reg(temp_c)
        _debug("write_crit_remote: %.1f C -> 0x%02X" % (temp_c, code))
        return self._write_register(REG_THIGH_CRIT_REMOTE, code)

    def read_crit_local(self):
        """Read the local critical (T_CRIT) limit in degrees Celsius."""
        return float(_s8(self._read_register(REG_THIGH_CRIT_LOCAL)))

    def write_crit_local(self, temp_c):
        """Set the local critical limit (enables WTC first)."""
        self.set_wtc_enable(True)
        code = _local_to_reg(temp_c)
        _debug("write_crit_local: %.1f C -> 0x%02X" % (temp_c, code))
        return self._write_register(REG_THIGH_CRIT_LOCAL, code)

    def read_crit_hysteresis(self):
        """Read the critical hysteresis in degrees Celsius (5-bit, 1 C/LSB)."""
        return float(self._read_register(REG_CRIT_HYSTERESIS) & 0x1F)

    def write_crit_hysteresis(self, temp_c):
        """Set the critical hysteresis in degrees Celsius (0..31)."""
        value = int(round(temp_c)) & 0x1F
        _debug("write_crit_hysteresis: %d C" % value)
        return self._write_register(REG_CRIT_HYSTERESIS, value)

    # ------------------------------------------------------------------
    # remote offset (11-bit, 0.125 C/LSB, two registers)
    # ------------------------------------------------------------------
    def read_remote_offset(self):
        """Read the remote temperature offset in degrees Celsius."""
        return self._read_remote_limit(REG_REMOTE_OFFSET_MSB,
                                       REG_REMOTE_OFFSET_LSB)

    def write_remote_offset(self, temp_c):
        """Set the remote temperature offset in degrees Celsius."""
        return self._write_remote_limit(REG_REMOTE_OFFSET_MSB,
                                        REG_REMOTE_OFFSET_LSB, temp_c)

    # ------------------------------------------------------------------
    # filter and alert mode (0xBF)
    # ------------------------------------------------------------------
    def read_filter_alert_mode(self):
        """Read the Filter and Alert Mode register."""
        return self._read_register(REG_FILTER_ALERT_MODE)

    def set_filter_level(self, level):
        """Set the remote digital filter level: 0 (none), 2 (4 samples) or
        6 (8 samples) in the register's Filter_Level[2:1] field."""
        level = (level & 0x06)          # keep only bits [2:1]
        temp = self._read_register(REG_FILTER_ALERT_MODE)
        value = (temp & ~0x06) | level
        _debug("set_filter_level: 0x%02X" % level)
        return self._write_register(REG_FILTER_ALERT_MODE, value)

    def set_alert_mode(self, comparator):
        """Select the ALERT pin mode: comparator mode (True) or interrupt /
        SMBus alert mode (False)."""
        temp = self._read_register(REG_FILTER_ALERT_MODE)
        value = (temp & ~0x01) | (0x01 if comparator else 0x00)
        _debug("set_alert_mode: %s" % ("comparator" if comparator
               else "interrupt"))
        return self._write_register(REG_FILTER_ALERT_MODE, value)

    # ------------------------------------------------------------------
    # identification
    # ------------------------------------------------------------------
    def read_chip_id(self):
        """Read the Chip ID register (0x50 for TMP4718)."""
        return self._read_register(REG_CHIP_ID)

    def read_vendor_id(self):
        """Read the Vendor ID register (0x60 for TI)."""
        return self._read_register(REG_VENDOR_ID)

    def read_device_rev_id(self):
        """Read the Device and Revision ID register (0x90 for TMP4718)."""
        return self._read_register(REG_DEVICE_REV_ID)
