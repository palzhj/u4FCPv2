#!/usr/bin/python
# This is lv_power.py file
# 16-channel lv power control and monitoring for the u4FCPv2 board
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
"""LV power control and monitoring (two stages).

Power-on is a two-stage sequence:

* **stage 1 - main power**: the board low-voltage enable, register 0x0b of the
  board register map (`board.reg.set_lv(1, auto_off)`). Nothing downstream is
  powered while this bit is 0.
* **stage 2 - sub power**: the 16 module enables on the expander
  `tcal6416(i2c_addr = 0b0100_001)`, one bit per module.

Because stage 2 is meaningless with stage 1 off, every stage-2 switch operation
reads the lv register first and raises RuntimeError when the main power is off.
Use `power_on(module)` / `power_on_all()` to run the sequence, or `set_main(1)`
once and then the stage-2 calls. Monitor reads are NOT guarded: they return
whatever the INA745/TMP4718 report, which is useful when diagnosing a rail that
is expected to be off.

Hardware topology (see the MODULE_POWER_EN section of cli.py):

* 16 module powers, one per output bit of the enable expander
  tcal6416(i2c_addr = 0b0100_001):

      module m  ->  port m // 8, pin m % 8      (m = 0..15)

  so modules 0..7 are port 0 bits 0..7 and modules 8..15 are port 1 bits 0..7.
  Bit value 1 switches that module's power ON, 0 switches it OFF. Both ports
  are configured as open-drain (register 0x4F), so 1 releases the line to its
  external pull-up and 0 pulls it low.

  Each enable line is wired-AND with the over-current output of that module's
  INA745 (open drain, active low): with the rail enabled the line is held up by
  the pull-up, and an over-current pulls it low - which the expander raises on
  its INT pin, wired to the FPGA. The FPGA reports that as lv_alm, live in
  mod_sta (0x09) and latched in mod_sta_lch (0x0a); lv_alarm() and
  lv_alarm_latch() read those, and the per-module view comes from reading the
  expander input port (see read_module). The interrupt mask registers power up
  masked (0xFF), so init() has to clear them for the INT pin to assert at all.
  The latch of an event is the monitor's own (ALATCH), not the expander's: the
  expander input latch stays off, and clear_oc_interrupt() drops the flag.

* the power monitor of each module is an INA745 placed after the TCA9548A
  (i2c_addr = 0b1110_011); two INA745 share one switch channel:

      module m  ->  channel m // 2
                    ina745 0b1000_000 (0x40) for even m
                    ina745 0b1000_001 (0x41) for odd  m

  The channel is selected before every monitor access, because the single
  INA745 bus pair is shared through the switch. The Current Over-Limit
  register (COL) of that INA745 is the per-module over-current threshold, see
  write_oc_limit().

* temperature: the TMP4718 (i2c_addr = 0b1001_100) remote channel measures the
  module temperature, its local channel the board temperature. In addition
  every INA745 reports its own local temperature.

* the ADS1114 (i2c_addr = 0b1001_001) measures the NTC thermistor divider;
  it is a single device shared by the whole board, wired directly on the
  board I2C bus and NOT behind the tca9548a, so it needs no channel selection
  and returns one temperature for the board (read_ntc_temp()). A reading close
  to full scale means no module is connected: the unplugged thermistor leaves
  the input pulled up to the supply, so read_ntc_temp() returns None.

* the output voltage of each module is set by a TPL0102-100 digital
  potentiometer (i2c_addr = 0b101_0101) sitting behind the same tca9548a
  channel as that module's INA745 pair: pot A for the even module of the
  channel, pot B for the odd one. See set_potentiometer().
"""
from ..devices.tcal6416 import tcal6416
from ..devices.tca9548a import tca9548a
from ..devices.ina745 import ina745, LSB_CURRENT, DIAG_CURRENTOL
from ..devices.tmp4718 import tmp4718
from ..devices.ads1114 import ads1114, CFG_PGA, PGA_FSR_V, PGA_4_096V, DR_128SPS
from ..devices.tpl0102_100 import (tpl0102_100, POT_A, POT_B,
                                   RESISTANCE_OHM as POT_R_TOT_OHM,
                                   NUM_TAPS as POT_NUM_TAPS)
from .reg import reg
import math
import time

MODULE_COUNT = 16
MODULE_MIN   = 0
MODULE_MAX   = MODULE_COUNT - 1

DEFAULT_BASE_ADDRESS = 0x00020100

ADDR_ENABLE   = 0b0100_001  # tcal6416: 16 lv power enable outputs
ADDR_SWITCH   = 0b1110_011  # tca9548a: switch in front of the power monitors
ADDR_INA_EVEN = 0b1000_000  # ina745 of the even module on a channel
ADDR_INA_ODD  = 0b1000_001  # ina745 of the odd  module on a channel
ADDR_TEMP     = 0b1001_100  # tmp4718: remote = module, local = board
ADDR_NTC      = 0b1001_001  # ads1114 measuring the NTC divider (0x49)
ADDR_POT      = 0b101_0101  # tpl0102_100 setting the module output voltage

# --- module output voltage divider -----------------------------------------
# The converter regulates its feedback node to POT_VREF_V, so with the
# potentiometer as the upper resistor R1 (wiper to the L terminal) and the
# fixed lower resistor R2:
#
#     Vout = POT_VREF_V * (R1 + R2) / R2
#     R1   = POT_R2_OHM * (Vout / POT_VREF_V - 1)
#
# R1 = 0 (wiper at the L terminal) gives the reference voltage itself, the
# power-up value R_TOT / 2 gives about 2.40 V, and the 256 taps span
# POT_V_MIN_V (1.2 V) .. POT_V_MAX_V (about 3.60 V) with R2 = 49.9 kohm.
POT_R2_OHM  = 49900.0       # fixed lower resistor R2 of the divider, ohm
POT_VREF_V  = 1.2           # feedback reference voltage, V
POT_R1_MIN_OHM = POT_R_TOT_OHM / POT_NUM_TAPS                       # one step
POT_R1_MAX_OHM = POT_R_TOT_OHM * (POT_NUM_TAPS - 1) / POT_NUM_TAPS  # max code
POT_V_MIN_V = POT_VREF_V                                    # R1 = 0 ohm
POT_V_MAX_V = POT_VREF_V * (1.0 + POT_R1_MAX_OHM / POT_R2_OHM)

# --- module over-current protection ----------------------------------------
# The threshold is the Current Over-Limit register (COL, address 0Ch) of the
# module's INA745: a 16-bit two's complement value with 1.2 mA/LSB. The device
# sets the CURRENTOL bit of its diagnostic register (0Bh, mask DIAG_CURRENTOL)
# when the measured current exceeds it. COL resets to 7FFFh, i.e. the maximum
# below, which is far above any module current and so trips nothing.
#
# The INA745 has no mask or enable bit for that flag (CURRENTOL is read only
# and there is no alert mask register), so the interrupt is armed by the
# threshold itself and write_oc_limit() also puts the monitor in latched alert
# mode: a trip then stays asserted until clear_oc_interrupt() reads the
# diagnostic register.
OC_LIMIT_MAX_CODE = 32767                       # largest positive COL code
OC_LIMIT_MAX_A    = OC_LIMIT_MAX_CODE * LSB_CURRENT

# Register 0x4F of the enable expander (ODEN0/ODEN1): both enable ports as
# open-drain, so an enable can only pull its line low and the ON state releases
# it to the external pull-up (see init()).
ENABLE_OPEN_DRAIN = 0x03

# The over-current status of the modules is wired to the input pins of the same
# tcal6416: input bit (port, pin) of module m = (m // 8, m % 8), the mapping of
# the enable outputs. Both the enables and these over-current lines are
# open-drain, so a pin reads 0 while its module reports over-current and 1 in
# the idle state (held by the pull-ups). Set this to False if a board drives
# the inputs active high instead.
OC_ACTIVE_LOW = True

POWER_OFF = 0
POWER_ON  = 1

# Delay in seconds between two consecutive lv power-ons. Switching all 16
# modules on in one write would sum their inrush currents; ramping them one by
# one keeps the surge of the common supply to a single module.
POWER_ON_DELAY = 0.1

# --- NTC thermistor chain measured by the ADS1114 --------------------------
# The ADS1114 measures the voltage across the NTC of a divider that is fed from
# NTC_VREF_V, with NTC_R_SERIES above it:
#
#     V_NTC = NTC_VREF_V * R_NTC / (NTC_R_SERIES + R_NTC)
#     R_NTC = NTC_R_SERIES * V_NTC / (NTC_VREF_V - V_NTC)
#
# which the Beta equation turns into a temperature:
#
#     T = 1 / (1/T0 + (1/B) * ln(R_NTC / R0)) - 273.15
#
# The divider ratio is taken against the EXCITATION voltage of the divider, not
# against the full-scale voltage of the ADC: the PGA only sets how many codes
# the ADC produces per volt, and mixing the two makes R_NTC - and so the
# temperature - come out wrong.
NTC_R_SERIES  = 100000.0    # series resistor of the divider, unit: ohm
NTC_VREF_V    = 3.3         # excitation voltage of the divider, unit: V
NTC_R0        = 10000.0     # NTC resistance at the reference temperature, ohm
NTC_T0_K      = 298.15      # reference temperature (25 degC), unit: K
NTC_BETA      = 3380.0      # NTC B constant, unit: K

# An unconnected module leaves the NTC input floating up to the supply through
# the series resistor, so the ADS1114 reads at (or clipped to) the top of the
# divider. Such a reading is not a temperature: it is reported as "no module
# connected" (None / "open"). The limit is a fraction of that top voltage, i.e.
# of the smaller of the excitation voltage and the PGA full scale.
NTC_OPEN_FRACTION = 0.95    # reading this close to the top = no module

# --- NTC over-temperature alert (ADS1114 digital comparator) ---------------
# The ADS1114 runs in continuous-conversion mode with its window comparator
# driving ALERT/RDY, because with this divider the reading DECREASES as the
# thermistor heats up while the traditional comparator only asserts on data
# ABOVE Hi_thresh. In window mode the pin asserts when the data exceed
# Hi_thresh OR fall below Lo_thresh (datasheet 7.3.7). Lo_thresh is therefore
# written with the code of NTC_ALERT_TEMP, so the pin asserts as soon as the
# module is hotter than 60 degC, and Hi_thresh is left at NTC_ALERT_TOP_CODE
# (0x7FFF, the largest code the ADC can produce) so the upper side never trips.
# A window comparator has no hysteresis: the pin releases as soon as the
# reading climbs back above Lo_thresh, i.e. exactly at NTC_ALERT_TEMP.
# Use config_ntc(window = False) for the traditional comparator instead, which
# alerts on the COLD side and does have a hysteresis band (NTC_HYST_TEMP).
NTC_ALERT_TEMP  = 60.0      # degC: the temperature the alert trips on
NTC_ALERT_TOP_CODE = 0x7FFF # Hi_thresh in window mode: upper side disabled
NTC_HYST_TEMP  = 2.0        # degC: band width, traditional mode only
NTC_ALERT_LATCH = 1         # COMP_LAT: 1 = latched until conversion data read
NTC_ALERT_QUEUE = 1         # COMP_QUE: 0 = 1, 1 = 2, 2 = 4 conversions
NTC_ALERT_WINDOW = True     # COMP_MODE: 1 = window, 0 = traditional

# --- NTC ADC (ADS1114) setup, written by config_ntc() ----------------------
# The board carries two ADS1114s - this NTC one and the high-voltage monitor -
# and both are brought up the same way by their board driver: an explicit PGA
# range, an explicit data rate, continuous conversion and a digital comparator.
# An explicit range matters here because the reset one (PGA_2_048V) is narrower
# than the divider: it delivers 0..NTC_VREF_V (3.3 V), so the reset range clips
# from about -34 degC downwards - and a clipped reading looks exactly like an
# unconnected module (see ntc_connected()), which would report a cold module as
# absent. NTC_PGA covers the whole divider instead.
NTC_PGA       = PGA_4_096V  # +/-4.096 V, 125 uV per LSB
NTC_DATA_RATE = DR_128SPS   # 128 samples/s, the reset data rate

MAIN_ON  = 0x01             # lv register bit 0: lv power ON
MAIN_AUTO_OFF = 0x02        # lv register bit 1: auto power off on over-temp

# Column layout of print_status(): the column name, what the column holds, the
# field width and the format of its values. Keeping the layout in one place
# makes the two header rows, the rules and the numbers line up by themselves.
STATUS_COLUMNS = (
    ("Module",   "No.",  6, "%6d"),
    ("ON",       "Y/N",  3, "%3s"),
    ("Vout",     "V",    7, "%7.3f"),
    ("OC",       "Y/N",  3, "%3s"),
    ("OC_LIMIT", "A",   10, "%10.3f"),
    ("Iout",     "A",    8, "%8.4f"),
    ("Pout",     "W",    7, "%7.3f"),
    ("Tlocal",   "C",    7, "%7.2f"),
)


def _fmt(temp, absent = "n/a"):
    """Format an optional temperature for the status printout."""
    return absent if temp is None else "%.2f" % temp


def ntc_threshold_code(temp, fsr = PGA_FSR_V[NTC_PGA]):
    """Return the Hi_thresh / Lo_thresh code of a temperature in degC.

    The temperature is turned into an NTC resistance (inverse Beta equation),
    the resistance into the divider voltage V_NTC = NTC_VREF_V * R / (R + Rs),
    and that voltage into the code the comparator compares with the conversion
    register, whose LSB is fsr / 32768 (fsr = the full-scale voltage of the PGA
    configured in the ADS1114; the default is the NTC_PGA that config_ntc()
    writes)."""
    resistance = NTC_R0 * math.exp(NTC_BETA * (1.0 / (temp + 273.15)
                                               - 1.0 / NTC_T0_K))
    volt = NTC_VREF_V * resistance / (NTC_R_SERIES + resistance)
    return int(round(volt * 32768.0 / fsr))


class lv_power(object):
    """Control and monitor the 16-channel lv power of the board.

    Stage 1 (main power) is the board lv register, stage 2 the per-module
    enables on the tcal6416; see the module docstring."""

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = DEFAULT_BASE_ADDRESS,
                 enable_addr = ADDR_ENABLE,
                 switch_addr = ADDR_SWITCH,
                 ina_even_addr = ADDR_INA_EVEN,
                 ina_odd_addr = ADDR_INA_ODD,
                 temp_addr = ADDR_TEMP,
                 ntc_addr = ADDR_NTC,
                 pot_addr = ADDR_POT,
                 main = None):
        """Create an lv_power instance.

        device_ip / udp_port : SiTCP target (FPGA) used by every device and by
                       the board register.
        base_address : FPGA I2C-core base address used by every device.
        enable_addr  : 7-bit address of the tcal6416 driving the power enables.
        switch_addr  : 7-bit address of the tca9548a in front of the monitors.
        ina_even_addr / ina_odd_addr : 7-bit addresses of the two INA745 that
                       share one switch channel.
        temp_addr    : 7-bit address of the TMP4718.
        ntc_addr     : 7-bit address of the ADS1114 reading the NTC divider.
        pot_addr     : 7-bit address of the TPL0102-100 setting the output
                       voltages, one per switch channel behind the switch.
        main         : board register object used for stage 1 (created when
                       None), so a caller can share one RBCP connection.

        Nothing is programmed here: the enable pins and the NTC ADC are set up
        by init(), which a caller has to run once before switching or reading
        anything.
        """
        self.power  = tcal6416(device_ip, udp_port, base_address, enable_addr)
        self.switch = tca9548a(device_ip, udp_port, base_address, switch_addr)
        self.temp   = tmp4718(device_ip, udp_port, base_address, temp_addr)
        self.ntc    = ads1114(device_ip, udp_port, base_address, ntc_addr)
        self.base_address  = base_address
        self.ina_even_addr = ina_even_addr
        self.ina_odd_addr  = ina_odd_addr
        self.ntc_addr      = ntc_addr
        self.pot_addr      = pot_addr
        self.device_ip     = device_ip
        self.udp_port      = udp_port
        self._ina = {}                       # address -> ina745 instance
        self._pot = {}                       # address -> tpl0102_100 instance
        self.main = main if main is not None else reg(device_ip, udp_port)

    # ------------------------------------------------------------------
    # bring-up: stage 1, enable pins, limits, latches and the NTC monitor
    # ------------------------------------------------------------------
    def init(self):
        """Bring the low-voltage side to its initial state.

        It

          1. arms every stage-2 channel at the maximum over-current limit
             (OC_LIMIT_MAX_A) in latched mode, so a limit only trips on a real
             fault and the trip stays visible until it is read - the scripts
             re-arm the limit they want before switching a rail on,
          2. configures the NTC ADC (config_ntc()) and drops a latched interrupt
             of it (clear_ntc_int()), so the over-temperature line starts
             released rather than asserted by an earlier run,
          3. switches stage 1 off (power_off_all(), the lv register 0x0b), so
             nothing downstream is powered. Both lv bits are written, so the
             automatic power off on over-current is cleared as well,
          4. configures the 16 enable pins as open-drain outputs holding every
             module off,
          5. masks every expander interrupt (registers 0x4A/0x4B) and keeps the
             expander input latch off (registers 0x44/0x45), because the latch
             of an over-current is the monitor's own (ALATCH, see
             write_oc_limit) - one latch for the whole design, and it survives a
             rail being switched off. All rails are off, and an off rail drives
             its line low through its own enable, so its interrupt is masked here
             and only unmasked by set_sub() once a rail is up (an unmasked pin in
             input mode is what would otherwise let the INT pin - wired to the
             FPGA as lv_alm - fire on that); one read of the input ports is done
             here so nothing is left asserted,
          6. clears what is latched: the per-module over-current events held by
             the INA745 monitors (clear_oc_interrupt(), the modules that had one
             are printed) and the board flags of mod_sta_lch - that register is
             read once, because it is read-to-clear and a single read consumes
             every flag, so the low-voltage over-current, the over-temperature
             and the high-voltage alarm are all reported from the same value.

        Order matters for the enable pins: the output stage is switched to
        open-drain first (register 0x4F, ODEN0/ODEN1) and only then are the pins
        turned into outputs, as the datasheet asks for (7.6.3), with the OFF
        value loaded into the output latch before the direction registers are
        cleared. The tcal6416 powers up with every pin an input, so nothing
        drives the module sub power before this, and clearing the directions
        first would release the pins to their 0xFF power-up value which, with
        the external pull-ups, switches all modules on. An open-drain enable
        cannot drive high: the ON value (bit = 1) releases the line, so every
        enable needs its pull-up, while the OFF value (bit = 0) actively pulls
        it low.

        This is a bring-up call, and it is destructive: it switches every module
        off, including one that was on, so it must not be used on a running
        board or by a monitor. It is safe to call again (e.g. after a device
        reset), and __init__ only creates the devices - a caller has to run this
        once before switching anything, which the scripts do right after
        constructing the object."""
        for module in range(MODULE_COUNT):      # 1. arm every channel at MAX
            self.write_oc_limit(module, OC_LIMIT_MAX_A)

        self.config_ntc()                       # 2. NTC ADC
        self.clear_ntc_int()                    #    drop a latched NTC interrupt

        self.power_off_all()                    # 3. stage 1: main power OFF
        for port in (0, 1):                     # 4. stage 2: OFF and outputs
            self.power.write_output_config(port, True)  # open drain
            self.power.write_output(port, 0x00)         # latch = sub power OFF
            self.power.write_config(port, 0x00)         # pins become outputs

        for port in (0, 1):                     # 5. alert lines -> INT/FPGA
            self.power.write_interrupt_mask(port, 0xFF)  # masked: every rail off
            self.power.write_input_latch(port, 0x00)     # no expander latch
            self.power.read_input(port, 0xFF)            # clear a pending INT

        tripped = [m for m in range(MODULE_COUNT)   # 6. drop the latches
                   if self.clear_oc_interrupt(m)]
        if tripped:
            print("lv_power: cleared over-current events on modules %s"
                  % tripped)
        latched = self.main.read_mod_sta_latch()    # read-to-clear: every flag
        if latched["lv_alm"]:
            print("lv_power: cleared the latched low-voltage over-current alarm")
        if latched["temp_alm"]:
            print("lv_power: cleared the latched over-temperature alarm")
        if latched["hv_alm"]:                       # same register, same read
            print("lv_power: cleared the latched high-voltage over-current alarm")

    # ------------------------------------------------------------------
    # module -> hardware mapping
    # ------------------------------------------------------------------
    @staticmethod
    def check_module(module):
        """Raise ValueError unless module is a valid module number (0..15)."""
        if not (MODULE_MIN <= module <= MODULE_MAX):
            raise ValueError("module must be in %d..%d, got %r"
                             % (MODULE_MIN, MODULE_MAX, module))
        return module

    @staticmethod
    def port_pin(module):
        """Return (port, pin) of the enable expander bit for a module."""
        lv_power.check_module(module)
        return module // 8, module % 8

    @staticmethod
    def channel(module):
        """Return the tca9548a channel carrying a module's power monitor."""
        lv_power.check_module(module)
        return module // 2

    def ina_addr(self, module):
        """Return the 7-bit address of the INA745 monitoring a module."""
        lv_power.check_module(module)
        return self.ina_even_addr if module % 2 == 0 else self.ina_odd_addr

    def ina(self, module):
        """Return the (cached) INA745 instance monitoring a module."""
        addr = self.ina_addr(module)
        if addr not in self._ina:
            self._ina[addr] = ina745(self.device_ip, self.udp_port,
                                     self.base_address, addr)
        return self._ina[addr]

    # ------------------------------------------------------------------
    # stage 1: main power (board lv register, 0x0b)
    # ------------------------------------------------------------------
    def set_main(self, on, auto_off = 0):
        """Switch the main power (stage 1) on (on = 1) or off (on = 0).

        auto_off : 0 = normal, 1 = auto power OFF on over-temperature."""
        return self.main.set_lv(on, auto_off)

    def get_main(self):
        """Return (enable, auto_off) of the lv register as 0/1 values."""
        value = self.main.read_lv()
        return (1 if value & MAIN_ON else 0, 1 if value & MAIN_AUTO_OFF else 0)

    def main_ready(self):
        """Return True when the main power (stage 1) is on, i.e. when stage-2
        sub-power switching is allowed."""
        return bool(self.get_main()[0])

    def _require_main(self):
        """Refuse a stage-2 operation while the main power is off."""
        if not self.get_main()[0]:
            raise RuntimeError(
                "main power (stage 1) is OFF - module sub-power switching has "
                "no effect; call set_main(1) or power_on(module) first")

    # ------------------------------------------------------------------
    # module alarms (mod_sta 0x09 / mod_sta_lch 0x0a)
    # ------------------------------------------------------------------
    def ot_alarm(self):
        """Return True while the over-temperature alarm is active (mod_sta bit
        0, register 0x09)."""
        return self.main.read_mod_sta()["temp_alm"]

    def ot_alarm_latch(self):
        """Return True when an over-temperature alarm has been latched, and
        clear it: mod_sta_lch (register 0x0a) is read-to-clear, so one call
        consumes every latched module status flag - the over-current one
        included. The per-module events held by the INA745 monitors are a
        separate latch, see clear_oc_interrupt()."""
        return self.main.read_mod_sta_latch()["temp_alm"]

    def lv_alarm(self):
        """Return True while the low-voltage over-current alarm is active
        (mod_sta bit 1, register 0x09)."""
        return self.main.read_mod_sta()["lv_alm"]

    def lv_alarm_latch(self):
        """Return True when a low-voltage over-current alarm has been latched,
        and clear it: mod_sta_lch (register 0x0a) is read-to-clear, so one call
        consumes every latched module status flag. The per-module events held by
        the INA745 monitors are a separate latch - see clear_oc_interrupt()."""
        return self.main.read_mod_sta_latch()["lv_alm"]

    # ------------------------------------------------------------------
    # stage 2: module sub power (tcal6416 outputs, 1 = power ON)
    # ------------------------------------------------------------------
    def set_sub(self, module, on):
        """Switch one module's sub power (stage 2) on (on = 1) or off (on = 0).

        Requires the main power (stage 1) to be on, otherwise RuntimeError.

        The enable line of a module is wired-AND with the over-current output of
        its monitor (both open drain), so the pin drives the line low while the
        module is off (output mode) and is released to its pull-up while it is
        on (input mode, which is what lets the expander raise its INT - wired to
        the FPGA as lv_alm - when the monitor pulls the line low).

        The pin's interrupt is masked for the whole transition, because the
        level and direction changes themselves look like an edge to the expander:
        it is armed again only after the rail is up and the switch glitch has
        been read away, and it stays masked while the rail is off."""
        self._require_main()
        port, pin = self.port_pin(module)
        bit = 1 << pin
        value = self.power.read_output(port)
        # the module number is also the flat pin of the 16-bit expander
        # (port = module // 8, bit = module % 8), which is the numbering the
        # pin-wise helpers set_pin_interrupt()/set_pin_direction() take
        self.power.set_pin_interrupt(module, False)  # mask before the change
        if on:
            value |= bit
            self.power.write_output(port, value)     # release the line
            self.power.set_pin_direction(module, True)   # input: INT can fire
            self.power.read_input(port, 0xFF)        # drop the mode-switch glitch
            self.power.set_pin_interrupt(module, True)   # arm once the rail is up
        else:
            value &= ~bit
            self.power.write_output(port, value)     # latch = sub power OFF
            self.power.set_pin_direction(module, False)  # output: drive it low
        return value

    def set_sub_all(self, on, delay = POWER_ON_DELAY):
        """Switch every module's sub power on (on = 1) or off (on = 0).

        Requires the main power (stage 1) to be on, otherwise RuntimeError.

        Switching on is ramped: the modules are enabled one after the other
        with `delay` seconds between them, so the inrush current of the common
        supply stays at one module instead of 16 (delay = 0 enables them all
        without a wait). Switching off needs no ramp - no surge - so it masks
        every interrupt first and then clears the whole latch in one write; the
        pins are made outputs with it, because a rail that is on has its pin in
        input mode (see set_sub) and only an output drives the line low."""
        self._require_main()
        if not on:
            for port in (0, 1):
                self.power.write_interrupt_mask(port, 0xFF)  # mask: no INT on it
                self.power.write_output(port, 0x00)          # latch all OFF
                self.power.write_config(port, 0x00)          # outputs drive low
            return 0x00
        for module in range(MODULE_COUNT):
            self.set_sub(module, POWER_ON)
            if delay > 0 and module != MODULE_MAX:
                time.sleep(delay)
        return 0xFF

    def get_sub(self, module):
        """Return the driven sub-power state (0/1) of a module, i.e. what
        set_sub writes to the enable bit (stage 2)."""
        port, pin = self.port_pin(module)
        return 1 if self.power.read_output(port) & (1 << pin) else 0

    # ------------------------------------------------------------------
    # two-stage sequences
    # ------------------------------------------------------------------
    def power_on(self, module, auto_off = 0):
        """Sequence both stages for one module: main power on, then the bit.

        Before returning, the interrupt of that rail is enabled on the expander
        (its mask bit cleared: 0 = unmasked, so the INT pin reaches the FPGA as
        lv_alm), so an over-current of a rail that is on is reported. Breaking
        the limit down to the register level is in set_sub(), which masks the
        pin around the transition and arms it once the rail is up; the step here
        makes that guarantee hold for this call as well."""
        lv_power.check_module(module)
        self.set_main(POWER_ON, auto_off)
        value = self.set_sub(module, POWER_ON)
        self.power.set_pin_interrupt(module, True)   # INT of that rail enabled
        return value

    def power_off(self, module):
        """Switch one module's sub power off; stage 1 is left on."""
        lv_power.check_module(module)
        return self.set_sub(module, POWER_OFF)

    def power_on_all(self, auto_off = 0, delay = POWER_ON_DELAY):
        """Sequence both stages for every module: main power on, a settle pause,
        then the module sub powers ramped one by one (see set_sub_all).

        delay : seconds between two consecutive lv power-ons (0 = switch
                them all on at once).

        As in power_on(), every rail's interrupt is enabled before this returns,
        so the expander can pass an over-current of any rail on to the FPGA
        (lv_alm)."""
        self.set_main(POWER_ON, auto_off)
        if delay > 0:
            time.sleep(delay)               # let the main rail settle first
        value = self.set_sub_all(POWER_ON, delay)
        for module in range(MODULE_COUNT):   # INT of every rail enabled
            self.power.set_pin_interrupt(module, True)
        return value

    def power_off_all(self, auto_off = 0):
        """Switch both stages off: the 16 sub powers first, then the main power.

        The stage-2 write is only allowed while stage 1 is on, so it is skipped
        when the main power is already off (the enables are then whatever they
        were, and init() is what leaves every one of them off)."""
        if self.get_main()[0]:
            self.set_sub_all(POWER_OFF)
        return self.set_main(POWER_OFF, auto_off)

    # ------------------------------------------------------------------
    # module output voltage (tpl0102_100 pot behind the switch channel)
    # ------------------------------------------------------------------
    @staticmethod
    def pot_channel(module):
        """Return the potentiometer of the TPL0102 that sets a module's output
        voltage: pot A for the even module of a switch channel, pot B for the
        odd module next to it."""
        lv_power.check_module(module)
        return POT_A if module % 2 == 0 else POT_B

    def pot(self):
        """Return the (cached) TPL0102-100 instance that sets the module output
        voltages of a switch channel.

        The chip sits behind the tca9548a, so the channel has to be selected
        (see select()) before it is accessed; the same address is used on every
        channel because the switch isolates them, so one instance serves every
        module - only the selected channel decides which chip is reached."""
        addr = self.pot_addr
        if addr not in self._pot:
            self._pot[addr] = tpl0102_100(self.device_ip, self.udp_port,
                                          self.base_address, addr)
        return self._pot[addr]

    def set_potentiometer(self, module, voltage, store = False):
        """Set the output voltage of a module and return the value reached.

        The converter regulates its feedback node to POT_VREF_V = 1.2 V, so
        with the potentiometer as the upper resistor R1 and the fixed lower
        resistor R2 = POT_R2_OHM:

            voltage = POT_VREF_V * (R1 + R2) / R2
            R1      = POT_R2_OHM * (voltage / POT_VREF_V - 1)

        R1 is written as a wiper-to-L resistance of the module's pot, which
        quantises it to the 256 taps (R_TOT / 256 = 390.6 ohm), so the reached
        voltage differs slightly from the request - 3.300 V, for instance,
        lands on 3.304 V - and that reached value is what is returned.
        Voltages the divider cannot reach (from POT_V_MIN_V to POT_V_MAX_V)
        raise ValueError instead of silently programming something else.

        store : False (default) leaves the setting in the volatile register of
                the pot, so it is lost at power-down and the pot comes back at
                its stored (factory mid-scale) value, which gives about 2.40 V;
                True writes the non-volatile register as well, so the voltage is
                recalled after power-up, at the cost of an EEPROM write cycle
                (tWC = 20 ms, 100k cycle endurance) - use it for a value that
                has to be permanent, not for every adjustment."""
        lv_power.check_module(module)
        if voltage < POT_VREF_V:
            raise ValueError("output voltage cannot go below the %g V reference, "
                             "got %r" % (POT_VREF_V, voltage))
        r1 = POT_R2_OHM * (voltage / POT_VREF_V - 1.0)
        if r1 > POT_R1_MAX_OHM:
            raise ValueError("output voltage %.4f V needs R1 = %.1f ohm, above "
                             "the pot maximum %.1f ohm (highest settable "
                             "voltage is %.4f V)"
                             % (voltage, r1, POT_R1_MAX_OHM, POT_V_MAX_V))
        self.select(module)                     # the pot is behind the channel
        position = self.pot().write_resistance(r1, pot = self.pot_channel(module),
                                               to_low = True, store = store)
        reached = POT_VREF_V * (1.0 + (POT_R_TOT_OHM * position / POT_NUM_TAPS)
                                / POT_R2_OHM)
        return reached

    # ------------------------------------------------------------------
    # module over-current protection (ina745 current over-limit, COL)
    # ------------------------------------------------------------------
    def write_oc_limit(self, module, current):
        """Set the over-current threshold of a module and return the value
        actually programmed, in amperes.

        The threshold is written to the Current Over-Limit register (COL,
        address 0Ch) of that module's INA745: a 16-bit two's complement value
        with 1.2 mA/LSB. The device sets its CURRENTOL diagnostic flag when the
        measured current exceeds it (datasheet 7.1.10 and 7.1.18). The channel
        of the module's monitor pair is selected first, as for every INA745
        access.

        The monitor is switched to latched alert mode (ALATCH = 1 in DIAG_ALRT,
        0Bh), so an over-current keeps the CURRENTOL flag and holds its ALERT
        output - and through the wired-AND line the expander input - low until
        clear_oc_interrupt() reads DIAG_ALRT. That is the only latch used: the
        expander input latch stays disabled (see init()), so the event is held
        by the monitor that saw it and a per-module trip survives a rail being
        switched off. Arming the limit reads DIAG_ALRT on the way, which clears
        any event that was pending from before, so a fresh limit starts from a
        clean state.

        current : threshold in amperes, positive. A value above OC_LIMIT_MAX_A
                  (39.3204 A, the 16-bit maximum 32767 at 1.2 mA/LSB, which is
                  also the reset value of COL) is not reachable: it is reported
                  on stdout and the maximum is programmed instead. The
                  programmed value differs from the request by at most half an
                  LSB (0.6 mA)."""
        lv_power.check_module(module)
        code = int(round(current / LSB_CURRENT))
        if code > OC_LIMIT_MAX_CODE:
            print("lv_power: over-current limit %.4f A for module %d is "
                  "above the COL maximum %.4f A (code %d), using the maximum"
                  % (current, module, OC_LIMIT_MAX_A, OC_LIMIT_MAX_CODE))
            code = OC_LIMIT_MAX_CODE
        self.select(module)                 # the monitor is behind the channel
        ina = self.ina(module)
        ina.write_col(code)
        ina.set_alert_latch(True)           # latched: held until read back
        return code * LSB_CURRENT

    def clear_oc_interrupt(self, module):
        """Clear a latched over-current event of a module and report whether one
        was pending.

        The flags held by ALATCH are released by reading DIAG_ALRT (0Bh), which
        is what this does: the CURRENTOL flag and the ALERT pin return to idle
        (datasheet 7.1.9). write_oc_limit() arms a module in latched mode, so a
        trip stays visible until this call - and reading clears every latched
        flag of that monitor, not only the over-current one, so the value is
        captured before it is cleared.

        Returns True when an over-current event was latched, False otherwise.
        If the module is still drawing more than its limit, the event is raised
        again by the next conversion."""
        lv_power.check_module(module)
        self.select(module)                 # the monitor is behind the channel
        status = self.ina(module).read_diag_alert()
        return bool(status & DIAG_CURRENTOL)

    # ------------------------------------------------------------------
    # monitoring (channel selected before every access)
    # ------------------------------------------------------------------
    def select(self, module):
        """Select the switch channel of a module's power monitor."""
        channel = self.channel(module)
        self.switch.select_channel(channel)
        return channel

    def read_bus_voltage(self, module):
        """Read a module's power monitor bus voltage in volts."""
        self.select(module)
        return self.ina(module).read_bus_voltage()

    def read_current(self, module):
        """Read a module's power monitor current in amperes."""
        self.select(module)
        return self.ina(module).read_current()

    def read_lv_power(self, module):
        """Read a module's power in watts (from the INA745 POWER register)."""
        self.select(module)
        return self.ina(module).read_power()

    def read_monitor_temp(self, module):
        """Read the local temperature of a module's INA745 in degC."""
        self.select(module)
        return self.ina(module).read_die_temp()

    def read_module_temp(self):
        """Read the module temperature from the TMP4718 remote channel.

        Returns None when the remote diode is reported disconnected."""
        return self.temp.read_remote_temp()

    def read_board_temp(self):
        """Read the board temperature from the TMP4718 local channel."""
        return self.temp.read_local_temp()

    # ------------------------------------------------------------------
    # NTC thermistor (shared ADS1114, no switch channel)
    # ------------------------------------------------------------------
    def _read_ntc_raw(self):
        """Read the NTC channel once and return (code, fsr, volt): the 16-bit
        conversion code, the full-scale voltage of the PGA configured in the
        ADS1114, and the voltage it corresponds to."""
        pga = (self.ntc.read_config() & CFG_PGA) >> 9
        fsr = PGA_FSR_V[pga]
        code = self.ntc.read_conversion()
        return code, fsr, code * fsr / 32768.0

    def read_ntc_voltage(self):
        """Return the ADS1114 voltage of the NTC divider, in volts.

        This is the measured quantity; the resistance and the temperature are
        derived from it with the excitation voltage of the divider
        (NTC_VREF_V), not with the full-scale voltage of the PGA."""
        code, fsr, volt = self._read_ntc_raw()
        return volt

    def _ntc_top(self, fsr):
        """Return the divider voltage at or above which the input counts as
        unconnected: NTC_OPEN_FRACTION of the top of the divider, where the top
        is the smaller of the excitation voltage and the PGA full scale, since
        an input above the full scale is clipped to it."""
        return NTC_OPEN_FRACTION * min(NTC_VREF_V, fsr)

    def ntc_connected(self):
        """Return False when no module is connected, i.e. when the NTC input
        reads at the top of the divider (NTC_OPEN_FRACTION of it) because an
        unplugged thermistor leaves the input pulled up to the supply."""
        code, fsr, volt = self._read_ntc_raw()
        return volt < self._ntc_top(fsr)

    def read_ntc_resistance(self):
        """Return the NTC resistance in ohm from the divider voltage:

            R_NTC = NTC_R_SERIES * V_NTC / (NTC_VREF_V - V_NTC)

        Returns None when the reading carries no resistance: at or below zero
        volts (shorted input) or at the top of the divider, which means no
        module is connected (see ntc_connected). The one conversion this reads
        decides both, so the two tests cannot disagree about it."""
        code, fsr, volt = self._read_ntc_raw()
        if volt <= 0.0 or volt >= NTC_VREF_V:
            return None
        if volt >= self._ntc_top(fsr):
            return None
        return NTC_R_SERIES * volt / (NTC_VREF_V - volt)

    def clear_ntc_int(self):
        """Release a latched interrupt of the NTC ADS1114 and return what the
        conversion register held.

        The over-temperature comparator is latched (NTC_ALERT_LATCH), so the
        pin stays asserted - also after the module has cooled back down - until
        the Conversion register is read, which is what this does (see
        ads1114.clear_int()). Reading the temperature, read_ntc_temp(), releases
        it as well, so this is for a bring-up that wants to leave the pin
        released."""
        return self.ntc.clear_int()

    def read_ntc_temp(self):
        """Return the NTC temperature in degC from the ADS1114 (Beta
        equation), or None when the input is saturated or reads at the top of
        the divider, i.e. when no module is connected."""
        resistance = self.read_ntc_resistance()
        if resistance is None or resistance <= 0.0:
            return None
        return (1.0 / ((1.0 / NTC_T0_K)
                       + (1.0 / NTC_BETA) * math.log(resistance / NTC_R0))
                - 273.15)

    # ------------------------------------------------------------------
    # ADS1114 configuration (continuous conversion + over-temperature alert)
    # ------------------------------------------------------------------
    def config_ntc(self, temp = NTC_ALERT_TEMP,
                   window = NTC_ALERT_WINDOW,
                   hysteresis = None,
                   latching = NTC_ALERT_LATCH,
                   queue = NTC_ALERT_QUEUE):
        """Configure the ADS1114 for continuous conversion and its
        over-temperature alert, and return (high_code, low_code).

        The chip is the same ADS1114 the high-voltage monitor uses and is set
        up the same way - an explicit PGA range and data rate, then continuous
        conversion and the comparator - so neither converter depends on its
        reset value:

        * PGA = NTC_PGA (+/-4.096 V): the reset +/-2.048 V is narrower than the
          NTC divider, which delivers 0..NTC_VREF_V (3.3 V), so it would clip a
          thermistor below about -34 degC and such a clipped reading is
          indistinguishable from an unconnected module - see ntc_connected().
        * DR = NTC_DATA_RATE (128 samples/s, the reset value made explicit).
        * MODE = continuous-conversion (MODE = 0b), so the device keeps
          converting and the comparator can assert at any time; the conversion
          register then always holds a recent result and read_ntc_temp() needs
          no start/poll.
        * window = True: COMP_MODE = window comparator (1b), active low
          (COMP_POL = 0b). The pin asserts when the data exceed Hi_thresh OR
          fall below Lo_thresh, and since the NTC reading decreases with
          temperature, Lo_thresh gets the code of `temp`: the pin asserts as
          soon as the module is hotter than `temp` degC. Hi_thresh is set to
          NTC_ALERT_TOP_CODE (0x7FFF, the largest code the ADC can produce), so
          the upper side never trips - including on an unconnected module,
          whose near-full-scale reading stays inside the window. There is no
          hysteresis in a window comparator: the pin releases as soon as the
          reading climbs back above Lo_thresh, i.e. at `temp` itself.
        * window = False: COMP_MODE = traditional comparator (0b), which
          asserts while the data are ABOVE Hi_thresh and releases only below
          Lo_thresh. With this divider the reading rises as the module gets
          colder, so this mode alerts on the COLD side: Hi_thresh gets the code
          of `temp` (assert once the module is colder than that), Lo_thresh the
          code of `temp + hysteresis` (default NTC_HYST_TEMP, a warmer
          temperature, i.e. a LOWER code), and the pin releases only once the
          module has warmed past `temp + hysteresis`. The codes therefore
          satisfy Lo_thresh < Hi_thresh and the band in between is the
          hysteresis.
        * COMP_LAT = latching: the asserted pin stays latched until conversion
          data are read, so an over-temperature that has already passed is not
          lost unnoticed; COMP_QUE = the number of successive conversions
          (0/1/2 -> 1/2/4) beyond the thresholds required to assert, which
          filters a single noisy sample.

        Lo_thresh bit15 = 0 and a Hi_thresh at 0x7FFF keep ALERT/RDY an alert
        output; it would become a conversion-ready output only with Hi_thresh
        bit15 = 1 and Lo_thresh bit15 = 0.
        """
        # bring the converter up first, so the threshold codes are computed for
        # the range that is actually configured - and the range that is read
        # back below is then the one just written
        self.ntc.set_pga(NTC_PGA)
        self.ntc.set_data_rate(NTC_DATA_RATE)
        # the threshold codes are compared with the conversion register, whose
        # LSB is fsr / 32768: the full scale of the configured PGA, not the
        # excitation voltage of the divider
        fsr = PGA_FSR_V[(self.ntc.read_config() & CFG_PGA) >> 9]
        if window:
            high_code = NTC_ALERT_TOP_CODE
            low_code  = ntc_threshold_code(temp, fsr)
        else:
            if hysteresis is None:
                hysteresis = NTC_HYST_TEMP
            high_code = ntc_threshold_code(temp, fsr)
            low_code  = ntc_threshold_code(temp + hysteresis, fsr)
        self.ntc.set_mode(single_shot = False)
        self.ntc.set_comparator(True, mode = 1 if window else 0, polarity = 0,
                                latching = latching, queue = queue)
        self.ntc.write_hi_thresh(high_code)
        self.ntc.write_lo_thresh(low_code)
        return high_code, low_code


    # ------------------------------------------------------------------
    # summaries
    # ------------------------------------------------------------------
    def read_module(self, module):
        """Read one module completely: returns a dict with the power state and
        the monitor values. The switch channel is selected once for all the
        monitor reads.

        oc is the over-current status of the module, read from the expander input
        pin that is wired-AND with its enable line: the enable and the INA745
        over-current output (both open drain, the latter active low) share one
        net, so with the rail on the line is held up by the pull-up and 0 means
        that module reports over-current (see OC_ACTIVE_LOW). It is therefore
        only meaningful while the module is switched on - with the rail off the
        enable itself pulls the line low - so oc is reported as 0 in that case
        (and the expander INT to the FPGA only fires with the rail on, for the
        same reason). A trip also holds the line low after the current is gone,
        because the monitor latches it (ALATCH, see write_oc_limit) until
        clear_oc_interrupt() reads it back - so this read does not need the
        INA745 diagnostic register, whose read would clear the latched event.
        oc_limit is the threshold armed in the monitor's COL register (see
        write_oc_limit), in amperes; the reset value is OC_LIMIT_MAX_A."""
        lv_power.check_module(module)
        self.select(module)
        ina = self.ina(module)
        port, pin = self.port_pin(module)
        power = self.get_sub(module)
        raw = 1 if self.power.read_input(port, 0xFF) & (1 << pin) else 0
        active = 0 if OC_ACTIVE_LOW else 1
        return {
            "module":    module,
            "channel":   self.channel(module),
            "power":     power,
            "voltage":   ina.read_bus_voltage(),
            "current":   ina.read_current(),
            "power_w":   ina.read_power(),
            "temp_local": ina.read_die_temp(),
            "oc":        1 if (raw == active and power) else 0,
            "oc_limit":  ina.read_col() * LSB_CURRENT,
        }

    def read_all(self):
        """Read every module: returns a list of dicts (see read_module)."""
        return [self.read_module(m) for m in range(MODULE_COUNT)]

    def print_status(self, marker = None):
        """Print the main power state and the monitor values of all modules.

        The table is laid out from STATUS_COLUMNS: a row with the names of the
        columns - module, ON, Vout, OC, OC_LIMIT, Iout, Pout, Tlocal - a row
        saying what each column holds (No., Y/N, V, Y/N, A, A, W, C) and a rule
        between the header and the numbers, so the fields line up by
        construction. A summary closes the table with how many modules are
        switched on, which ones report over-current and the total output power.

        marker : optional callable (module, column, value, text) -> text, called
        for every cell with its formatted text so a caller can decorate the
        values it wants to point out (lv_monitor.py uses it to highlight the
        values that changed since the previous refresh). The default prints the
        plain text, and this module stays free of any terminal escape codes.

        ON is the driven sub-power state of the module (stage 2), OC the
        over-current status read from the enable expander inputs (Y = the
        module is switched on and reports over-current; those open-drain lines
        are active low), OC_LIMIT/A the threshold armed in the monitor's COL
        register (see write_oc_limit), and Vout / Iout / Pout / Tlocal come
        from the module's INA745."""
        rule = "  ".join("-" * width for name, unit, width, fmt in STATUS_COLUMNS)
        enable, auto_off = self.get_main()
        print("main power (stage 1): enable=%d  ot_auto_off=%d  "
              "T_board(local)/C=%.2f"
              % (enable, auto_off, self.read_board_temp()))
        print("main power (stage 2):")
        print("  ".join("%*s" % (width, name)
                        for name, unit, width, fmt in STATUS_COLUMNS))
        print("  ".join("%*s" % (width, unit)
                        for name, unit, width, fmt in STATUS_COLUMNS))
        print(rule)
        on, total, tripped = 0, 0.0, []
        for module in range(MODULE_COUNT):
            data = self.read_module(module)
            oc = data["oc"] and data["power"]
            on += 1 if data["power"] else 0
            total += data["power_w"]
            if oc:
                tripped.append(module)
            values = (data["module"],
                      "Y" if data["power"] else "N",
                      data["voltage"],
                      "Y" if oc else "N",
                      data["oc_limit"],
                      data["current"], data["power_w"],
                      data["temp_local"])
            cells = []
            for (name, unit, width, fmt), value in zip(STATUS_COLUMNS, values):
                text = fmt % value
                if marker is not None:
                    text = marker(data["module"], name, value, text)
                cells.append(text)
            print("  ".join(cells))
        print(rule)
        print("modules on: %d/%d   over-current: %s   Pout total: %.3f W"
              % (on, MODULE_COUNT,
                 ("modules " + ", ".join(str(m) for m in tripped)) if tripped
                 else "none", total))
        print("T_module(remote)/C=%s   NTC(remote)/C=%s"
              % (_fmt(self.read_module_temp(), "open"),
                 _fmt(self.read_ntc_temp(), "open")))
        print("")
