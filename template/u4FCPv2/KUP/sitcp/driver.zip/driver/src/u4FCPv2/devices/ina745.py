#!/usr/bin/python
# This is ina745.py
# TI INA745A/INA745B 40V, 16-bit digital power monitor (EZShunt) driver
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
# based on INA745x datasheet (TI SBOSAC3)

from ..bus.i2c import i2c

# Debug switches, independent of each other:
#   DEBUG     = 1 -> print high-level per-operation info
#   DEBUG_LOW_LEVEL = 1 -> print low-level register/bus transactions
# Set either to 0 to silence that level only.
DEBUG            = 0
DEBUG_LOW_LEVEL  = 0


def _debug(msg):
    """Print a high-level debug message when DEBUG is enabled."""
    if DEBUG:
        print("[ina745] " + msg)


def _debug_low_level(msg):
    """Print a low-level debug message when DEBUG_LOW_LEVEL is enabled."""
    if DEBUG_LOW_LEVEL:
        print("[ina745-low-level] " + msg)


# ---------------------------------------------------------------------------
# Device address (datasheet Table 6-2). Pins A1/A0 select one of 16 addresses:
#   A1=A0=GND -> 0x40 (default) ... A1=A0=SCL -> 0x4F
# The 8-bit write byte on the bus is (addr << 1), e.g. 0x80 at 0x40.
# ---------------------------------------------------------------------------
INA745_ADDR_DEFAULT = 0b1000_000  # 7-bit address 0x40, A1 = A0 = GND


def addr7_to_addr8(addr7):
    """Convert a 7-bit target address to the 8-bit address byte sent on the
    bus with the R/W bit cleared (0x80 for INA745 at 0x40)."""
    return ((addr7 & 0x7F) << 1) & 0xFE


# ---------------------------------------------------------------------------
# Register map (datasheet Table 7-1). Registers wider than 16 bits (POWER,
# ENERGY, CHARGE) are read as a burst of 3 or 5 bytes, MSB first, after the
# register pointer is set. All register bytes are sent MSB first.
# ---------------------------------------------------------------------------
REG_CONFIG          = 0x00  # Configuration, 16-bit, R/W
REG_ADC_CONFIG      = 0x01  # ADC configuration, 16-bit, R/W
REG_VBUS            = 0x05  # Bus voltage measurement, 16-bit, R
REG_DIETEMP         = 0x06  # Die temperature measurement, 16-bit, R
REG_CURRENT         = 0x07  # Current result, 16-bit, R
REG_POWER           = 0x08  # Power result, 24-bit, R
REG_ENERGY          = 0x09  # Energy result, 40-bit, R
REG_CHARGE          = 0x0A  # Charge result, 40-bit, R
REG_DIAG_ALRT       = 0x0B  # Diagnostic flags and alert, 16-bit, R/W
REG_COL             = 0x0C  # Current over-limit threshold, R/W
REG_CUL             = 0x0D  # Current under-limit threshold, R/W
REG_BOVL            = 0x0E  # Bus overvoltage threshold, R/W
REG_BUVL            = 0x0F  # Bus undervoltage threshold, R/W
REG_TEMP_LIMIT      = 0x10  # Temperature over-limit threshold, R/W
REG_PWR_LIMIT       = 0x11  # Power over-limit threshold, R/W
REG_MANUFACTURER_ID = 0x3E  # Manufacturer ID, 16-bit, R (0x5449 = "TI")

# --- CONFIG register (Table 7-3) bit masks ---------------------------------
CFG_RST    = 0x8000  # system reset, self-clearing
CFG_RSTACC = 0x4000  # reset ENERGY and CHARGE accumulators
CFG_CONVDLY_MASK = 0x3FC0  # bits 13:6, initial conversion delay in 2ms steps

# --- ADC_CONFIG register (Table 7-4) bit masks -----------------------------
ADC_MODE_MASK   = 0xF000  # bits 15:12
ADC_VBUSCT_MASK = 0x0E00  # bits 11:9 bus voltage conversion time
ADC_VSENCT_MASK = 0x01C0  # bits 8:6 shunt voltage conversion time
ADC_TCT_MASK    = 0x0038  # bits 5:3 temperature conversion time
ADC_AVG_MASK    = 0x0007  # bits 2:0 averaging

# ADC conversion mode values (bits 15:12)
MODE_SHUTDOWN                    = 0x0
MODE_TRIG_BUS                    = 0x1
MODE_TRIG_TEMP                   = 0x4
MODE_TRIG_TEMP_BUS               = 0x5
MODE_TRIG_TEMP_CURRENT           = 0x6
MODE_TRIG_TEMP_CURRENT_BUS       = 0x7
MODE_CONT_BUS                    = 0x9
MODE_CONT_TEMP                   = 0xC
MODE_CONT_TEMP_BUS               = 0xD
MODE_CONT_TEMP_CURRENT           = 0xE
MODE_CONT_TEMP_CURRENT_BUS       = 0xF  # default

# Conversion time codes (VBUSCT/VSENCT/TCT): 0..7 -> 50us..4120us
CONVTIME_US = {0: 50, 1: 84, 2: 150, 3: 280, 4: 540, 5: 1052,
               6: 2074, 7: 4120}

# Averaging codes (AVG bits 2:0): 0..7 -> 1..1024
AVG_SAMPLES = {0: 1, 1: 4, 2: 16, 3: 64, 4: 128, 5: 256, 6: 512, 7: 1024}

# --- DIAG_ALRT register (Table 7-11) bit masks -----------------------------
DIAG_ALATCH     = 0x8000  # alert latch (transparent vs latched)
DIAG_CNVR       = 0x4000  # enable conversion-ready flag on ALERT pin
DIAG_SLOWALERT  = 0x2000  # alert on averaged value
DIAG_APOL       = 0x1000  # alert polarity (active-low vs active-high)
DIAG_ENERGYOF   = 0x0800  # energy overflow
DIAG_CHARGEOF   = 0x0400  # charge overflow
DIAG_MATHOF     = 0x0200  # arithmetic overflow
DIAG_TMPOL      = 0x0080  # overtemperature event
DIAG_CURRENTOL  = 0x0040  # overcurrent event
DIAG_CURRENTUL  = 0x0020  # undercurrent event
DIAG_BUSOL      = 0x0010  # bus over-limit event
DIAG_BUSUL      = 0x0008  # bus under-limit event
DIAG_POL        = 0x0004  # power over-limit event
DIAG_CNVRF      = 0x0002  # conversion complete flag
DIAG_MEMSTAT    = 0x0001  # memory checksum status (1 = normal)

# --- measurement LSB sizes -------------------------------------------------
LSB_BUS_VOLTAGE  = 0.003125    # V / LSB  (3.125 mV)
LSB_DIE_TEMP     = 0.125       # degC / LSB (125 mdegC, bits 15:4)
LSB_CURRENT      = 0.0012      # A / LSB (1.2 mA)
LSB_POWER        = 0.000240    # W / LSB (240 uW)
LSB_ENERGY       = 0.00384     # J / LSB (3.84 mJ)
LSB_CHARGE       = 0.000075    # C / LSB (75 uC)
LSB_PWR_LIMIT    = 0.06144     # W / LSB (256 x power LSB)


def _s16(value):
    """Interpret a 16-bit value as a signed (two's complement) integer."""
    value &= 0xFFFF
    return value - 0x10000 if value & 0x8000 else value


def _s40(value):
    """Interpret a 40-bit value as a signed (two's complement) integer."""
    value &= (1 << 40) - 1
    return value - (1 << 40) if value & (1 << 39) else value


def _int_from_bytes(data):
    """Assemble a big-endian (MSB first) integer from a bytes sequence."""
    value = 0
    for b in data:
        value = (value << 8) | (b & 0xFF)
    return value


class ina745(object):
    """Class for communicating with an INA745x digital power monitor.

    Access to a register is done through the 8-bit register pointer:

      * write: START -> <addr|W> -> <pointer> -> <MSB> .. <LSB> -> STOP
      * read : START -> <addr|W> -> <pointer> -> RESTART ->
               <addr|R> -> <MSB> .. <LSB> -> NACK -> STOP

    (datasheet 6.5.1.1, Figures 6-12..6-14). Registers wider than 16 bits
    are read as a single burst of 3 or 5 bytes (MSB first). Implemented
    with u4FCPv2.bus.i2c writeBytes()/readBytes(); the register pointer byte is
    passed as the leading data byte.
    """

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = INA745_ADDR_DEFAULT,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create an INA745 instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        i2c_addr : 7-bit target address (0x40..0x4F, default 0x40 for
                   A1=A0=GND); it is shifted up internally to the 8-bit bus
                   address byte.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency.
        """
        if not (0x00 <= i2c_addr <= 0x7F):
            raise ValueError("i2c_addr must be a 7-bit address (0x00..0x7F), "
                             "got 0x%02X" % i2c_addr)
        i2c_addr = addr7_to_addr8(i2c_addr)  # 7-bit -> bus address byte
        self.i2c_addr = i2c_addr
        self.i2c = i2c(device_ip, udp_port, base_address, i2c_addr,
                       clk_freq, i2c_freq)
        _debug("init: 8-bit addr=0x%02X (7-bit 0x%02X), base=0x%08X, "
               "clk=%dMHz, i2c=%dKHz, ip=%s:%d"
               % (i2c_addr, i2c_addr >> 1, base_address, clk_freq, i2c_freq,
                  device_ip, udp_port))

    # ------------------------------------------------------------------
    # low level: raw register transactions (debug via _debug_low_level)
    # ------------------------------------------------------------------
    def _read_register(self, reg, nbytes = 2):
        """Read nbytes (1..5, MSB first) starting at register reg."""
        data = self.i2c.readBytes(reg, nbytes)
        value = _int_from_bytes(data)
        _debug_low_level("read reg 0x%02X (%d bytes) -> 0x%0*X"
                         % (reg, nbytes, nbytes * 2, value))
        return value

    def _write_register(self, reg, value, nbytes = 2):
        """Write nbytes (1..5) of value to register reg, MSB first."""
        bytes_out = [(value >> (8 * i)) & 0xFF
                     for i in range(nbytes - 1, -1, -1)]
        _debug_low_level("write reg 0x%02X <- 0x%0*X"
                         % (reg, nbytes * 2, value & ((1 << (8 * nbytes)) - 1)))
        self.i2c.writeBytes([reg] + bytes_out)
        return value

    def _read_register16(self, reg):
        return self._read_register(reg, 2)

    def _write_register16(self, reg, value):
        return self._write_register(reg, value & 0xFFFF, 2)

    # ------------------------------------------------------------------
    # configuration
    # ------------------------------------------------------------------
    def read_config(self):
        """Read the CONFIG register (0x00)."""
        value = self._read_register16(REG_CONFIG)
        _debug("read_config: 0x%04X" % value)
        return value

    def write_config(self, value):
        """Write the CONFIG register."""
        value = value & 0xFFFF
        _debug("write_config: 0x%04X" % value)
        return self._write_register16(REG_CONFIG, value)

    def reset(self):
        """Trigger a system reset (RST bit), same as a power-on reset."""
        _debug("reset")
        return self._write_register16(REG_CONFIG, CFG_RST)

    def reset_accumulators(self):
        """Clear the ENERGY and CHARGE accumulation registers."""
        _debug("reset_accumulators")
        return self._write_register16(REG_CONFIG, CFG_RSTACC)

    def set_conversion_delay(self, delay_ms):
        """Set the initial conversion delay in ms (0..510, steps of 2ms)."""
        value = self.read_config()
        code = max(0, min(255, int(round(delay_ms / 2.0))))
        value = (value & ~CFG_CONVDLY_MASK) | ((code << 6) & CFG_CONVDLY_MASK)
        _debug("set_conversion_delay: %d ms (code %d)" % (delay_ms, code))
        return self._write_register16(REG_CONFIG, value)

    # ------------------------------------------------------------------
    # ADC configuration
    # ------------------------------------------------------------------
    def read_adc_config(self):
        """Read the ADC_CONFIG register (0x01)."""
        value = self._read_register16(REG_ADC_CONFIG)
        _debug("read_adc_config: 0x%04X" % value)
        return value

    def write_adc_config(self, value):
        """Write the ADC_CONFIG register."""
        value = value & 0xFFFF
        _debug("write_adc_config: 0x%04X" % value)
        return self._write_register16(REG_ADC_CONFIG, value)

    def set_adc_mode(self, mode):
        """Set the ADC operating mode (MODE_* constants), e.g. shutdown,
        triggered single-shot or continuous conversion."""
        temp = self.read_adc_config()
        value = (temp & ~ADC_MODE_MASK) | ((mode & 0x0F) << 12)
        _debug("set_adc_mode: 0x%X" % mode)
        return self._write_register16(REG_ADC_CONFIG, value)

    def set_conversion_time(self, vbus_us = None, vsen_us = None,
                            temp_us = None):
        """Set the conversion times of the bus-voltage / shunt-voltage /
        temperature measurements in microseconds (50, 84, 150, 280, 540,
        1052, 2074 or 4120). Only fields given are changed."""
        temp = self.read_adc_config()
        table = {v: k for k, v in CONVTIME_US.items()}
        if vbus_us is not None:
            code = table[vbus_us]
            temp = (temp & ~ADC_VBUSCT_MASK) | ((code & 0x07) << 9)
        if vsen_us is not None:
            code = table[vsen_us]
            temp = (temp & ~ADC_VSENCT_MASK) | ((code & 0x07) << 6)
        if temp_us is not None:
            code = table[temp_us]
            temp = (temp & ~ADC_TCT_MASK) | ((code & 0x07) << 3)
        _debug("set_conversion_time: vbus=%s vsen=%s temp=%s us"
               % (vbus_us, vsen_us, temp_us))
        return self._write_register16(REG_ADC_CONFIG, temp)

    def set_averaging(self, samples):
        """Set the sample averaging count: 1, 4, 16, 64, 128, 256, 512 or
        1024 (applies to all active inputs)."""
        table = {v: k for k, v in AVG_SAMPLES.items()}
        if samples not in table:
            raise ValueError("invalid averaging count %r" % (samples,))
        temp = self.read_adc_config()
        value = (temp & ~ADC_AVG_MASK) | (table[samples] & 0x07)
        _debug("set_averaging: %d samples" % samples)
        return self._write_register16(REG_ADC_CONFIG, value)

    # ------------------------------------------------------------------
    # measurement results (scaled to physical units)
    # ------------------------------------------------------------------
    def read_bus_voltage(self):
        """Read the bus voltage in volts (3.125 mV/LSB)."""
        value = self._read_register16(REG_VBUS)
        volt = (value & 0xFFFF) * LSB_BUS_VOLTAGE
        _debug("read_bus_voltage: 0x%04X -> %.4f V" % (value, volt))
        return volt

    def read_die_temp(self):
        """Read the internal die temperature in degrees Celsius
        (0.125 degC/LSB, 12-bit two's complement field in bits 15:4)."""
        value = self._read_register16(REG_DIETEMP)
        temp = (_s16(value) >> 4) * LSB_DIE_TEMP   # arithmetic shift keeps sign
        _debug("read_die_temp: 0x%04X -> %.2f degC" % (value, temp))
        return temp

    def read_current(self):
        """Read the shunt current in amperes (1.2 mA/LSB, two's complement)."""
        value = self._read_register16(REG_CURRENT)
        current = _s16(value) * LSB_CURRENT
        _debug("read_current: 0x%04X -> %.4f A" % (value, current))
        return current

    def read_power(self):
        """Read the power result in watts (24-bit, 240 uW/LSB, unsigned)."""
        value = self._read_register(REG_POWER, 3)
        power = value * LSB_POWER
        _debug("read_power: 0x%06X -> %.4f W" % (value, power))
        return power

    def read_energy(self):
        """Read the accumulated energy in joules (40-bit, 3.84 mJ/LSB,
        unsigned)."""
        value = self._read_register(REG_ENERGY, 5)
        energy = value * LSB_ENERGY
        _debug("read_energy: 0x%010X -> %.4f J" % (value, energy))
        return energy

    def read_charge(self):
        """Read the accumulated charge in coulombs (40-bit, 75 uC/LSB,
        two's complement)."""
        value = self._read_register(REG_CHARGE, 5)
        charge = _s40(value) * LSB_CHARGE
        _debug("read_charge: 0x%010X -> %.4f C" % (value, charge))
        return charge

    # ------------------------------------------------------------------
    # diagnostics and alert
    # ------------------------------------------------------------------
    def read_diag_alert(self):
        """Read the DIAG_ALRT register (flags defined by DIAG_* masks)."""
        value = self._read_register16(REG_DIAG_ALRT)
        _debug("read_diag_alert: 0x%04X" % value)
        return value

    def write_diag_alert(self, value):
        """Write the DIAG_ALRT register (e.g. to configure ALATCH/CNVR/
        SLOWALERT/APOL)."""
        value = value & 0xFFFF
        _debug("write_diag_alert: 0x%04X" % value)
        return self._write_register16(REG_DIAG_ALRT, value)

    def set_alert_latch(self, latching):
        """Set the alert latch mode: True = latched (cleared by reading
        DIAG_ALRT), False = transparent."""
        temp = self.read_diag_alert()
        value = temp | DIAG_ALATCH if latching else temp & ~DIAG_ALATCH
        _debug("set_alert_latch: %s" % latching)
        return self._write_register16(REG_DIAG_ALRT, value)

    def set_alert_polarity(self, active_high):
        """Set the ALERT pin polarity: True = active high, False = active
        low (open-drain)."""
        temp = self.read_diag_alert()
        value = temp | DIAG_APOL if active_high else temp & ~DIAG_APOL
        _debug("set_alert_polarity: %s" % ("active-high" if active_high
               else "active-low"))
        return self._write_register16(REG_DIAG_ALRT, value)

    def read_conversion_ready(self):
        """Return True when a conversion cycle has completed (CNVRF bit)."""
        return bool(self.read_diag_alert() & DIAG_CNVRF)

    # ------------------------------------------------------------------
    # threshold registers (raw two's-complement / unsigned codes)
    # ------------------------------------------------------------------
    def read_col(self):
        """Read the current over-limit threshold (raw code, 1.2mA/LSB)."""
        return _s16(self._read_register16(REG_COL))

    def write_col(self, code):
        """Write the current over-limit threshold (raw signed code)."""
        code = code & 0xFFFF
        _debug("write_col: 0x%04X (%d)" % (code, _s16(code)))
        return self._write_register16(REG_COL, code)

    def read_cul(self):
        """Read the current under-limit threshold (raw code, 1.2mA/LSB)."""
        return _s16(self._read_register16(REG_CUL))

    def write_cul(self, code):
        """Write the current under-limit threshold (raw signed code)."""
        code = code & 0xFFFF
        _debug("write_cul: 0x%04X (%d)" % (code, _s16(code)))
        return self._write_register16(REG_CUL, code)

    def read_bovl(self):
        """Read the bus overvoltage threshold (raw code, 3.125mV/LSB)."""
        return self._read_register16(REG_BOVL) & 0x7FFF

    def write_bovl(self, code):
        """Write the bus overvoltage threshold (raw unsigned code, 15-bit)."""
        code = code & 0x7FFF
        _debug("write_bovl: 0x%04X" % code)
        return self._write_register16(REG_BOVL, code)

    def read_buvl(self):
        """Read the bus undervoltage threshold (raw code, 3.125mV/LSB)."""
        return self._read_register16(REG_BUVL) & 0x7FFF

    def write_buvl(self, code):
        """Write the bus undervoltage threshold (raw unsigned code, 15-bit)."""
        code = code & 0x7FFF
        _debug("write_buvl: 0x%04X" % code)
        return self._write_register16(REG_BUVL, code)

    def read_temp_limit(self):
        """Read the temperature over-limit threshold in degrees Celsius
        (0.125 degC/LSB, 12-bit two's complement field in bits 15:4)."""
        value = self._read_register16(REG_TEMP_LIMIT)
        return (_s16(value) >> 4) * LSB_DIE_TEMP

    def write_temp_limit(self, temp_c):
        """Set the temperature over-limit threshold in degrees Celsius
        (12-bit two's complement field in bits 15:4)."""
        code = int(round(temp_c / LSB_DIE_TEMP))
        code = max(-2048, min(2047, code))        # clamp to 12-bit signed
        value = (code & 0x0FFF) << 4
        _debug("write_temp_limit: %.1f degC -> 0x%04X" % (temp_c, value))
        return self._write_register16(REG_TEMP_LIMIT, value)

    def read_pwr_limit(self):
        """Read the power over-limit threshold in watts
        (61.44 mW/LSB, unsigned)."""
        return self._read_register16(REG_PWR_LIMIT) * LSB_PWR_LIMIT

    def write_pwr_limit(self, power_w):
        """Set the power over-limit threshold in watts (0..4026 W)."""
        code = int(round(power_w / LSB_PWR_LIMIT)) & 0xFFFF
        _debug("write_pwr_limit: %.2f W -> 0x%04X" % (power_w, code))
        return self._write_register16(REG_PWR_LIMIT, code)

    # ------------------------------------------------------------------
    # manufacturer
    # ------------------------------------------------------------------
    def read_manufacturer_id(self):
        """Read the Manufacturer ID register (0x5449 = ASCII "TI")."""
        value = self._read_register16(REG_MANUFACTURER_ID)
        text = chr((value >> 8) & 0xFF) + chr(value & 0xFF)
        _debug("read_manufacturer_id: 0x%04X (%r)" % (value, text))
        return text
