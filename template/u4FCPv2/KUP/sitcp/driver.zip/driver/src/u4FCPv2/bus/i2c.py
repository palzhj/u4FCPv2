#!/usr/bin/python
# This is i2c.py file
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
from ..transport.rbcp import Rbcp
import time

I2C_CTR_EN      = 0b10000000 # I2C core enable bit
I2C_CTR_IEN     = 0b01000000 # I2C core interrupt enable bit.

I2C_TXR_WR      = 0b00000000 # writing to slave
I2C_TXR_RD      = 0b00000001 # reading from slave

I2C_CR_STA      = 0b10000000 # generate (repeated) start condition
I2C_CR_STO      = 0b01000000 # generate stop condition
I2C_CR_RD       = 0b00100000 # read from slave
I2C_CR_WR       = 0b00010000 # write to slave
I2C_CR_NACK     = 0b00001000 # when a receiver, sent ACK (ACK = '0') or NACK (ACK = '1')
I2C_CR_IACK     = 0b00000001 # Interrupt acknowledge. When set, clears a pending interrupt.

I2C_SR_NORXACK  = 0b10000000 # No acknowledge received from slave.
I2C_SR_BUSY     = 0b01000000 # I2C bus busy
I2C_SR_AL       = 0b00100000 # Arbitration lost
I2C_SR_TIP      = 0b00000010 # Transfer in progress
I2C_SR_IF       = 0b00000001 # Interrupt Flag


def _to_bytes(data):
    """Normalize a payload to bytes: accept an int, bytes/bytearray, a str,
    or an iterable of ints (e.g. [0x12, 0x34])."""
    if isinstance(data, int):
        return bytes([data & 0xFF])
    if isinstance(data, str):
        return data.encode("utf-8")
    try:
        return bytes(bytearray(data))
    except (TypeError, ValueError):
        raise ValueError("I2C ERROR: cannot convert data %r to bytes" % (data,))

class I2CError(Exception):
    """
    I2C Error Exception class.
    """
    pass

class i2c(object):
    """Class for communicating with an I2C device through the FPGA I2C-master
    core (OpenCores I2C master, see i2c_specs.pdf). Only two byte-oriented
    primitives are exposed: readBytes() and writeBytes(); register based
    devices send their internal (register) address as leading data bytes."""
    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = None,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create an I2C bus master on the FPGA I2C core.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : register base address of the I2C master core.
        i2c_addr : address byte of the target on the bus (the driver layer
                   passes its 7-bit address already shifted up, R/W bit
                   cleared); it has no useful default and must be given.
        clk_freq / i2c_freq : timing parameters used to compute the clock
                   divider of the core.
        """
        if i2c_addr is None:
            raise ValueError("i2c_addr is required: it is the address byte of "
                             "the I2C target on the bus")
        self.CLK_FREQ_MHZ = clk_freq # MHz
        self.I2C_FREQ_KHZ = i2c_freq # kHz
        self.I2C_PRER_LO_ADDR = base_address
        self.I2C_PRER_HI_ADDR = base_address + 0x1
        self.I2C_CTR_ADDR     = base_address + 0x2
        self.I2C_RXR_ADDR     = base_address + 0x3
        self.I2C_TXR_ADDR     = base_address + 0x3
        self.I2C_CR_ADDR      = base_address + 0x4
        self.I2C_SR_ADDR      = base_address + 0x4

        self._address = i2c_addr
        self._rbcp = Rbcp(device_ip = device_ip, udp_port = udp_port)

        clk_count = int(self.CLK_FREQ_MHZ*1000/5/self.I2C_FREQ_KHZ - 1)
        prer_hi = (clk_count >> 8) & 0xFF
        prer_hi = bytes([prer_hi])
        prer_lo = clk_count & 0xFF
        prer_lo = bytes([prer_lo])

        if prer_lo != self._rbcp.write(self.I2C_PRER_LO_ADDR, prer_lo):
            raise IOError("UDP communication ERROR.")
            return -1

        self._rbcp.write(self.I2C_PRER_HI_ADDR, prer_hi)
        self._rbcp.write(self.I2C_CTR_ADDR, bytes([I2C_CTR_EN])) # enable

    # ------------------------------------------------------------------
    # low level core primitives
    # ------------------------------------------------------------------
    def _wait_tip(self, timeout = 1.0):
        """Wait until the I2C core clears the Transfer-In-Progress (TIP) bit.
        Raises IOError if the transfer does not finish within `timeout`
        seconds, so a hung bus never blocks the caller forever."""
        deadline = time.time() + timeout
        while (self._rbcp.read(self.I2C_SR_ADDR, 1)[0]) & I2C_SR_TIP:
            if time.time() > deadline:
                raise IOError("I2C ERROR: timeout waiting for TIP to clear "
                              "(%.1f s)" % timeout)

    def _abort(self):
        """Release the I2C bus with a STOP condition after a fault."""
        try:
            self._rbcp.write(self.I2C_CR_ADDR, bytes([I2C_CR_STO]))
            self._wait_tip()
        except IOError:
            pass

    def _tx_byte(self, data, sta = False, sto = False):
        """Transmit one byte over the bus (spec 4.2.3, Example 1):

        load data into the Transmit Register, issue a WR command (plus STA
        for the first byte / STO for the last byte), wait for the TIP flag
        to negate, then read the RxACK (NORXACK) flag. If the slave did not
        acknowledge, abort with a STOP and raise IOError."""
        self._rbcp.write(self.I2C_TXR_ADDR, bytes([data & 0xFF]))
        cr = I2C_CR_WR
        if sta:
            cr |= I2C_CR_STA
        if sto:
            cr |= I2C_CR_STO
        self._rbcp.write(self.I2C_CR_ADDR, bytes([cr]))
        time.sleep(8/(self.I2C_FREQ_KHZ*1000.0))
        self._wait_tip()
        if (self._rbcp.read(self.I2C_SR_ADDR, 1)[0]) & I2C_SR_NORXACK:
            if not sto:                             # bus still held, release it
                self._abort()
            raise IOError("I2C ERROR: No acknowledge received")

    def _rx_byte(self, nack = False, sto = False):
        """Receive one byte from the slave (spec Example 2):

        issue an RD command (NACK + STOP on the last received byte), wait
        for TIP to negate, then read the received byte from RXR."""
        cr = I2C_CR_RD
        if nack:
            cr |= I2C_CR_NACK
        if sto:
            cr |= I2C_CR_STO
        self._rbcp.write(self.I2C_CR_ADDR, bytes([cr]))
        time.sleep(8/(self.I2C_FREQ_KHZ*1000.0))
        self._wait_tip()
        return self._rbcp.read(self.I2C_RXR_ADDR, 1)[0] & 0xFF

    # ------------------------------------------------------------------
    # byte-oriented bus primitives
    # ------------------------------------------------------------------
    def writeBytes(self, data):
        """Write `data` (bytes/bytearray/str/int/list) to the slave.

        I2C write operation (spec Example 1):
            START -> <slave addr|W> -> <data bytes...> -> STOP
        Register-mapped devices put their internal (register) address
        byte(s) at the front of `data`, e.g. writeBytes([reg, value]).
        Every transferred byte is acknowledged on the 9th SCL clock; each
        transfer waits for TIP and re-checks the RxACK flag."""
        data = _to_bytes(data)
        if len(data) == 0:
            raise ValueError("I2C ERROR: no data to write")

        # 1) START + slave address with the write bit
        self._tx_byte(self._address | I2C_TXR_WR, sta = True)

        # 2) data bytes; the last one terminates the transfer with STOP
        for byte in data[:-1]:
            self._tx_byte(byte)
        self._tx_byte(data[-1], sto = True)

    def readBytes(self, data, length_to_read):
        """Read `length_to_read` bytes from the slave, returned as bytes.

        data : internal (register) address byte(s) to write before the read,
               or None for a pure read (single-register devices such as the
               TCA9548A send no register address).

        I2C read operation (spec Example 2):
            [START -> <addr|W> -> <data...>] ->
            repeated START -> <addr|R> -> <read bytes...> -> NACK+STOP
        The first length_to_read-1 bytes are acknowledged by the controller;
        the final byte is NACKed and followed by a STOP."""
        if length_to_read <= 0:
            raise ValueError("I2C ERROR: read length must be >= 1, got %r"
                             % (length_to_read,))

        # 1) optional: write the internal (register) address byte(s)
        if data is not None:
            data = _to_bytes(data)
            if len(data):
                self._tx_byte(self._address | I2C_TXR_WR, sta = True)
                for byte in data:
                    self._tx_byte(byte)

        # 2) repeated START + slave address with the read bit
        self._tx_byte(self._address | I2C_TXR_RD, sta = True)

        # 3) receive length_to_read bytes, NACK + STOP on the last one
        result = bytes()
        for i in range(length_to_read - 1):
            result += bytes([self._rx_byte()])
        result += bytes([self._rx_byte(nack = True, sto = True)])
        return result
