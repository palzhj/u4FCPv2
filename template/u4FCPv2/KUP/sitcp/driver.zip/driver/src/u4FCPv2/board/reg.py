#!/usr/bin/python
# This is reg.py file
# board register map driver (see docs/reg_table.md)
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
from ..transport.rbcp import Rbcp

# ---------------------------------------------------------------------------
# Register map (docs/reg_table.md)
#   byte_size = 256, bus_width = 8
# ---------------------------------------------------------------------------
REG_SYN_INFO    = 0x00  # synthesis date, 32-bit, rof
REG_SYN_VER     = 0x04  # firmware version, 8-bit, rof
REG_SYS_RST     = 0x05  # user logic / DDR reset, 8-bit, w1trg
REG_MOD_RST     = 0x06  # front-end module / QSFP reset, 8-bit, w1trg
REG_SYS_STA     = 0x07  # system status, 8-bit, ro
REG_SYS_STA_LCH = 0x08  # system status latch, 8-bit, rotrg
REG_MOD_STA     = 0x09  # module status, 8-bit, ro
REG_MOD_STA_LCH = 0x0A  # module status latch, 8-bit, rotrg
REG_CLK         = 0x0B  # clock source control, rw
REG_LV          = 0x0C  # low voltage control, rw
REG_HV          = 0x0D  # high voltage control, rw
REG_QSFP        = 0x0E  # QSFP control, rw

# --- sys_rst (0x05) bit fields ----------------------------------------------
BIT_USR_RST = 0x01  # w1trg: write 1 to pulse-reset the user logic, 0 no effect
BIT_DDR_RST = 0x02  # w1trg: write 1 to pulse-reset the DDR, 0 has no effect

# --- mod_rst (0x06) bit fields ----------------------------------------------
BIT_MOD_RST  = 0x01  # w1trg: write 1 to pulse-reset the front-end modules
BIT_QSFP_RST = 0x02  # w1trg: write 1 to pulse-reset the QSFP

# --- sys_sta (0x07) / sys_sta_lch (0x08) bit fields -------------------------
BIT_CLK_LOCK = 0x01  # 0 = MMCM not locked, 1 = MMCM locked

# --- mod_sta (0x09) / mod_sta_lch (0x0a) bit fields -------------------------
BIT_TEMP_ALM = 0x01  # mod_sta: 1 = over-temperature alarm
BIT_LV_ALM   = 0x02  # mod_sta: 1 = low-voltage over-current alarm
BIT_HV_ALM   = 0x04  # mod_sta: 1 = high-voltage over-current alarm
BIT_QSFP_ALM = 0x08  # mod_sta: 1 = QSFP28 alarm
BIT_QSFP_PRS = 0x10  # mod_sta: 1 = QSFP module present

# --- clk (0x0b) bit fields --------------------------------------------------
BIT_CLK_EXT_EN = 0x01  # 0 = on-board/local clock, 1 = external clock from AMC

# --- lv (0x0c) bit fields ---------------------------------------------------
BIT_LV_ENABLE      = 0x01  # 1 = lv power ON, 0 = lv power OFF
BIT_LV_OT_AUTO_OFF = 0x02  # 1 = auto power OFF when over-temperature

# --- hv (0x0d) bit fields ---------------------------------------------------
# stop resets to 1, i.e. the high voltage powers up shut down (safe default),
# and the register table documents that; 0 has to be written to switch it on.
BIT_HV_STOP        = 0x01  # 1 = emergency shut down, 0 = HV ON
BIT_HV_OC_AUTO_OFF = 0x02  # 1 = auto power OFF when over-current

# --- qsfp (0x0e) bit fields -------------------------------------------------
BIT_QSFP_LPMODE = 0x01  # 1 = QSFP low-power mode, 0 = normal (full power)

# ---------------------------------------------------------------------------
# SiTCP configuration space (0xffffff00, separate from the board register map
# of docs/reg_table.md; merged from lib/reg.py)
# ---------------------------------------------------------------------------
REG_SITCP                   = 0xFFFFFF00
REG_SITCP_CONTROL           = 0xFFFFFF10
REG_SITCP_RETRANSMISSION_TIME = 0xFFFFFF2E

# REG_SITCP_CONTROL bits
CTRL_RESET          = 0x80
CTRL_WINDOW_SCALING = 0x10
CTRL_KEEP_ALIVE     = 0x04
CTRL_FAST_RETRAINS  = 0x02
CTRL_NAGLE          = 0x01


def _bcd_to_int(value):
    """Decode a binary-coded-decimal byte (syn_info fields) to an int."""
    return (value >> 4) * 10 + (value & 0x0F)


class reg(object):
    """Class for accessing the board registers over SiTCP RBCP
    (../transport/rbcp.py). Every register is 8-bit except syn_info (32-bit);
    a read/write is a plain RBCP transaction at the register offset."""

    def __init__(self, device_ip = "192.168.10.16", udp_port = 4660):
        """Create a reg instance.

        device_ip : SiTCP device IP address.
        udp_port  : SiTCP device RBCP (UDP) port.
        """
        self._rbcp = Rbcp(device_ip = device_ip, udp_port = udp_port)

    # ------------------------------------------------------------------
    # low level register access
    # ------------------------------------------------------------------
    def read(self, address, length = 1):
        """Read `length` bytes starting at the register offset."""
        return self._rbcp.read(address, length)

    def write(self, address, data):
        """Write `data` (int or byte-like) at the register offset."""
        if isinstance(data, int):
            data = bytes([data & 0xFF])
        return self._rbcp.write(address, data)

    # ------------------------------------------------------------------
    # syn_info (0x00, 32-bit rof)
    # ------------------------------------------------------------------
    def read_syn_info(self):
        """Read the synthesis date: hour[7:0], date[15:8], month[23:16],
        year[31:24] (BCD). Returns a dict with decoded values."""
        temp = self.read(REG_SYN_INFO, 4)
        info = {
            "hour":  _bcd_to_int(temp[0]),
            "date":  _bcd_to_int(temp[1]),
            "month": _bcd_to_int(temp[2]),
            "year":  2000 + _bcd_to_int(temp[3]),
        }
        return info

    def read_info(self):
        """Print the synthesis date and firmware version."""
        info = self.read_syn_info()
        print("Compiling date: %d-%02d-%02d, %02d:00"
              % (info["year"], info["month"], info["date"], info["hour"]))
        print("Firmware version: ", self.read_syn_ver())

    # ------------------------------------------------------------------
    # syn_ver (0x04, rof)
    # ------------------------------------------------------------------
    def read_syn_ver(self):
        """Read the firmware version."""
        return self.read(REG_SYN_VER, 1)[0]

    # ------------------------------------------------------------------
    # sys_rst (0x05, w1trg) / mod_rst (0x06, w1trg)
    # ------------------------------------------------------------------
    def usr_reset(self):
        """Generate a reset pulse for the user logic (write 1 to
        sys_rst.usr_rst)."""
        self.write(REG_SYS_RST, BIT_USR_RST)

    def ddr_reset(self):
        """Generate a reset pulse for the DDR (write 1 to sys_rst.ddr_rst)."""
        self.write(REG_SYS_RST, BIT_DDR_RST)

    def mod_reset(self):
        """Generate a reset pulse for the front-end modules (write 1 to
        mod_rst.mod_rst)."""
        self.write(REG_MOD_RST, BIT_MOD_RST)

    def qsfp_reset(self):
        """Generate a reset pulse for the QSFP (write 1 to mod_rst.qsfp_rst)."""
        self.write(REG_MOD_RST, BIT_QSFP_RST)

    # ------------------------------------------------------------------
    # sys_sta (0x07, ro) / sys_sta_lch (0x08, rotrg)
    # ------------------------------------------------------------------
    def read_sys_sta(self):
        """Read the system status register (bit 0 = clk_lock)."""
        return self.read(REG_SYS_STA, 1)[0]

    def read_sys_sta_latch(self):
        """Read the latched system status; the latch is cleared by reading."""
        return self.read(REG_SYS_STA_LCH, 1)[0]

    def clk_locked(self):
        """Return True while the MMCM reports locked (sys_sta.clk_lock)."""
        return bool(self.read_sys_sta() & BIT_CLK_LOCK)

    def clk_lock_latch(self):
        """Return True when the MMCM has reported locked at some point, and
        clear the flag: sys_sta_lch is read-to-clear, so one call consumes it."""
        return bool(self.read_sys_sta_latch() & BIT_CLK_LOCK)

    # ------------------------------------------------------------------
    # mod_sta (0x09, ro) / mod_sta_lch (0x0a, rotrg)
    # ------------------------------------------------------------------
    @staticmethod
    def _decode_mod_sta(value):
        """Decode a module status byte into named flags."""
        return {
            "temp_alm": bool(value & BIT_TEMP_ALM),
            "lv_alm":   bool(value & BIT_LV_ALM),
            "hv_alm":   bool(value & BIT_HV_ALM),
            "qsfp_alm": bool(value & BIT_QSFP_ALM),
            "qsfp_prs": bool(value & BIT_QSFP_PRS),
        }

    def read_mod_sta(self):
        """Read the module status flags (temp/lv/hv/qsfp alarm, qsfp present)."""
        return self._decode_mod_sta(self.read(REG_MOD_STA, 1)[0])

    def read_mod_sta_latch(self):
        """Read the latched module status flags (interrupt mode); the flags
        are cleared by reading this register."""
        return self._decode_mod_sta(self.read(REG_MOD_STA_LCH, 1)[0])

    # ------------------------------------------------------------------
    # clk (0x0b, rw)
    # ------------------------------------------------------------------
    def read_clk(self):
        """Read the clock control byte (bit 0 = ext_en)."""
        return self.read(REG_CLK, 1)[0]

    def set_clk_ext(self, external):
        """Select the clock source: True = external clock from the AMC,
        False = on-board/local clock. Other bits are preserved."""
        value = self.read_clk()
        value = (value | BIT_CLK_EXT_EN) if external else \
                (value & ~BIT_CLK_EXT_EN)
        self.write(REG_CLK, value)
        return value

    # ------------------------------------------------------------------
    # lv (0x0c, rw)
    # ------------------------------------------------------------------
    def read_lv(self):
        """Read the low-voltage control byte."""
        return self.read(REG_LV, 1)[0]

    def set_lv(self, enable, ot_auto_off = 0):
        """Set the low-voltage control (register 0x0c).

        enable      : 0 = module power OFF, 1 = module power ON.
        ot_auto_off : 0 = normal, 1 = auto power OFF on over-temperature.
        Both bits are always written; the remaining bits are preserved."""
        value = self.read_lv()
        value = value | BIT_LV_ENABLE if enable else value & ~BIT_LV_ENABLE
        value = (value | BIT_LV_OT_AUTO_OFF) if ot_auto_off else \
                (value & ~BIT_LV_OT_AUTO_OFF)
        self.write(REG_LV, value)
        return value

    # ------------------------------------------------------------------
    # hv (0x0d, rw)
    # ------------------------------------------------------------------
    def read_hv(self):
        """Read the high-voltage control byte (bit 0 = stop resets to 1)."""
        return self.read(REG_HV, 1)[0]

    def set_hv(self, stop, oc_auto_off = 0):
        """Set the high-voltage control (register 0x0d).

        stop        : 0 = high voltage ON, 1 = emergency shut down. This is the
                      bit that RESETS TO 1, so the supply is off after a board
                      reset until a 0 is written here.
        oc_auto_off : 0 = normal, 1 = auto power OFF on over-current.
        Both bits are always written; the remaining bits are preserved."""
        value = self.read_hv()
        value = (value | BIT_HV_STOP) if stop else (value & ~BIT_HV_STOP)
        value = (value | BIT_HV_OC_AUTO_OFF) if oc_auto_off else \
                (value & ~BIT_HV_OC_AUTO_OFF)
        self.write(REG_HV, value)
        return value

    # ------------------------------------------------------------------
    # qsfp (0x0e, rw)
    # ------------------------------------------------------------------
    def read_qsfp(self):
        """Read the QSFP control byte (bit 0 = low-power mode)."""
        return self.read(REG_QSFP, 1)[0]

    def set_qsfp_lpmode(self, low_power):
        """Set the QSFP low-power mode: True = low power, False = normal
        (full power). Other bits are preserved."""
        value = self.read_qsfp()
        value = (value | BIT_QSFP_LPMODE) if low_power else \
                (value & ~BIT_QSFP_LPMODE)
        self.write(REG_QSFP, value)
        return value

    # ------------------------------------------------------------------
    # debug helper
    # ------------------------------------------------------------------
    def print_status(self):
        """Print the firmware information and the current status registers.

        The module flags are printed twice: the live ones from mod_sta (0x09)
        and the latched ones from mod_sta_lch (0x0a) with a _lch suffix on the
        label. Reading the latched register clears it (rotrg), so one call
        consumes every latched module flag - use read_mod_sta_latch() alone when
        the flags have to be kept."""
        self.read_info()
        sta = self.read_sys_sta()
        print("sys_sta       : 0x%02X  (clk_lock = %d)"
              % (sta, 1 if sta & BIT_CLK_LOCK else 0))
        sta_lch = self.read_sys_sta_latch()          # read-to-clear
        print("sys_sta_lch   : 0x%02X  (clk_lock = %d)"
              % (sta_lch, 1 if sta_lch & BIT_CLK_LOCK else 0))
        mod = self.read_mod_sta()
        for name in ("temp_alm", "lv_alm", "hv_alm", "qsfp_alm", "qsfp_prs"):
            print("%-13s : %d" % (name, mod[name]))
        latched = self.read_mod_sta_latch()
        for name in ("temp_alm", "lv_alm", "hv_alm", "qsfp_alm", "qsfp_prs"):
            print("%-13s : %d" % (name + "_lch", latched[name]))
        print("clk           : 0x%02X" % self.read_clk())
        print("lv            : 0x%02X" % self.read_lv())
        print("hv            : 0x%02X" % self.read_hv())
        print("qsfp          : 0x%02X" % self.read_qsfp())

    # ------------------------------------------------------------------
    # SiTCP configuration (merged from lib/reg.py)
    # ------------------------------------------------------------------
    def read_sitcp_reg(self):
        """Read and print the SiTCP configuration registers."""
        temp = self._rbcp.read(REG_SITCP, 0x42)
        for i in range(0x42):
            print("@addr0x%02x: 0x%02x" % (i, temp[i]))

    def set_sitcp_retransmission_time(self, msec):
        """Set the SiTCP retransmission time in milliseconds."""
        self.write(REG_SITCP_RETRANSMISSION_TIME, (msec >> 8) & 0xFF)
        self.write(REG_SITCP_RETRANSMISSION_TIME + 1, msec & 0xFF)

    def set_sitcp_keep_alive(self, enable = True):
        """Enable/disable the SiTCP keep-alive function."""
        temp = self.read(REG_SITCP_CONTROL, 1)[0]
        if enable:
            self.write(REG_SITCP_CONTROL, temp | CTRL_KEEP_ALIVE)
        else:
            self.write(REG_SITCP_CONTROL, temp & ~CTRL_KEEP_ALIVE)

    def set_sitcp_fast_retrains(self, enable = True):
        """Enable/disable the SiTCP fast retransmission function."""
        temp = self.read(REG_SITCP_CONTROL, 1)[0]
        if enable:
            self.write(REG_SITCP_CONTROL, temp | CTRL_FAST_RETRAINS)
        else:
            self.write(REG_SITCP_CONTROL, temp & ~CTRL_FAST_RETRAINS)

    def set_sitcp_nagle(self, enable = True):
        """Enable/disable the SiTCP Nagle algorithm."""
        temp = self.read(REG_SITCP_CONTROL, 1)[0]
        if enable:
            self.write(REG_SITCP_CONTROL, temp | CTRL_NAGLE)
        else:
            self.write(REG_SITCP_CONTROL, temp & ~CTRL_NAGLE)

    def set_sitcp_window_scaling(self, enable = True):
        """Enable/disable SiTCP window scaling (SiTCP-XG only)."""
        if 0x58 == self.read(REG_SITCP + 8, 1)[0]:
            temp = self.read(REG_SITCP_CONTROL, 1)[0]
            if enable:
                self.write(REG_SITCP_CONTROL, temp | CTRL_WINDOW_SCALING)
            else:
                self.write(REG_SITCP_CONTROL, temp & ~CTRL_WINDOW_SCALING)
