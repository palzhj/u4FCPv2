#!/usr/bin/python
# This is tca9548a.py
# TI TCA9548A low-voltage 8-channel I2C switch driver
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
from ..bus.i2c import i2c

# Debug switches, independent of each other:
#   DEBUG     = 1 -> print high-level per-operation info
#   DEBUG_LOW_LEVEL = 1 -> print low-level register/bus transactions
# Set either to 0 to silence that level only.
DEBUG     = 0
DEBUG_LOW_LEVEL = 0


def _debug(msg):
    """Print a high-level debug message when DEBUG is enabled."""
    if DEBUG:
        print("[tca9548a] " + msg)


def _debug_low_level(msg):
    """Print a low-level debug message when DEBUG_LOW_LEVEL is enabled."""
    if DEBUG_LOW_LEVEL:
        print("[tca9548a-low-level] " + msg)


def _mask_to_channels(value):
    """Return the channel numbers selected by a control-register bit mask."""
    return [n for n in range(8) if value & (1 << n)]

# ---------------------------------------------------------------------------
# Device address (datasheet Figure 7-3 and Table 7-1)
#
#   The 7-bit target address is built from fixed 1110 + A2 A1 A0:
#     A2A1A0 = 000 -> 0x70       A2A1A0 = 100 -> 0x74
#     A2A1A0 = 001 -> 0x71       A2A1A0 = 101 -> 0x75
#     A2A1A0 = 010 -> 0x72       A2A1A0 = 110 -> 0x76
#     A2A1A0 = 011 -> 0x73       A2A1A0 = 111 -> 0x77
#
#   The hardware on this board is strapped to 0x73, i.e. the 8-bit address
#   byte put on the bus is 0xE6 for a write and 0xE7 for a read.
# ---------------------------------------------------------------------------
TCA9548A_ADDR_DEFAULT = 0b111_0011  # 7-bit address 0x73 (write byte 0xE6)


def addr7_to_addr8(addr7):
    """Convert a 7-bit target address (0x70..0x77) to the 8-bit address byte
    sent on the bus with the R/W bit cleared (0xE0..0xEE)."""
    return ((addr7 & 0x7F) << 1) & 0xFE


# Control-register channel-select bits (datasheet Figure 7-6 / Table 7-2):
# bit Bn = 1 switches channel n (SCn/SDn) on; any combination is allowed.
CH0 = 0x01  # channel 0
CH1 = 0x02  # channel 1
CH2 = 0x04  # channel 2
CH3 = 0x08  # channel 3
CH4 = 0x10  # channel 4
CH5 = 0x20  # channel 5
CH6 = 0x40  # channel 6
CH7 = 0x80  # channel 7


class tca9548a(object):
    """Class for communicating with a TCA9548A 8-channel I2C switch.

    The TCA9548A has a single 8-bit control register and no internal
    register map, so every access is:

      * write: START -> <addr|W> -> <control byte> -> STOP
      * read : START -> <addr|R> -> <one byte> -> NACK -> STOP

    A selected channel becomes active only after the STOP condition
    (datasheet 7.5.4), which i2c.readBytes()/writeBytes() provide.
    """

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = TCA9548A_ADDR_DEFAULT,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create a TCA9548A instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        i2c_addr : 7-bit target address (0x70..0x77, default 0x73); it is
                   shifted up internally to the 8-bit bus address byte.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency.
        """
        if not (0x00 <= i2c_addr <= 0x7F):
            raise ValueError("i2c_addr must be a 7-bit address (0x00..0x7F), "
                             "got 0x%02X" % i2c_addr)
        i2c_addr = addr7_to_addr8(i2c_addr)  # 7-bit -> bus address byte
        self.i2c_addr = i2c_addr
        self.i2c = i2c(device_ip, udp_port, base_address, i2c_addr,
                       clk_freq, i2c_freq)
        _debug("init: 8-bit addr=0x%02X (7-bit 0x%02X), base=0x%08X, "
               "clk=%dMHz, i2c=%dKHz, ip=%s:%d"
               % (i2c_addr, i2c_addr >> 1, base_address, clk_freq, i2c_freq,
                  device_ip, udp_port))

    # ------------------------------------------------------------------
    # low level: raw control-register transactions (debug via _debug_low_level)
    # ------------------------------------------------------------------
    def _read_control(self):
        """Read the control register:
        START -> <addr|R> -> <one byte> -> NACK -> STOP (datasheet Fig 7-5)."""
        value = self.i2c.readBytes(None, 1)[0]
        _debug_low_level("read8: addr=0x%02X -> data 0x%02X (channels %s)"
                   % (self.i2c_addr | 0x01, value, _mask_to_channels(value)))
        return value

    def _write_control(self, value):
        """Write the control register:
        START -> <addr|W> -> <control byte> -> STOP (datasheet Fig 7-4)."""
        value = value & 0xFF
        _debug_low_level("write8: addr=0x%02X <- data 0x%02X (channels %s)"
                   % (self.i2c_addr, value, _mask_to_channels(value)))
        self.i2c.writeBytes([value])
        return value

    # ------------------------------------------------------------------
    # convenient helpers
    # ------------------------------------------------------------------
    def select_channel(self, channel):
        """Select exactly one channel (0..7) and deselect all others."""
        if not (0 <= channel <= 7):
            raise ValueError("channel must be in 0..7, got %r" % (channel,))
        _debug("select_channel: channel %d (mask 0x%02X)"
               % (channel, 1 << channel))
        return self._write_control(1 << channel)

    def deselect_channel(self, channel):
        """Deselect one channel (0..7), keeping the other channels as-is."""
        if not (0 <= channel <= 7):
            raise ValueError("channel must be in 0..7, got %r" % (channel,))
        _debug("deselect_channel: channel %d (mask 0x%02X)"
               % (channel, 1 << channel))
        status = self._read_control()
        return self._write_control(status & ~(1 << channel))

    def enable_all(self):
        """Select every channel (all 8 channels switched on)."""
        _debug("enable_all")
        return self._write_control(0xFF)

    def disable_all(self):
        """Deselect every channel (same as the power-up/reset default)."""
        _debug("disable_all")
        return self._write_control(0x00)

    def is_channel_selected(self, channel):
        """Return True if the given channel (0..7) is currently selected."""
        if not (0 <= channel <= 7):
            raise ValueError("channel must be in 0..7, got %r" % (channel,))
        status = self._read_control()
        _debug("is_channel_selected: channel %d -> %s"
               % (channel, bool(status & (1 << channel))))
        return bool(status & (1 << channel))
