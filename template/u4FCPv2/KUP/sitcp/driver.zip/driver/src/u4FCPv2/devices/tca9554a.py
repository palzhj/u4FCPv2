#!/usr/bin/python
# This is tca9554a.py
# TI TCA9554A low-voltage 8-bit I2C/SMBus I/O expander driver
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
# based on TCA9554A datasheet (TI SCPS196)

from ..bus.i2c import i2c

# Debug switches, independent of each other:
#   DEBUG     = 1 -> print high-level per-operation info
#   DEBUG_LOW_LEVEL = 1 -> print low-level register/bus transactions
# Set either to 0 to silence that level only.
DEBUG            = 0
DEBUG_LOW_LEVEL  = 0


def _debug(msg):
    """Print a high-level debug message when DEBUG is enabled."""
    if DEBUG:
        print("[tca9554a] " + msg)


def _debug_low_level(msg):
    """Print a low-level debug message when DEBUG_LOW_LEVEL is enabled."""
    if DEBUG_LOW_LEVEL:
        print("[tca9554a-low-level] " + msg)


# ---------------------------------------------------------------------------
# Device address (datasheet Figure 19 and Table 2)
#
#   7-bit slave address = 0111 A2 A1 A0, fixed by the A0/A1/A2 pins:
#     A2A1A0 = 000 -> 0x38       A2A1A0 = 100 -> 0x3C
#     A2A1A0 = 001 -> 0x39       A2A1A0 = 101 -> 0x3D
#     A2A1A0 = 010 -> 0x3A       A2A1A0 = 110 -> 0x3E
#     A2A1A0 = 011 -> 0x3B       A2A1A0 = 111 -> 0x3F
#
#   The hardware on this board is strapped with A2 = A1 = A0 = 0 (default
#   0x38); the 8-bit write byte on the bus is then 0x70, read byte 0x71.
# ---------------------------------------------------------------------------
TCA9554A_ADDR_DEFAULT = 0b0111_000  # 7-bit address 0x38, A2 = A1 = A0 = 0


def addr7_to_addr8(addr7):
    """Convert a 7-bit target address (0x38..0x3F) to the 8-bit address byte
    sent on the bus with the R/W bit cleared (0x70 for TCA9554A at 0x38)."""
    return ((addr7 & 0x7F) << 1) & 0xFE


# ---------------------------------------------------------------------------
# Register map (datasheet Table 3 "Command Byte"). A single 8-bit port is
# controlled through these four registers, addressed by the command byte.
# ---------------------------------------------------------------------------
REG_INPUT        = 0x00  # Input Port, read only, I0..I7
REG_OUTPUT       = 0x01  # Output Port, read/write, default 0xFF
REG_POLARITY     = 0x02  # Polarity Inversion, read/write, default 0x00
REG_CONFIG       = 0x03  # Configuration, read/write, default 0xFF (all inputs)

# port pin bit masks
P0 = 0x01  # pin 0
P1 = 0x02  # pin 1
P2 = 0x04  # pin 2
P3 = 0x08  # pin 3
P4 = 0x10  # pin 4
P5 = 0x20  # pin 5
P6 = 0x40  # pin 6
P7 = 0x80  # pin 7

PINS = [P0, P1, P2, P3, P4, P5, P6, P7]


class tca9554a(object):
    """Class for communicating with a TCA9554A 8-bit I/O expander.

    Register access is via the I2C command byte (the register pointer), so
    every operation passes the command byte as leading data:

      * write: START -> <addr|W> -> <command byte> -> <data> -> STOP
      * read : START -> <addr|W> -> <command byte> -> RESTART ->
               <addr|R> -> <data> -> NACK -> STOP

    Configuration register bit = 1 means the pin is an input (default),
    bit = 0 means the pin is an output (datasheet 8.6.3, Table 7).
    """

    def __init__(self, device_ip = "192.168.10.16",
                 udp_port = 4660,
                 base_address = 0x00020000,
                 i2c_addr = TCA9554A_ADDR_DEFAULT,
                 clk_freq = 125,  # unit: MHz
                 i2c_freq = 100): # unit: KHz
        """Create a TCA9554A instance.

        device_ip / udp_port : SiTCP target (FPGA) that carries the I2C core.
        base_address : FPGA I2C-core base address.
        i2c_addr : 7-bit target address (0x38..0x3F, default 0x38); it is
                   shifted up internally to the 8-bit bus address byte.
        clk_freq / i2c_freq : FPGA I2C-core clock and I2C bus frequency.
        """
        if not (0x00 <= i2c_addr <= 0x7F):
            raise ValueError("i2c_addr must be a 7-bit address (0x00..0x7F), "
                             "got 0x%02X" % i2c_addr)
        i2c_addr = addr7_to_addr8(i2c_addr)  # 7-bit -> bus address byte
        self.i2c_addr = i2c_addr
        self.i2c = i2c(device_ip, udp_port, base_address, i2c_addr,
                       clk_freq, i2c_freq)
        _debug("init: 8-bit addr=0x%02X (7-bit 0x%02X), base=0x%08X, "
               "clk=%dMHz, i2c=%dKHz, ip=%s:%d"
               % (i2c_addr, i2c_addr >> 1, base_address, clk_freq, i2c_freq,
                  device_ip, udp_port))

    # ------------------------------------------------------------------
    # low level: raw register transactions (debug via _debug_low_level)
    # ------------------------------------------------------------------
    def _read_register(self, reg):
        """Read one 8-bit register selected by the command byte."""
        value = self.i2c.readBytes(reg, 1)[0]
        _debug_low_level("read reg 0x%02X -> 0x%02X" % (reg, value))
        return value

    def _write_register(self, reg, value):
        """Write one 8-bit register selected by the command byte."""
        value = value & 0xFF
        _debug_low_level("write reg 0x%02X <- 0x%02X" % (reg, value))
        self.i2c.writeBytes([reg, value])
        return value

    # ------------------------------------------------------------------
    # input / output port
    # ------------------------------------------------------------------
    def read_input(self):
        """Read the Input Port register (pin logic levels, P0..P7)."""
        value = self._read_register(REG_INPUT)
        _debug("read_input: 0x%02X" % value)
        return value

    def read_output(self):
        """Read the Output Port register (latched output values)."""
        return self._read_register(REG_OUTPUT)

    def write_output(self, value):
        """Write the Output Port register (bits affect pins configured as
        outputs only)."""
        value = value & 0xFF
        _debug("write_output: 0x%02X" % value)
        return self._write_register(REG_OUTPUT, value)

    # ------------------------------------------------------------------
    # polarity inversion
    # ------------------------------------------------------------------
    def read_polarity(self):
        """Read the Polarity Inversion register."""
        return self._read_register(REG_POLARITY)

    def write_polarity(self, value):
        """Write the Polarity Inversion register: bit = 1 inverts the
        polarity of that input pin, 0 keeps the original polarity."""
        value = value & 0xFF
        _debug("write_polarity: 0x%02X" % value)
        return self._write_register(REG_POLARITY, value)

    # ------------------------------------------------------------------
    # configuration (bit = 1 -> input, bit = 0 -> output)
    # ------------------------------------------------------------------
    def read_config(self):
        """Read the Configuration register:
        returned bit = 1 means the pin is an input."""
        return self._read_register(REG_CONFIG)

    def write_config(self, value):
        """Write the Configuration register:
        value bit = 1 makes the pin an input, bit = 0 an output."""
        value = value & 0xFF
        _debug("write_config: 0x%02X" % value)
        return self._write_register(REG_CONFIG, value)

    def set_pin_direction(self, pin, is_input):
        """Set the direction of one pin (0..7) without touching the others.

        is_input : True -> pin becomes an input (high-Z),
                   False -> pin becomes an output."""
        if not (0 <= pin <= 7):
            raise ValueError("pin must be in 0..7, got %r" % (pin,))
        bit = PINS[pin]
        temp = self.read_config()
        value = temp | bit if is_input else temp & ~bit
        _debug("set_pin_direction(pin %d -> %s)" % (pin,
               "input" if is_input else "output"))
        return self._write_register(REG_CONFIG, value)

    # ------------------------------------------------------------------
    # pin helpers
    # ------------------------------------------------------------------
    def set_pin(self, pin, level):
        """Set one output pin (0..7) high (level=1) or low (level=0),
        keeping the other output pins as-is."""
        if not (0 <= pin <= 7):
            raise ValueError("pin must be in 0..7, got %r" % (pin,))
        bit = PINS[pin]
        temp = self.read_output()
        value = temp | bit if level else temp & ~bit
        _debug("set_pin(pin %d, level %d)" % (pin, level))
        return self._write_register(REG_OUTPUT, value)

    def read_pin(self, pin):
        """Read one input pin (0..7): returns 1 or 0."""
        if not (0 <= pin <= 7):
            raise ValueError("pin must be in 0..7, got %r" % (pin,))
        return 1 if self.read_input() & PINS[pin] else 0
