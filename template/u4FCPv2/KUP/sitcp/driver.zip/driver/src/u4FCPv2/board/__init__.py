# package
# u4FCPv2/board/__init__.py
"""L3 board layer: board-specific composition of the device layer.

Contents mirror docs/reg_table.md (registers), the JTAG switch wiring, the FPGA
system monitor, the 16-channel lv power control/monitoring, the high voltage
control/monitoring and the front-end module chip-select lines.
"""
from .reg import reg
from .jtag_sw import jtag_sw
from .sysmon import sysmon
from .lv_power import lv_power
from .hv_power import hv_power
from .module_cs import module_cs

__all__ = ['reg', 'jtag_sw', 'sysmon', 'lv_power', 'hv_power', 'module_cs']
