#!/usr/bin/python
# This is cli.py file
# application entry point: bring-up checks for the u4FCPv2 board
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
from .board.reg import reg
from .board.jtag_sw import jtag_sw
from .board.sysmon import sysmon
from .board.lv_power import lv_power, MODULE_COUNT
from .board.module_cs import module_cs

# SiTCP target of the board: every device created below talks to this FPGA
# over RBCP/UDP, so the address is given once here and passed on explicitly.
DEVICE_IP = "192.168.10.16"
UDP_PORT  = 4660

# FPGA I2C-core base addresses: the low-voltage chain (lv power, module CS,
# monitors, NTC) sits behind 0x00020100 and the JTAG switch behind 0x00020000.
# The high-voltage chain behind 0x00020200 is not checked from here.
LV_BASE_ADDRESS   = 0x00020100
JTAG_BASE_ADDRESS = 0x00020000

# 7-bit I2C address of the tca9554a that carries the JTAG switch.
JTAG_ADDR = 0b0111_001

# Output voltage stored into the pot of every module by
# MODULE_POWER_SAVE_CONFIG, unit: V. It has to stay inside the range the pot
# can reach (POT_V_MIN_V..POT_V_MAX_V of lv_power, 1.2..3.60 V).
MODULE_OUTPUT_V = 2.1

# ---------------------------------------------------------------------------
# Bring-up switches: 1 runs that check, 0 skips it. Most of them WRITE to the
# board, so a run is not a read-only operation - TEST_REG reads the
# read-to-clear status latches (which clears them), RESET_MODULE pulses a
# front-end reset, MODULE_CS drives the chip-select lines,
# MODULE_POWER_SAVE_CONFIG stores new pot values and the clock switches change
# the clock source.
# ---------------------------------------------------------------------------
TEST_REG                 = 1  # print the board status registers
TEST_SYSMON              = 0  # print the FPGA system monitor
ENABLE_USB_JTAG          = 1  # take the JTAG mux to the USB cable
USE_EXTERNAL_CLK         = 0  # clock from the AMC instead of the on-board one
USE_INTERNAL_CLK         = 0  # on-board/local clock (the other alternative)
MODULE_POWER_SAVE_CONFIG = 0  # store MODULE_OUTPUT_V in every module pot
RESET_MODULE             = 0  # pulse a reset of the front-end modules
MODULE_CS                = 0  # exercise the 16 module chip-select lines


def main():
    """Run the bring-up checks whose switch above is 1, in the order they
    appear.

    The switches are edited in this file, so main() takes no arguments. A check
    that fails raises out of the call (an RBCP timeout, for instance), so the
    checks below it are then left unrun."""
    #################################################################
    # board status registers (the latched ones are read-to-clear)
    if TEST_REG:
        board_reg = reg(DEVICE_IP, UDP_PORT)
        board_reg.print_status()
        print("")

    #################################################################
    # FPGA system monitor
    if TEST_SYSMON:
        fpga_sysmon = sysmon(DEVICE_IP, UDP_PORT)
        fpga_sysmon.print_status()
        print("")

    #################################################################
    # JTAG by USB cable
    if ENABLE_USB_JTAG:
        jtag_switch = jtag_sw(DEVICE_IP, UDP_PORT, JTAG_BASE_ADDRESS,
                              JTAG_ADDR)
        jtag_switch.enable_con()          # use the USB JTAG cable
        # jtag_switch.disable_con()       # use the AMC JTAG instead
        jtag_switch.get_status()
        print("")

    #################################################################
    # clock source (bit 0 of the clk register 0x0b: 0 = on-board clock,
    # 1 = external clock from the AMC). The two clock switches are
    # alternatives, so only one of them belongs to a run.
    if USE_EXTERNAL_CLK:
        board_reg = reg(DEVICE_IP, UDP_PORT)
        board_reg.set_clk_ext(True)       # external clock from the AMC
        # board_reg.set_clk_ext(False)    # on-board clock instead
        print("clk           : 0x%02X" % board_reg.read_clk())
        print("")

    if USE_INTERNAL_CLK:
        board_reg = reg(DEVICE_IP, UDP_PORT)
        board_reg.set_clk_ext(False)      # on-board/local clock
        # board_reg.set_clk_ext(True)     # external clock from the AMC
        print("clk           : 0x%02X" % board_reg.read_clk())
        print("")

    #################################################################
    # store the module power-save output voltage
    if MODULE_POWER_SAVE_CONFIG:
        lv_pwr = lv_power(DEVICE_IP, UDP_PORT, LV_BASE_ADDRESS)
        lv_pwr.init()
        for module in range(MODULE_COUNT):
            lv_pwr.set_potentiometer(module, MODULE_OUTPUT_V, store = True)
        print("")

    #################################################################
    # reset the front-end modules
    if RESET_MODULE:
        board_reg = reg(DEVICE_IP, UDP_PORT)
        board_reg.mod_reset()
        print("")

    #################################################################
    # module chip-select lines
    if MODULE_CS:
        # the instance is not called module_cs: that is the imported class, and
        # assigning it here would make the name a local of main(), so the
        # module_cs(...) on the right would read it before it is bound
        cs = module_cs(DEVICE_IP, UDP_PORT, LV_BASE_ADDRESS)
        cs.init()                         # pins become outputs, all released
        cs.select_all()                   # drive every line low
        cs.print_status()
        cs.deselect_all()                 # release every line again
        cs.print_status()
        cs.select(3)                      # one line low
        cs.print_status()
        cs.deselect(3)                    # release it
        cs.print_status()
        print("")


if __name__ == "__main__":
    main()
