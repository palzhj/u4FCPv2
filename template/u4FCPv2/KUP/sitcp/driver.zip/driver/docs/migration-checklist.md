# Migration checklist: flat layout -> layered `src/` layout

> **Applied 2026-09-10.** Sections 1, 2, 3, 6 and 7 were executed. Sections 4
> (CapWords class renames) and 5 (bus injection) were intentionally skipped: class
> names stay lowercase and drivers keep building their own bus, so
> `tests/test_drivers.py` replaces the bus class inside each device module
> instead of injecting a fake. The steps below remain as the record of what was
> done and as instructions for the remaining optional work.
>
> Verification after the move: `python3 tests/test_drivers.py` -> 146 checks
> passed; the CLI runs both via `scripts/debug.py` and via an editable install
> (`pip install -e .`). `lint-imports` was not available, so `.importlinter` is in
> place but unexecuted.

Companion to `docs/architecture.md`. The steps are ordered so the repository
keeps working after every step; keep the test suite green (146 checks) after each
group.

## 0. Baseline

- [ ] `python3 test.py` passes and `python3 -m py_compile` is clean for all files.
- [ ] Record the current tree: `find . -name __pycache__ -prune -o -type f -print | sort > /tmp/before.txt`
- [ ] Create a branch, e.g. `git checkout -b reorg/layered-src-layout`.

## 1. Create the target tree and move files (`git mv` keeps history)

- [ ] `mkdir -p src/u4FCPv2/{transport,bus,devices,board} docs/datasheets tests`
- [ ] `git mv lib/rbcp.py   src/u4FCPv2/transport/rbcp.py`
- [ ] `git mv lib/i2c.py    src/u4FCPv2/bus/i2c.py`
- [ ] `git mv lib/spi.py    src/u4FCPv2/bus/spi.py`
- [ ] `git mv lib/sysmon.py src/u4FCPv2/board/sysmon.py`
- [ ] For each driver folder, move the module out of its own package:

      git mv ads1114/ads1114.py          src/u4FCPv2/devices/ads1114.py
      git mv ina745/ina745.py            src/u4FCPv2/devices/ina745.py
      git mv tca9548a/tca9548a.py        src/u4FCPv2/devices/tca9548a.py
      git mv tca9554a/tca9554a.py        src/u4FCPv2/devices/tca9554a.py
      git mv tcal6416/tcal6416.py        src/u4FCPv2/devices/tcal6416.py
      git mv tmp4718/tmp4718.py          src/u4FCPv2/devices/tmp4718.py
      git mv tpl0401a_10/tpl0401a_10.py  src/u4FCPv2/devices/tpl0401a_10.py

- [ ] `git mv board/reg.py src/u4FCPv2/board/reg.py`
- [ ] `git mv board/jtag_sw.py src/u4FCPv2/board/jtag_sw.py`
- [ ] `git mv board/reg_table.md docs/reg_table.md`
      (it is the board register map, not a package data file: it stays under
      `docs/` and is not shipped inside `u4FCPv2/board/`, so the driver only
      refers to it by path)
- [ ] Move datasheets out of the importable packages:
      `git mv <each>/*.pdf docs/datasheets/`
      (ads1114.pdf, ina745a.pdf, tca9548a.pdf, tca9554a.pdf, tcal6416.pdf,
      tmp4718.pdf, tpl0401a-10.pdf, i2c_specs.pdf)
- [ ] Delete leftovers: `git rm tca9554a/tca9554a.txt`, old `lib/__init__.py`,
      and the now-empty `*/__init__.py` of each driver folder.
- [ ] Remove the empty `lib/`, `ads1114/`, `ina745/`, `tca9548a/`, `tca9554a/`,
      `tcal6416/`, `tmp4718/`, `tpl0401a_10/` directories.

## 2. Explicit package initializers (no wildcard re-exports)

- [ ] `src/u4FCPv2/__init__.py` — docstring only, no imports.
- [ ] `src/u4FCPv2/transport/__init__.py`:
      `from .rbcp import Rbcp, RbcpError, RbcpTimeout, RbcpBusError`
- [ ] `src/u4FCPv2/bus/__init__.py`:
      `from .i2c import I2c` and `from .spi import Spi`
- [ ] `src/u4FCPv2/devices/__init__.py`: one explicit line per driver, e.g.
      `from .tca9548a import TCA9548A` (plus the constants callers use, such as
      `CH0..CH7`, `PORT0`, `REG_*` if they are part of the public API).
- [ ] `src/u4FCPv2/board/__init__.py`:
      `from .reg import Reg`, `from .jtag_sw import JtagSw`, `from .sysmon import Sysmon`

This also removes the failure mode already hit twice in `init.py`: a wildcard
re-export shadows the submodule of the same name, so `from X import X` returned
the class and `X.X(...)` raised `AttributeError`.

## 3. Rewrite imports (downward only)

- [ ] In every driver replace:

      import lib                       -> (delete)
      from lib import i2c              -> from ..bus.i2c import I2c
      i2c.i2c(device_address = ...)    -> I2c(device_address = ...)

- [ ] In `bus/i2c.py`, `bus/spi.py`, `board/sysmon.py` replace:

      import lib                       -> (delete)
      from lib import rbcp             -> from ..transport.rbcp import Rbcp
      rbcp.Rbcp()                      -> Rbcp()

- [ ] In `board/reg.py`: `from lib import rbcp` -> `from ..transport.rbcp import Rbcp`
      and `rbcp.Rbcp(...)` -> `Rbcp(...)`.
- [ ] In `board/jtag_sw.py`: `import tca9554a.tca9554a` ->
      `from ..devices.tca9554a import TCA9554A`, and `tca9554a.tca9554a(` -> `TCA9554A(`.
- [ ] Delete every `sys.path.insert(...)` (in `init.py`, `test.py`) — after step 5
      the package is installed and none is needed.

## 4. Class names in CapWords (optional but recommended)

- [ ] `tca9548a -> TCA9548A`, `tca9554a -> TCA9554A`, `tcal6416 -> TCAL6416`,
      `ads1114 -> ADS1114`, `ina745 -> INA745`, `tmp4718 -> TMP4718`,
      `tpl0401a -> TPL0401A`, `reg -> Reg`, `jtag_sw -> JtagSw`,
      `sysmon -> Sysmon`, `spi -> Spi`, `i2c -> I2c` (`Rbcp` already correct).
- [ ] Keep the old lowercase names as thin aliases for one release if any script
      outside this repository imports them.

## 5. Inject the bus/transport instead of constructing it

- [ ] Add `bus = None` to all seven device constructors and use
      `self.bus = bus if bus is not None else I2c(...)`.
- [ ] Add `transport = None` to `I2c`, `Spi`, `Sysmon` and use
      `self._rbcp = transport if transport is not None else Rbcp()`.
- [ ] Replace the seven `self.i2c = i2c.i2c(...)` call sites
      (`ads1114:145`, `ina745:177`, `tca9548a:95`, `tca9554a:103`,
      `tcal6416:119`, `tmp4718:163`, `tpl0401a_10:88`).
- [ ] Rename the attribute `self.i2c` to `self.bus` and update the `self.i2c.`
      call sites inside each driver.

## 6. Applications and tests

- [ ] `src/u4FCPv2/cli.py`: turn `init.py` into `main()` (keep the
      `TEST_*` / `ENABLE_USB_JTAG` / `MODULE_POWER_EN` switches as constants or
      CLI flags); keep the fixed device addresses and base addresses as-is.
- [ ] `pyproject.toml`: add `[project.scripts] board-init = "u4FCPv2.cli:main"`,
      then run `board-init` instead of `python init.py`.
- [ ] `scripts/debug.py`: optional one-line wrapper (`from u4FCPv2.cli import main`)
      for people who still type `python init.py`.
- [ ] `tests/conftest.py`: provide `FakeRbcp` and `FakeI2c` fixtures; convert the
      stub buses of `test.py` into those fixtures.
- [ ] Port `test.py` to `tests/test_*.py` (pytest), passing the fake bus via the
      new `bus=` argument instead of monkeypatching `lib.i2c.i2c`.

## 7. Packaging and verification

- [ ] Add `pyproject.toml` exactly as in `docs/architecture.md` (setuptools,
      `where = ["src"]`, stdlib-only dependencies).
- [ ] `pip install -e .` then confirm imports work from an unrelated directory:

      cd /tmp && python3 -c "from u4FCPv2.devices import TCA9548A; print(TCA9548A)"

- [ ] `python3 -m pytest tests/ -q` is green.
- [ ] Copy `docs/importlinter.ini.example` to `.importlinter`; `pip install import-linter`;
      `lint-imports` reports no broken contracts.
- [ ] Add both to CI: `lint-imports && pytest -q`.
- [ ] Diff the move: `git status --porcelain` should show renames, not rewrites,
      and `find . -name __pycache__ -prune -o -type f -print | sort` should match
      the target tree in `docs/architecture.md`.

## Definition of done

- [ ] Layering is acyclic and downward-only, verified by `lint-imports`.
- [ ] No `sys.path` manipulation anywhere in the repository.
- [ ] No wildcard re-exports; every package lists its public names explicitly.
- [ ] Device drivers receive their bus; tests use fakes rather than monkeypatching.
- [ ] `pip install .` (or `-e .`) is the only setup step; no repository-root
      assumption remains in the code.
- [ ] Datasheets live under `docs/`, not inside importable packages.

## Rollback

The reorg is a pure move plus import rewrite: `git revert` of the merge commit
(or `git checkout main -- .`) restores the flat layout. Keeping the old
lowercase class names as aliases in step 4 makes the transition reversible for
out-of-tree scripts too.
