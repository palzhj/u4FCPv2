# Architecture: layer order and dependency direction

Status: **applied 2026-09-10.** The layout below is in place; the executed steps
are recorded in `migration-checklist.md`. Two optional steps from that checklist
were intentionally not applied: CapWords class renames (section 4) and bus
injection (section 5) — drivers still construct their own bus, and the tests
replace the bus class inside each device module.

## Why order matters

The components form a strict chain: an application call travels downward
(`app -> board -> device -> bus -> transport`), and a build/install travels
upward (`transport -> bus -> devices -> board -> app`). If folders mirror that
chain and imports may only point **downward**, then:

* installing bottom-up always satisfies dependencies without manual ordering;
* a component can be tested with everything below it faked;
* moving a component down a layer never breaks the layers above it.

## Target layout

```
driver/                                    # repository root
├─ pyproject.toml
├─ .importlinter                           # layering contract (see below)
├─ docs/
│  ├─ architecture.md                      # this file
│  ├─ migration-checklist.md
│  └─ datasheets/*.pdf                     # PDFs out of the code packages
├─ src/
│  └─ u4FCPv2/                             # single installable distribution
│     ├─ __init__.py
│     ├─ transport/                        # L0
│     │  ├─ __init__.py
│     │  └─ rbcp.py                        # from lib/rbcp.py
│     ├─ bus/                              # L1
│     │  ├─ __init__.py
│     │  ├─ i2c.py                         # from lib/i2c.py
│     │  └─ spi.py                         # from lib/spi.py
│     ├─ devices/                          # L2
│     │  ├─ __init__.py
│     │  ├─ tca9548a.py
│     │  ├─ tca9554a.py
│     │  ├─ tcal6416.py
│     │  ├─ ads1114.py
│     │  ├─ ina745.py
│     │  ├─ tmp4718.py
│     │  └─ tpl0401a_10.py
│     ├─ board/                            # L3
│     │  ├─ __init__.py
│     │  ├─ reg.py
│     │  ├─ jtag_sw.py
│     │  ├─ sysmon.py                      # from lib/sysmon.py
│     │  ├─ lv_power.py
│     │  ├─ hv_power.py
│     │  └─ module_cs.py                   # front-end module chip-select lines
│     └─ cli.py                            # L4, replaces init.py
├─ scripts/
│  └─ debug.py                             # optional thin wrapper
└─ tests/
   ├─ conftest.py                          # fake transport/bus fixtures
   └─ test_*.py
```

## Layers

| Priority | Layer | Package | May import | Build/install |
|---|---|---|---|---|
| 1 (called first) | L4 apps | `u4FCPv2.cli`, `scripts/`, `tests/` | L3 and below | last |
| 2 | L3 board | `u4FCPv2.board` | L2, L1, L0 | 4th |
| 3 | L2 devices | `u4FCPv2.devices` | L1, L0 | 3rd |
| 4 | L1 bus | `u4FCPv2.bus` | L0 | 2nd |
| 5 (called last) | L0 transport | `u4FCPv2.transport` | stdlib only | 1st |

Rules:

1. **Downward only.** A module may import modules of its own layer or lower,
   never higher, never sideways between sibling components of the same layer.
2. **No `sys.path` manipulation.** Everything is installed as a package; no
   `sys.path.insert(...)` in library or application code.
3. **No wildcard re-exports.** Each package `__init__.py` re-exports explicit
   names (`from .tca9548a import TCA9548A`), never `from .mod import *`.
4. **The bus is injected, not constructed.** A device driver receives its bus;
   only the application (or a board helper) decides which transport/bus to build.
5. **Semantic folder names.** Folders cannot start with a digit, so the call
   priority is expressed by the layer documentation and the import-linter
   contract above, not by numeric prefixes such as `1_bus`.

## Before the move (for reference)

| Item | Before | Now |
|---|---|---|
| Transport | `lib/rbcp.py` | `src/u4FCPv2/transport/rbcp.py` |
| Bus | `lib/i2c.py`, `lib/spi.py` | `src/u4FCPv2/bus/{i2c,spi}.py` |
| FPGA sysmon reader | `lib/sysmon.py` | `src/u4FCPv2/board/sysmon.py` |
| Chip drivers | `ads1114/`, `ina745/`, `tca9548a/`, `tca9554a/`, `tcal6416/`, `tmp4718/`, `tpl0401a_10/` | `src/u4FCPv2/devices/` |
| Board composition | `board/reg.py`, `board/jtag_sw.py` | `src/u4FCPv2/board/` (with `__init__.py`) |
| Applications | `init.py`, `test.py` | `src/u4FCPv2/cli.py`, `scripts/debug.py`, `scripts/init.py`, `tests/` |
| Datasheets | inside each driver package | `docs/datasheets/` |
| Packaging | none | `pyproject.toml` (+ `.importlinter`) |

Structural issues that the move resolved:

* `lib/` mixed three layers (transport `rbcp`, buses `i2c`/`spi`, and the
  device-level `sysmon`) — now split into `transport/`, `bus/`, `board/`.
* Every library module started with `import lib` + `from lib import rbcp`,
  which only resolved because the parent of `lib/` happened to be on `sys.path`
  — replaced by relative downward imports (`from ..transport.rbcp import Rbcp`).
* `init.py` and `test.py` inserted the repository root into `sys.path` — the CLI
  and the package no longer do (the standalone test adds `src/` only so it can
  run from a checkout without an install).
* `board/` was a namespace package (no `__init__.py`) — it has one now.
* `tca9554a/tca9554a.txt` leftover and the in-package PDFs were removed/moved.

Still open (deliberate, see migration-checklist.md):

* The seven drivers still build their own bus (`self.i2c = i2c(...)`) instead of
  taking `bus=` — so `tests/test_drivers.py` swaps the bus class inside each
  device module rather than injecting a fake.
* Class names remain lowercase (`tca9548a`), not CapWords (`TCA9548A`).
* `lint-imports` is not installed here, so `.importlinter` is present but has not
  been executed yet.

## Install order vs call order

*Single distribution (recommended).* Declare one project and let the resolver
order the build; the layering exists to keep imports acyclic, not to be managed
by hand:

```toml
[project]
name = "u4FCPv2"
version = "0.1.0"
requires-python = ">=3.8"
dependencies = []                 # stdlib only today

[project.scripts]
board-init = "u4FCPv2.cli:main"

[build-system]
requires = ["setuptools>=61"]
build-backend = "setuptools.build_meta"

[tool.setuptools.packages.find]
where = ["src"]
```

```bash
pip install -e .        # development
pip install .           # deployment (builds transport -> ... -> cli internally)
```

Naming note: `u4FCPv2` is the project/display name. Two consequences worth
knowing before the first release:

* PyPI/PEP 503 normalises distribution names to lowercase, so `pip install
  u4FCPv2` and `pip install u4fcpv2` resolve to the same project (`u4fcpv2`);
  the metadata `name` can stay `u4FCPv2`.
* Python **imports are case sensitive** while macOS and Windows file systems are
  not. If this repository may be checked out on those platforms, consider
  keeping the import package lowercase (`src/u4fcpv2/`, `from u4fcpv2.devices
  import TCA9548A`) while the pyproject `name` stays `u4FCPv2`. Renaming the
  import root later is mechanical but touches every import line, so decide it
  before running `migration-checklist.md`, not after.

*Chained distributions (only if a layer is reused elsewhere).* Publish
`u4FCPv2-rbcp` → `u4FCPv2-bus-i2c` (depends on `u4FCPv2-rbcp`) → `u4FCPv2-devices`
(depends on `u4FCPv2-bus-i2c`) → `u4FCPv2` → application, each pinning the one
below it (`dependencies = ["u4FCPv2-bus-i2c~=1.2"]`). Installation then literally
proceeds in descending priority, at the cost of several repositories, a version
matrix and an internal package index.

## Dependency injection (what makes the layering enforceable)

Still to do — the seven drivers currently build their own bus
(`src/u4FCPv2/devices/ads1114.py`, `ina745.py`, `tca9548a.py`, `tca9554a.py`,
`tcal6416.py`, `tmp4718.py`, `tpl0401a_10.py`):

```python
self.i2c = i2c.i2c(device_address = i2c_addr, base_address = base_address,
                   clk_freq = clk_freq, i2c_freq = i2c_freq)
```

Target: the driver accepts the bus, and only the caller decides what to build.

```python
class TCA9548A:
    def __init__(self, i2c_addr = 0x73, bus = None, base_address = 0x00020000,
                 clk_freq = 125, i2c_freq = 100):
        self.bus = bus if bus is not None else I2c(
            device_address = (i2c_addr << 1), base_address = base_address,
            clk_freq = clk_freq, i2c_freq = i2c_freq)
```

The same pattern one layer down keeps the transport swappable:

```python
I2c(device_address = ..., transport = Rbcp(device_ip = "192.168.10.16",
                                           udp_port = 4660))
```

Benefits: `tests/` passes a `FakeBus` instead of monkeypatching module
internals; the board layer can share one bus across devices; no upward import is
ever needed.

## Enforcement

See `docs/importlinter.ini.example` for a contract that fails the build when an
import points the wrong way. Add it to CI together with `pytest` so the
direction is verified mechanically rather than by review.
