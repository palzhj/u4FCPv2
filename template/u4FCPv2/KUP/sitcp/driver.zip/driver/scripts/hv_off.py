#!/usr/bin/python
# This is hv_off.py file
# shut the high voltage of the board down
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
import os
import sys
import time

# allow running straight from a checkout ("python scripts/hv_off.py")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from u4FCPv2.board.hv_power import hv_power  # noqa: E402

# default SiTCP target of the board, changed with -ip / -port
DEVICE_IP = "192.168.10.16"
UDP_PORT  = 4660

# FPGA I2C-core base address of the high-voltage devices
BASE_ADDRESS = 0x00020200

# wait after the stop before reading the monitors, unit: s. The supply and its
# output capacitors discharge in this time.
HV_OFF_DELAY_S = 1.0

USAGE = ("usage: %s [-ip ADDR] [-port PORT]\n"
         "  -ip ADDR   : board IP address (default %s)\n"
         "  -port PORT : board RBCP UDP port (default %d)")


def usage(program = None):
    """Return the usage text, with the script name and the current defaults."""
    return USAGE % (program or os.path.basename(sys.argv[0]), DEVICE_IP,
                    UDP_PORT)


def _port(text, text_usage):
    """Return the UDP port given on the command line."""
    try:
        port = int(text, 0)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0 < port < 65536):
        raise SystemExit(text_usage)
    return port


def parse_args(argv):
    """Return (device_ip, udp_port) from the command line; -ip and -port
    override the default board target."""
    device_ip, udp_port = DEVICE_IP, UDP_PORT
    text_usage = usage(os.path.basename(argv[0]))
    index = 1
    while index < len(argv):
        option = argv[index]
        if option in ("-h", "--help"):
            print(text_usage)
            raise SystemExit(0)
        if option in ("-ip", "--ip") and index + 1 < len(argv):
            device_ip = argv[index + 1]
            index += 2
        elif option in ("-port", "--port") and index + 1 < len(argv):
            udp_port = _port(argv[index + 1], text_usage)
            index += 2
        elif option in ("-ip", "--ip", "-port", "--port"):
            raise SystemExit(text_usage)        # option without its value
        else:
            raise SystemExit(text_usage)        # this script takes no argument
    return device_ip, udp_port


def main():
    """Shut the high voltage down and print the result.

    The monitor ADS1114 is put back to its default window first, before the
    level is touched: hv_power.write_thresholds() with no limits writes the
    reset values back into both threshold registers, so a window set for a live
    supply (hv_power.init) cannot report an under/over-voltage
    while the output is going down. The potentiometer is then driven down to
    0 V, so the output comes down from whatever level it
    was left at, and the emergency stop (hv register 0x0d, bit 0) is engaged
    after that, so the supply is left off whatever state it was in. After
    HV_OFF_DELAY_S seconds - the supply and its output capacitors discharge in
    that time - the latched high-voltage over-current alarm is cleared
    (mod_sta_lch, register 0x0a, is read-to-clear) and the state is printed.
    -ip and -port select another board than the default one."""
    device_ip, udp_port = parse_args(sys.argv)
    hv = hv_power(device_ip, udp_port, BASE_ADDRESS, shutdown = False)
    hv.write_thresholds()                   # monitor window back to the reset
                                            # values, before the level is touched
    hv.set_voltage(0)                       # level down to 0 V first
    time.sleep(HV_OFF_DELAY_S)              # let the supply discharge
    hv.emergency_stop()                     # then high voltage OFF
    time.sleep(HV_OFF_DELAY_S)              # let the supply discharge
    hv.clear_monitor_int()                  # release a latch left by a past run
    hv.hv_alarm_latch()                     # read-to-clear: drop the latched alarm
    print("HV OFF, but note that the discharge process takes a relatively long time!")

if __name__ == "__main__":
    main()
