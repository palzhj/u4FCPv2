#!/usr/bin/python
# This is debug.py file
# thin wrapper: run the bring-up checks of u4FCPv2.cli without installing
# the console script
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
import os
import sys

# allow running straight from a checkout ("python scripts/debug.py")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from u4FCPv2.cli import main  # noqa: E402

if __name__ == "__main__":
    main()
