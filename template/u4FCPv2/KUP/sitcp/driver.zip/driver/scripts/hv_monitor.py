#!/usr/bin/python
# This is hv_monitor.py file
# refresh the high voltage monitor of the board in the terminal
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
import os
import sys
import time

# allow running straight from a checkout ("python scripts/hv_monitor.py 2")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from u4FCPv2.board.hv_power import hv_power  # noqa: E402

# default SiTCP target of the board, changed with -ip / -port
DEVICE_IP = "192.168.10.16"
UDP_PORT  = 4660

# FPGA I2C-core base address of the high-voltage devices
BASE_ADDRESS = 0x00020200

# default refresh period, unit: s (the command line argument overrides it)
REFRESH_S = 5.0

# ANSI escape sequence: erase the display and put the cursor at the home position
CLEAR_SCREEN = "\033[2J\033[H"

# Highlighting of the values that changed since the previous refresh: a changed
# value is printed inverted (ANSI reverse video, so foreground and background
# swap and the field keeps its width), and a value has to move by TOLERANCE to
# count as changed (the states - stopped, the control state and the alarm - are
# compared as states, so any change counts). Without a threshold the measured
# voltage would light up on every refresh, since the monitor always moves by its
# last digit.
HIGHLIGHT = "\033[7m"       # reverse video: colour invert
NORMAL    = "\033[0m"
TOLERANCE = {"measured": 1.0,    # V
             "monitor_v": 0.01,  # V
             "setpoint": 1.0,    # V
             "resistance": 10.0} # ohm

USAGE = ("usage: %s [-ip ADDR] [-port PORT] [-all] [interval]\n"
         "  -ip ADDR   : board IP address (default %s)\n"
         "  -port PORT : board RBCP UDP port (default %d)\n"
         "  -all       : highlight every change, however small (default: only\n"
         "               changes beyond the per-value tolerance)\n"
         "  interval   : refresh period in seconds, e.g. 2 or 0.5 (default %s)")


def usage(program = None):
    """Return the usage text, with the script name and the current defaults."""
    return USAGE % (program or os.path.basename(sys.argv[0]), DEVICE_IP,
                    UDP_PORT, REFRESH_S)


def _port(text, text_usage):
    """Return the UDP port given on the command line."""
    try:
        port = int(text, 0)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0 < port < 65536):
        raise SystemExit(text_usage)
    return port


def _interval(text, text_usage):
    """Return the refresh period in seconds given on the command line."""
    try:
        interval = float(text)
    except ValueError:
        raise SystemExit(text_usage)
    if not interval > 0.0:
        raise SystemExit(text_usage)
    return interval


def parse_args(argv):
    """Return (device_ip, udp_port, interval, highlight_all) from the command
    line.

    -ip and -port override the board target, -all marks every change instead of
    only the ones beyond the per-value tolerance, and the optional positional
    argument is the refresh period in seconds (REFRESH_S when it is not
    given)."""
    device_ip, udp_port, highlight_all, rest = DEVICE_IP, UDP_PORT, False, []
    text_usage = usage(os.path.basename(argv[0]))
    index = 1
    while index < len(argv):
        option = argv[index]
        if option in ("-h", "--help"):
            print(text_usage)
            raise SystemExit(0)
        if option in ("-all", "--all"):
            highlight_all = True
            index += 1
        elif option in ("-ip", "--ip") and index + 1 < len(argv):
            device_ip = argv[index + 1]
            index += 2
        elif option in ("-port", "--port") and index + 1 < len(argv):
            udp_port = _port(argv[index + 1], text_usage)
            index += 2
        elif option in ("-ip", "--ip", "-port", "--port"):
            raise SystemExit(text_usage)        # option without its value
        else:
            rest.append(option)
            index += 1
    if len(rest) > 1:
        raise SystemExit(text_usage)
    return (device_ip, udp_port,
            _interval(rest[0], text_usage) if rest else REFRESH_S,
            highlight_all)


def _changed(name, before, after, tolerance = None):
    """Return True when a value moved enough to be worth highlighting.

    `tolerance` is the per-value threshold table; an empty table marks every
    change, however small."""
    if tolerance is None:
        tolerance = TOLERANCE
    if name in ("on", "state", "alarm"):
        return before != after          # states: any change counts
    try:
        return abs(float(after) - float(before)) > tolerance.get(name, 0.0)
    except (TypeError, ValueError):
        return before != after


def highlighter(state, tolerance = None):
    """Return the cell marker for hv_power.print_status().

    The marker compares every value with the one from the previous refresh,
    wraps the ones that changed in HIGHLIGHT and stores the new values in
    `state`, so a refresh only marks what really moved. The first refresh has
    nothing to compare against, so it prints everything plainly; `tolerance`
    selects how far a value has to move (see TOLERANCE, or an empty table for
    "any change")."""
    def marker(name, value, text):
        before = state.get(name, value)
        state[name] = value
        if _changed(name, before, value, tolerance):
            return HIGHLIGHT + text + NORMAL
        return text
    return marker


def main():
    """Print the high-voltage status until interrupted.

    The terminal is cleared and rewritten every `interval` seconds (the command
    line argument, REFRESH_S by default), so the monitor stays in place instead
    of scrolling; the period is kept even when reading takes a noticeable part
    of it. A failed read is reported and the monitor keeps running, since a
    monitoring loop should survive a transient bus error.

    Every value that changed since the previous refresh is printed inverted
    (colour invert), which makes the supply being stopped, the level moving or
    an over-current easy to spot; -all marks every change instead of only the
    ones beyond the per-value tolerance.

    The supply is left exactly as it is found: the object is created with
    shutdown = False, so monitoring never engages the emergency stop."""
    device_ip, udp_port, interval, highlight_all = parse_args(sys.argv)
    hv = hv_power(device_ip, udp_port, BASE_ADDRESS, shutdown = False)
    state = {}
    marker = highlighter(state, {} if highlight_all else None)
    try:
        while True:
            started = time.time()
            sys.stdout.write(CLEAR_SCREEN)
            print("high voltage monitor   %s   %s:%d   refresh %.1fs   "
                  "(Ctrl-C to stop)"
                  % (time.strftime("%Y-%m-%d %H:%M:%S"), device_ip, udp_port,
                     interval))
            print("")
            try:
                hv.print_status(marker = marker)
            except Exception as error:
                print("read error: %s" % error)
            sys.stdout.flush()
            time.sleep(max(0.0, interval - (time.time() - started)))
    except KeyboardInterrupt:
        print("stopped")


if __name__ == "__main__":
    main()
