#!/usr/bin/python
# This is lv_off.py file
# switch the lv power of the board off: one module or the whole board
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
import os
import sys
import time

# allow running straight from a checkout ("python scripts/lv_off.py -ip 192.168.10.16 3")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from u4FCPv2.board.lv_power import (lv_power, MODULE_COUNT,  # noqa: E402
                                    OC_LIMIT_MAX_A)

# default SiTCP target of the board, changed with -ip / -port
DEVICE_IP = "192.168.10.16"
UDP_PORT  = 4660

# FPGA I2C-core base address used by the lv power devices
BASE_ADDRESS = 0x00020100

# wait after switching the power off, unit: s. The module rails discharge in
# this time, so the monitors are read after the supply has really gone.
POWER_OFF_DELAY_S = 1.0

USAGE = ("usage: %s [-ip ADDR] [-port PORT] [module]\n"
         "  -ip ADDR   : board IP address (default %s)\n"
         "  -port PORT : board RBCP UDP port (default %d)\n"
         "  module     : switch that module off (0..%d), the main power stays on\n"
         "  none       : switch the whole board off (both stages)")


def usage(program = None):
    """Return the usage text, with the script name and the current defaults."""
    return USAGE % (program or os.path.basename(sys.argv[0]), DEVICE_IP,
                    UDP_PORT, MODULE_COUNT - 1)


def _port(text, text_usage):
    """Return the UDP port given on the command line."""
    try:
        port = int(text, 0)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0 < port < 65536):
        raise SystemExit(text_usage)
    return port


def _module(text, text_usage):
    """Return the module number given on the command line."""
    try:
        module = int(text, 0)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0 <= module < MODULE_COUNT):
        raise SystemExit(text_usage)
    return module


def parse_args(argv):
    """Return (device_ip, udp_port, module) from the command line.

    -ip and -port override the board target; the optional positional argument
    is the module to switch off (None = every module, i.e. the whole board)."""
    device_ip, udp_port, rest = DEVICE_IP, UDP_PORT, []
    text_usage = usage(os.path.basename(argv[0]))
    index = 1
    while index < len(argv):
        option = argv[index]
        if option in ("-h", "--help"):
            print(text_usage)
            raise SystemExit(0)
        if option in ("-ip", "--ip") and index + 1 < len(argv):
            device_ip = argv[index + 1]
            index += 2
        elif option in ("-port", "--port") and index + 1 < len(argv):
            udp_port = _port(argv[index + 1], text_usage)
            index += 2
        elif option in ("-ip", "--ip", "-port", "--port"):
            raise SystemExit(text_usage)        # option without its value
        else:
            rest.append(option)
            index += 1
    if len(rest) > 1:
        raise SystemExit(text_usage)
    return device_ip, udp_port, (_module(rest[0], text_usage) if rest else None)


def main():
    """Switch the lv power off and print the result.

    Without a module argument every module is switched off: the 16 sub-power
    enables of the tcal6416 are cleared first, so the next power-on starts from
    all modules off and ramps them one by one (that write is only allowed while
    the main power is on, so it is skipped when stage 1 is already off), and
    then stage 1 (the board lv register) is switched off.

    With a module number only that module's sub-power enable is cleared and the
    main power stays on, so the other modules keep running.

    The over-current limit of the module (or of every module) is armed at its
    maximum first (OC_LIMIT_MAX_A), so the rails going down cannot trip a limit
    that was left armed for operation - that is also the limit init() leaves
    behind.

    Once the rails have discharged (POWER_OFF_DELAY_S) the latched over-current
    events of the modules are cleared, so the next power-on starts without an old
    trip pending - any module that had one is reported, and the latch lives in
    the INA745, which keeps it even with the rail off. The board-side low-voltage
    alarm is dropped as well, by reading its read-to-clear latch (mod_sta_lch,
    register 0x0a); that read consumes every latched module flag, so the
    low-voltage bit is what is reported from it. The state is printed last.
    -ip and -port select another board than the default one."""
    device_ip, udp_port, module = parse_args(sys.argv)
    lv_pwr = lv_power(device_ip, udp_port, BASE_ADDRESS)
    modules = range(MODULE_COUNT) if module is None else (module,)
    for m in modules:                       # no trip while the rails come down
        lv_pwr.write_oc_limit(m, OC_LIMIT_MAX_A)
    if module is None:
        lv_pwr.power_off_all()              # stage 2 then stage 1
    elif lv_pwr.main_ready():
        lv_pwr.power_off(module)            # that module only, stage 1 stays on
    else:                                   # stage 1 off: the module is off too
        print("main power (stage 1) is already OFF - module %d is off as well"
              % module)

    time.sleep(POWER_OFF_DELAY_S)           # let the rails discharge

    lv_pwr.clear_ntc_int()                    #    drop a latched NTC interrupt
    tripped = [m for m in range(MODULE_COUNT)
               if lv_pwr.clear_oc_interrupt(m)]     # read-to-clear, per module
    if tripped:
        print("cleared over-current events on modules %s" % tripped)
    latched = lv_pwr.main.read_mod_sta_latch()      # read-to-clear: every flag
    if latched["lv_alm"]:
        print("cleared the latched low-voltage over-current alarm")
    if latched["temp_alm"]:
        print("cleared the latched over-temperature alarm")
    if latched["hv_alm"]:                           # same register, same read
        print("cleared the latched high-voltage over-current alarm")

    lv_pwr.print_status()


if __name__ == "__main__":
    main()
