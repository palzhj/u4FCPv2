#!/usr/bin/python
# This is lv_on.py file
# switch the lv power of the board on: one module or the whole board
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
import os
import sys
import time

# allow running straight from a checkout ("python scripts/lv_on.py -ip 192.168.10.16 3")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from u4FCPv2.board.lv_power import lv_power, MODULE_COUNT  # noqa: E402

# default SiTCP target of the board, changed with -ip / -port
DEVICE_IP = "192.168.10.16"
UDP_PORT  = 4660

# FPGA I2C-core base address used by the lv power devices
BASE_ADDRESS = 0x00020100

# over-current limit armed on a module before its rail is switched on, unit: A
OC_LIMIT_A = 1.2

# lv register over-temperature auto power off: 0 = the main power stays on after an over-current
OT_LV_AUTO_OFF = 1

# wait after switching the power on before reading the monitors, unit: s. The
# enables ramp one module at a time, so the rails need a moment to settle
# before the voltage and current readings mean anything.
POWER_ON_DELAY_S = 1.0

USAGE = ("usage: %s [-ip ADDR] [-port PORT] [-oc AMPS] [module]\n"
         "  -ip ADDR   : board IP address (default %s)\n"
         "  -port PORT : board RBCP UDP port (default %d)\n"
         "  -oc AMPS   : over-current limit armed on the module(s) before the\n"
         "               rail is switched on, unit: A (default %s)\n"
         "  module     : switch that module on (0..%d)\n"
         "  none       : switch the whole board on (both stages)")


def usage(program = None):
    """Return the usage text, with the script name and the current defaults."""
    return USAGE % (program or os.path.basename(sys.argv[0]), DEVICE_IP,
                    UDP_PORT, OC_LIMIT_A, MODULE_COUNT - 1)


def _port(text, text_usage):
    """Return the UDP port given on the command line."""
    try:
        port = int(text, 0)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0 < port < 65536):
        raise SystemExit(text_usage)
    return port


def _module(text, text_usage):
    """Return the module number given on the command line."""
    try:
        module = int(text, 0)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0 <= module < MODULE_COUNT):
        raise SystemExit(text_usage)
    return module


def _oc(text, text_usage):
    """Return the over-current limit in amperes given on the command line."""
    try:
        oc_limit = float(text)
    except ValueError:
        raise SystemExit(text_usage)
    if not oc_limit > 0.0:
        raise SystemExit(text_usage)
    return oc_limit


def parse_args(argv):
    """Return (device_ip, udp_port, oc_limit, module) from the command line.

    -ip and -port override the board target and -oc the over-current limit
    armed before power-on; the optional positional argument is the module to
    switch on (None = every module, i.e. the whole board)."""
    device_ip, udp_port, oc_limit, rest = DEVICE_IP, UDP_PORT, OC_LIMIT_A, []
    text_usage = usage(os.path.basename(argv[0]))
    index = 1
    while index < len(argv):
        option = argv[index]
        if option in ("-h", "--help"):
            print(text_usage)
            raise SystemExit(0)
        if option in ("-ip", "--ip") and index + 1 < len(argv):
            device_ip = argv[index + 1]
            index += 2
        elif option in ("-port", "--port") and index + 1 < len(argv):
            udp_port = _port(argv[index + 1], text_usage)
            index += 2
        elif option in ("-oc", "--oc") and index + 1 < len(argv):
            oc_limit = _oc(argv[index + 1], text_usage)
            index += 2
        elif option in ("-ip", "--ip", "-port", "--port", "-oc", "--oc"):
            raise SystemExit(text_usage)        # option without its value
        else:
            rest.append(option)
            index += 1
    if len(rest) > 1:
        raise SystemExit(text_usage)
    return (device_ip, udp_port, oc_limit,
            _module(rest[0], text_usage) if rest else None)


def main():
    """Switch the lv power on and print the result.

    The over-current limit of the module(s) to be switched on is armed first
    (-oc AMPS, OC_LIMIT_A by default), so the monitors already watch the rails
    when they come up.

    Without a module argument every module is switched on by power_on_all():
    stage 1 (the board lv register) followed by the 16 sub-power enables of the
    tcal6416, ramped one module at a time to keep the inrush current of the
    common supply low.

    With a module number only that module is switched on - power_on() turns the
    main power on and then enables that one bit, leaving the other modules as
    they are.

    The state of the modules is printed at the end, after POWER_ON_DELAY_S
    seconds so the rails have settled. -ip and -port select another board than
    the default one."""
    device_ip, udp_port, oc_limit, module = parse_args(sys.argv)
    lv_pwr = lv_power(device_ip, udp_port, BASE_ADDRESS)

    lv_pwr.clear_ntc_int()                    #    drop a latched NTC interrupt
    tripped = [m for m in range(MODULE_COUNT)   # 6. drop the latches
                if lv_pwr.clear_oc_interrupt(m)]
    if tripped:
        print("lv_power: cleared over-current events on modules %s"
                % tripped)
    latched = lv_pwr.main.read_mod_sta_latch()    # read-to-clear: every flag
    if latched["lv_alm"]:
        print("lv_power: cleared the latched low-voltage over-current alarm")
    if latched["temp_alm"]:
        print("lv_power: cleared the latched over-temperature alarm")
    if latched["hv_alm"]:                       # same register, same read
        print("lv_power: cleared the latched high-voltage over-current alarm")

    modules = range(MODULE_COUNT) if module is None else (module,)
    for m in modules:
        lv_pwr.write_oc_limit(m, oc_limit)     # arm before powering the rail
    if module is None:
        lv_pwr.power_on_all(OT_LV_AUTO_OFF)    # stage 1 and stage 2 ON
    else:
        lv_pwr.power_on(module, OT_LV_AUTO_OFF)  # stage 1, then that module

    time.sleep(POWER_ON_DELAY_S)                # let the rails settle

    lv_pwr.print_status()                      # stage 1 state + 16 modules


if __name__ == "__main__":
    main()
