#!/usr/bin/python
# This is init.py file
# initialise the board: lv power off and configured,
# high voltage off with a clean monitor
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
import os
import sys
import time

# allow running straight from a checkout ("python scripts/init.py")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from u4FCPv2.board.lv_power import lv_power  # noqa: E402
from u4FCPv2.board.hv_power import hv_power  # noqa: E402

# default SiTCP target of the board, changed with -ip / -port
DEVICE_IP = "192.168.10.16"
UDP_PORT  = 4660

# FPGA I2C-core base addresses: the low-voltage devices (lv power, monitors,
# NTC) sit behind 0x00020100 and the high-voltage chain behind 0x00020200
LV_BASE_ADDRESS = 0x00020100
HV_BASE_ADDRESS = 0x00020200

# wait at the end, unit: s, so the module rails have discharged before the
# status is read back
INIT_DELAY_S = 1.0

USAGE = ("usage: %s [-ip ADDR] [-port PORT]\n"
         "  -ip ADDR   : board IP address (default %s)\n"
         "  -port PORT : board RBCP UDP port (default %d)")


def usage(program = None):
    """Return the usage text, with the script name and the current defaults."""
    return USAGE % (program or os.path.basename(sys.argv[0]), DEVICE_IP,
                    UDP_PORT)


def _port(text, text_usage):
    """Return the UDP port given on the command line."""
    try:
        port = int(text, 0)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0 < port < 65536):
        raise SystemExit(text_usage)
    return port


def parse_args(argv):
    """Return (device_ip, udp_port) from the command line; -ip and -port
    override the default board target."""
    device_ip, udp_port = DEVICE_IP, UDP_PORT
    text_usage = usage(os.path.basename(argv[0]))
    index = 1
    while index < len(argv):
        option = argv[index]
        if option in ("-h", "--help"):
            print(text_usage)
            raise SystemExit(0)
        if option in ("-ip", "--ip") and index + 1 < len(argv):
            device_ip = argv[index + 1]
            index += 2
        elif option in ("-port", "--port") and index + 1 < len(argv):
            udp_port = _port(argv[index + 1], text_usage)
            index += 2
        elif option in ("-ip", "--ip", "-port", "--port"):
            raise SystemExit(text_usage)        # option without its value
        else:
            raise SystemExit(text_usage)        # this script takes no argument
    return device_ip, udp_port


def main():
    """Initialise the board: low voltage off and configured, high voltage off.

    High voltage (the hv register 0x0d and the monitor ADS1114): hv_power.init()

      1. puts the monitor window back to its default (the reset pair, so nothing
         is armed), sets the monitor ADC up (PGA +/-4.096 V, 128 samples/s,
         window comparator enabled, continuous conversion),
      2. engages the emergency stop, so the supply is off - the hv register
         resets with stop = 1, i.e. already shut down, but the stop is written
         anyway so the state never depends on the reset value, and the
         potentiometer comes up at a mid-scale wiper,
      3. drives the level to 0 V, so a later release_stop() cannot bring the
         output up at an old setpoint.

    LV power (the board lv register 0x0c and the tcal6416 enable pins):
    lv_power.init()

      4. switches stage 1 (the main power) off, configures the 16 enable pins as
         open-drain outputs holding every module off, and arms every stage-2
         over-current limit at its maximum (OC_LIMIT_MAX_A) in latched mode. The
         expander powers up with its pins as inputs, so nothing drives the
         module sub power before this, and the OFF value is loaded before the
         pins become outputs, so the whole low-voltage side is down when this
         returns,
      5. configures the NTC ADC and drops the latched alarms, reporting the ones
         that were pending. The latched module flags share one read-to-clear
         register (mod_sta_lch, 0x0a), so this is where the whole board's latches
         go - including the high-voltage one, which is why the HV init leaves
         them alone.

    Both inits also drop the interrupt of their own ADS1114 - the high-voltage
    monitor and the NTC ADC - because each runs a latching window comparator:
    its ALERT/RDY pin stays asserted until the Conversion register is read, so
    a latch left over from an earlier run is released there and the two
    converters report only what they see from now on.

    After INIT_DELAY_S, so the module rails have discharged, both states are
    printed. -ip and -port select another board than the default one."""
    device_ip, udp_port = parse_args(sys.argv)

    hv_pwr = hv_power(device_ip, udp_port, HV_BASE_ADDRESS)
    hv_pwr.init()                          # window default, monitor set up,
                                           # supply off, level 0 V

    lv_pwr = lv_power(device_ip, udp_port, LV_BASE_ADDRESS)
    lv_pwr.init()                          # stage 1 off, enables off, OC at MAX,
                                           # NTC set up, latches dropped

    time.sleep(INIT_DELAY_S)               # let the module rails discharge

    print("board initialised")
    lv_pwr.print_status()
    hv_pwr.print_status()


if __name__ == "__main__":
    main()
