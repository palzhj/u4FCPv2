#!/usr/bin/python
# This is hv_on.py file
# switch the high voltage of the board on
# author: zhj@ihep.ac.cn with deepseek's assist
# 2026-09-10 created
import os
import sys
import time

# allow running straight from a checkout ("python scripts/hv_on.py 300")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                os.pardir, "src"))

from u4FCPv2.board.hv_power import hv_power, HV_VOLTAGE_MAX  # noqa: E402

# default SiTCP target of the board, changed with -ip / -port
DEVICE_IP = "192.168.10.16"
UDP_PORT  = 4660

# FPGA I2C-core base address of the high-voltage devices
BASE_ADDRESS = 0x00020200

# wait after programming the level before reading the monitors, unit: s
HV_ON_DELAY_S = 1.0

# high voltage programmed when none is given on the command line, unit: V
HV_DEFAULT_V = 150.0

# automatic power off of the high voltage on over-current, 0/1 (bit 1 of the hv
# register 0x0d, see board.reg): 1 lets the board shut the supply down by
# itself when the over-current alarm comes, 0 leaves it running
HV_AUTO_OFF = 1

# level step of the ramp, unit: V. The pot quantizes every step to its nearest
# tap (HV_VOLTAGE_MAX / (POT_NUM_TAPS - 1), about 4.7 V), so a 5 V step moves one
# tap, at most two.
HV_VOLTAGE_STEP = 4.0

# how fast the level is raised, unit: V/s. The level goes up in steps of
# HV_VOLTAGE_STEP volts with step / rate seconds between them, so 0.83 s per
# 5 V step at the default (i.e. the ramp takes about voltage / rate seconds);
# 0 jumps straight to the setpoint.
HV_RAMP_RATE_V_S = 8.0

# level below which the ramp window has to be wide, unit: V. The charge
# accumulated in the supply makes the output lag the setpoint near 0 V, so the
# monitor window is HV_RAMP_KNEE_V + HV_VOLTAGE_STEP there and only
# 1.5 * HV_VOLTAGE_STEP above it, where the output follows the steps closely
# (see ramp_margin).
HV_RAMP_KNEE_V = 20.0


def ramp_margin(voltage):
    """Return the monitor window margin to use while the level is at `voltage`,
    in volts.

    The window follows the level being set (level -/+ the margin) and is
    rewritten at every step, so ALERT/RDY reports the output leaving the ramp by
    more than the margin. Up to HV_RAMP_KNEE_V the accumulated charge of the
    supply makes the output lag, so the window is HV_RAMP_KNEE_V +
    HV_VOLTAGE_STEP wide; above it 2 * HV_VOLTAGE_STEP is enough.

    The lower limit is only usable while the level is below the margin:
    Lo_thresh has to stay at or above LO_THRESH_RESET (0x8000, i.e. below 0 V),
    so above that the lower side is left at its reset value."""
    if voltage <= HV_RAMP_KNEE_V:
        return HV_RAMP_KNEE_V + HV_VOLTAGE_STEP
    return 2 * HV_VOLTAGE_STEP

USAGE = ("usage: %s [-ip ADDR] [-port PORT] [-ramp RATE] [voltage]\n"
         "  -ip ADDR   : board IP address (default %s)\n"
         "  -port PORT : board RBCP UDP port (default %d)\n"
         "  -ramp RATE : ramp-up rate in V/s (default %g V/s)\n"
         "  voltage    : high voltage setpoint, 0..%g V (default %g V)")


def usage(program = None):
    """Return the usage text, with the script name and the current defaults."""
    return USAGE % (program or os.path.basename(sys.argv[0]), DEVICE_IP,
                    UDP_PORT, HV_RAMP_RATE_V_S, HV_VOLTAGE_MAX, HV_DEFAULT_V)


def _port(text, text_usage):
    """Return the UDP port given on the command line."""
    try:
        port = int(text, 0)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0 < port < 65536):
        raise SystemExit(text_usage)
    return port


def _voltage(text, text_usage):
    """Return the high voltage setpoint given on the command line."""
    try:
        voltage = float(text)
    except ValueError:
        raise SystemExit(text_usage)
    if not (0.0 <= voltage <= HV_VOLTAGE_MAX):
        raise SystemExit(text_usage)
    return voltage


def _rate(text, text_usage):
    """Return the ramp-up rate in V/s given on the command line."""
    try:
        rate = float(text)
    except ValueError:
        raise SystemExit(text_usage)
    if rate < 0.0:
        raise SystemExit(text_usage)
    return rate


def parse_args(argv):
    """Return (device_ip, udp_port, voltage, rate) from the command line.

    -ip, -port and -ramp override the board target and the ramp-up rate; the
    optional positional argument is the high voltage setpoint, HV_DEFAULT_V when
    it is not given and HV_RAMP_RATE_V_S for the rate."""
    device_ip, udp_port, rest = DEVICE_IP, UDP_PORT, []
    rate = HV_RAMP_RATE_V_S
    text_usage = usage(os.path.basename(argv[0]))
    index = 1
    while index < len(argv):
        option = argv[index]
        if option in ("-h", "--help"):
            print(text_usage)
            raise SystemExit(0)
        if option in ("-ip", "--ip") and index + 1 < len(argv):
            device_ip = argv[index + 1]
            index += 2
        elif option in ("-port", "--port") and index + 1 < len(argv):
            udp_port = _port(argv[index + 1], text_usage)
            index += 2
        elif option in ("-ramp", "--ramp") and index + 1 < len(argv):
            rate = _rate(argv[index + 1], text_usage)
            index += 2
        elif option in ("-ip", "--ip", "-port", "--port", "-ramp", "--ramp"):
            raise SystemExit(text_usage)        # option without its value
        else:
            rest.append(option)
            index += 1
    if len(rest) > 1:
        raise SystemExit(text_usage)
    return (device_ip, udp_port,
            _voltage(rest[0], text_usage) if rest else HV_DEFAULT_V, rate)


def main():
    """Bring the high voltage to the wanted level and switch it on.

    The supply is off by default, and this script makes sure of it: the first
    thing it does is engage the emergency stop (the hv register 0x0d resets
    with stop = 1, i.e. already shut down, but the stop is written anyway so the
    state never depends on that, and the potentiometer comes up at a mid-scale
    wiper of about 300 V, so "off" has to be driven every time). The sequence is

      1. emergency_stop(): the high voltage is off, with the automatic power off
         on over-current programmed to HV_AUTO_OFF at the same time,
      2. set_voltage(0 V): the level is driven to 0 V while the supply is still
         stopped, so it cannot come up at an old setpoint,
      3. release_stop(): the high voltage is on, at 0 V,
      4. the level is ramped up to the setpoint given on the command line (or
         HV_DEFAULT_V) in steps of HV_VOLTAGE_STEP volts, with step / rate
         seconds between the steps, so the output rises at about -ramp volts per
         second (HV_RAMP_RATE_V_S when not given). Each step is quantized by the
         pot to its nearest tap, and the level set, the output read back from the
         monitor ADC and the live high-voltage over-current flag are printed as
         the ramp comes up; the monitor window is moved to the level set -/-
         ramp_margin() at the same time, wider up to HV_RAMP_KNEE_V because the
         accumulated charge makes the output lag there. A step that lands
         on the tap already set is skipped without a wait, and -ramp 0 jumps
         straight to the setpoint,
      5. after HV_ON_DELAY_S seconds the setpoint, the measured output and the
         live over-current alarm are printed.

    A high-voltage over-current alarm that is already active is reported. Use
    hv_power.emergency_stop() to shut the supply down again. -ip and -port
    select another board than the default one."""
    device_ip, udp_port, voltage, rate = parse_args(sys.argv)
    hv = hv_power(device_ip, udp_port, BASE_ADDRESS, shutdown = True,
                  auto_off = HV_AUTO_OFF)   # HV off, auto power off programmed
    hv.clear_monitor_int()            # release a latch left by a past run
    if hv.hv_alarm_latch():
        print("warning: the high-voltage over-current alarm is already active")
    hv.set_voltage(0)                   # start from 0 V, supply still stopped
    hv.release_stop()                   # high voltage ON
    level = HV_VOLTAGE_STEP             # ramp up in steps of HV_VOLTAGE_STEP V
    reached = 0.0
    while rate > 0.0 and level < voltage:
        value = hv.set_voltage(level)
        time.sleep(HV_VOLTAGE_STEP / rate)   # wait setup time
        if value > reached:             # the wiper moved, let the output follow
            print("ramp up: set %7.2f V  read %7.2f V  oc %s"
                  % (value, hv.read_voltage(),
                     "yes" if hv.hv_alarm() else "no"))
            margin = ramp_margin(value)     # window around the level set
            under = value - margin
            hv.write_thresholds(under if under < 0.0 else None, value + margin)
            reached = value
        level += HV_VOLTAGE_STEP
    value = hv.set_voltage(voltage)     # land exactly on the setpoint
    if rate > 0.0:
        time.sleep(HV_VOLTAGE_STEP / rate)   # wait setup time (-ramp 0: no wait)
    if value != reached:
        print("ramp up: set %7.2f V  read %7.2f V  oc %s"
              % (value, hv.read_voltage(),
                 "yes" if hv.hv_alarm() else "no"))
        margin = ramp_margin(value)
        under = value - margin
        hv.write_thresholds(under if under < 0.0 else None, value + margin)
    time.sleep(HV_ON_DELAY_S)           # let the supply settle
    hv.print_status()


if __name__ == "__main__":
    main()
