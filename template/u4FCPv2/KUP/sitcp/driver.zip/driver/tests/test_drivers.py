#!/usr/bin/env python3
# test_drivers.py - offline unit tests for the I2C device drivers (tca9548a,
# tcal6416, tca9554a, tmp4718, ads1114, ina745, tpl0401a_10).
# Runs without hardware: the bus class of each driver module is replaced by a
# stub bus.
#
# Usage:
#   python3 tests/test_drivers.py           # quiet run
#   python3 tests/test_drivers.py -v        # also enable DEBUG/DEBUG_LOW_LEVEL
import io
import importlib
import os
import sys
from contextlib import redirect_stdout

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.path.dirname(HERE), "src")
if SRC not in sys.path:                     # runnable from a checkout without
    sys.path.insert(0, SRC)                 # `pip install -e .`

# The device packages re-export their class at package level (e.g.
# `from u4FCPv2.devices import tca9548a` gives the class), so the submodule
# attribute of the same name is shadowed. Tests need the *module* objects
# (module-level DEBUG flags/constants), which importlib.import_module returns.
tca9548a_module = importlib.import_module("u4FCPv2.devices.tca9548a")
tcal6416_module = importlib.import_module("u4FCPv2.devices.tcal6416")
tca9554a_module = importlib.import_module("u4FCPv2.devices.tca9554a")
tmp4718_module  = importlib.import_module("u4FCPv2.devices.tmp4718")
ads1114_module  = importlib.import_module("u4FCPv2.devices.ads1114")
ina745_module   = importlib.import_module("u4FCPv2.devices.ina745")
tpl0401a_module = importlib.import_module("u4FCPv2.devices.tpl0401a_10")

ALL_DRIVERS = (tca9548a_module, tcal6416_module, tca9554a_module, tmp4718_module, ads1114_module,
               ina745_module, tpl0401a_module)


# ---------------------------------------------------------------------------
# Stub A: single-register device, used for the TCA9548A I2C switch.
# ---------------------------------------------------------------------------
class SingleRegBus(object):
    def __init__(self, device_ip="192.168.10.16", udp_port=4660,
                 base_address=0x00020000, i2c_addr=None,
                 clk_freq=125, i2c_freq=100):
        self.device_ip = device_ip
        self.udp_port = udp_port
        self.base_address = base_address
        self.i2c_addr = i2c_addr
        self.reg = 0x00          # TCA9548A control register
        self.log = []            # list of ("read",) / ("write", value)

    def read8(self, internal_addr_length=0, internal_addr=0):
        self.log.append(("read",))
        return self.reg

    def write8(self, value, internal_addr_length=0, internal_addr=0):
        self.log.append(("write", value & 0xFF))
        self.reg = value & 0xFF

    def readBytes(self, data, length_to_read):
        """Single-register device: pure read returns the one control byte."""
        self.log.append(("read",))
        return bytes([self.reg & 0xFF]) * length_to_read

    def writeBytes(self, data):
        value = data & 0xFF if isinstance(data, int) else data[0] & 0xFF
        self.log.append(("write", value))
        self.reg = value
        return value

    def writes(self):
        return [v for op, v in self.log if op == "write"]


# ---------------------------------------------------------------------------
# Stub B: register-map device with a command byte, used for the TCAL6416
# 16-bit I/O expander. Registers are addressed by the command byte.
# ---------------------------------------------------------------------------
class RegMapBus(object):
    DEFAULTS = {
        0x02: 0xFF, 0x03: 0xFF,   # Output Port 0/1, default all high
        0x06: 0xFF, 0x07: 0xFF,   # Configuration 0/1, default all inputs
        0x04: 0x00, 0x05: 0x00,   # Polarity inversion
        0x40: 0xFF, 0x41: 0xFF, 0x42: 0xFF, 0x43: 0xFF,  # drive strength
        0x44: 0x00, 0x45: 0x00,   # input latch
        0x46: 0x00, 0x47: 0x00,   # pull enable
        0x48: 0xFF, 0x49: 0xFF,   # pull select
        0x4A: 0xFF, 0x4B: 0xFF,   # interrupt mask
        0x4F: 0x00,               # output port config (push-pull)
    }

    def __init__(self, device_ip="192.168.10.16", udp_port=4660,
                 base_address=0x00020000, i2c_addr=None,
                 clk_freq=125, i2c_freq=100):
        self.device_ip = device_ip
        self.udp_port = udp_port
        self.base_address = base_address
        self.i2c_addr = i2c_addr
        self.regs = dict(self.DEFAULTS)  # writable register map
        self.log = []                    # ("read", reg) / ("write", reg, val)

    def read8(self, internal_addr_length=1, internal_addr=0):
        self.log.append(("read", internal_addr))
        return self.regs.get(internal_addr, 0x00)

    def write8(self, value, internal_addr_length=1, internal_addr=0):
        value = value & 0xFF
        self.log.append(("write", internal_addr, value))
        self.regs[internal_addr] = value
        return value

    def readBytes(self, data, length_to_read):
        """First data byte selects the register; all read bytes mirror it."""
        reg = data if isinstance(data, int) else data[0]
        self.log.append(("read", reg, length_to_read))
        value = self.regs.get(reg, 0x00)
        return bytes([value & 0xFF]) * length_to_read

    def writeBytes(self, data):
        data = [data] if isinstance(data, int) else list(data)
        reg, value = data[0], data[1] & 0xFF
        self.log.append(("write", reg, value))
        self.regs[reg] = value
        return value


_created = []


def _build(stub_cls, driver_cls, i2c_addr):
    """Point the driver module's bus class at stub_cls, build an instance on it,
    and return (driver, stub_bus).

    Each device module does `from ..bus.i2c import i2c`, so the name is bound in
    that module: the stub is installed there (not in u4FCPv2.bus.i2c)."""
    driver_mod = sys.modules[driver_cls.__module__]
    driver_mod.i2c = stub_cls
    _created[:] = []
    orig_init = stub_cls.__init__

    def capturing_init(self, *a, **k):
        orig_init(self, *a, **k)
        _created.append(self)

    stub_cls.__init__ = capturing_init
    sw = driver_cls("192.168.10.16", 4660, 0x00020000, i2c_addr)
    return sw, _created[-1]


def make_switch(i2c_addr=0x73):
    """TCA9548A instance on a single-register stub bus."""
    return _build(SingleRegBus, tca9548a_module.tca9548a, i2c_addr)


def make_expander(i2c_addr=0x20):
    """TCAL6416 instance on a register-map stub bus."""
    return _build(RegMapBus, tcal6416_module.tcal6416, i2c_addr)


def make_tca9554a(i2c_addr=0x38):
    """TCA9554A 8-bit I/O expander instance on a MemBus stub."""
    return _build(MemBus, tca9554a_module.tca9554a, i2c_addr)


# ---------------------------------------------------------------------------
# Stub C: generic register-map device holding integer values per register,
# used for the pointer-addressed drivers (tmp4718, ads1114, ina745,
# tpl0401a_10). readBytes()/writeBytes() transfer big-endian (MSB first),
# readBytes()/writeBytes() single bytes.
# ---------------------------------------------------------------------------
class MemBus(object):
    def __init__(self, device_ip="192.168.10.16", udp_port=4660,
                 base_address=0x00020000, i2c_addr=None,
                 clk_freq=125, i2c_freq=100):
        self.device_ip = device_ip
        self.udp_port = udp_port
        self.base_address = base_address
        self.i2c_addr = i2c_addr
        self.regs = {}
        self.log = []

    def _reg(self, reg, default=0x00):
        return self.regs.get(reg, default)

    def read8(self, internal_addr_length=1, internal_addr=0):
        self.log.append(("read", internal_addr))
        return self._reg(internal_addr) & 0xFF

    def write8(self, value, internal_addr_length=1, internal_addr=0):
        value = value & 0xFF
        self.log.append(("write", internal_addr, value))
        self.regs[internal_addr] = value
        return value

    def readBytes(self, data, length_to_read):
        reg = data if isinstance(data, int) else data[0]
        self.log.append(("read", reg, length_to_read))
        value = self._reg(reg, 0)
        out = []
        for i in range(length_to_read - 1, -1, -1):
            out.append((value >> (8 * i)) & 0xFF)
        return bytes(out)

    def writeBytes(self, data):
        data = [data] if isinstance(data, int) else list(data)
        reg = data[0]
        value = 0
        for b in data[1:]:
            value = (value << 8) | (b & 0xFF)
        self.log.append(("write", reg, value))
        self.regs[reg] = value
        return value


def make_temp_sensor(i2c_addr=0x4C):
    """TMP4718 instance on a MemBus stub."""
    return _build(MemBus, tmp4718_module.tmp4718, i2c_addr)


def make_adc(i2c_addr=0x48):
    """ADS1114 instance on a MemBus stub."""
    return _build(MemBus, ads1114_module.ads1114, i2c_addr)


def make_power_monitor(i2c_addr=0x40):
    """INA745 instance on a MemBus stub."""
    return _build(MemBus, ina745_module.ina745, i2c_addr)


def make_potentiometer(i2c_addr=0x2E):
    """TPL0401A-10 instance on a MemBus stub."""
    return _build(MemBus, tpl0401a_module.tpl0401a, i2c_addr)


def main():
    verbose = "-v" in sys.argv
    for mod in ALL_DRIVERS:
        mod.DEBUG = 1 if verbose else 0
        mod.DEBUG_LOW_LEVEL = 1 if verbose else 0

    passed = 0
    failed = 0

    def check(name, cond, detail=""):
        nonlocal passed, failed
        if cond:
            passed += 1
            print("PASS  %s" % name)
        else:
            failed += 1
            print("FAIL  %s  %s" % (name, detail))

    # ======================================================================
    # TCA9548A 8-channel I2C switch
    # ======================================================================
    # --- module constants / helpers -------------------------------------
    for n in range(8):
        check("tca: CH%d == 1<<%d" % (n, n),
              getattr(tca9548a_module, "CH%d" % n) == (1 << n))

    for addr7, addr8 in ((0x70, 0xE0), (0x73, 0xE6), (0x77, 0xEE)):
        check("tca: addr7_to_addr8(0x%02X) == 0x%02X" % (addr7, addr8),
              tca9548a_module.addr7_to_addr8(addr7) == addr8)

    # --- address normalization (address is always the 7-bit form) --------
    for arg, expect in ((0x70, 0xE0), (0x73, 0xE6), (0x77, 0xEE)):
        sw, bus = make_switch(i2c_addr=arg)
        check("tca: i2c_addr 0x%02X -> bus byte 0x%02X" % (arg, expect),
              sw.i2c_addr == expect and bus.i2c_addr == expect,
              "got 0x%02X" % sw.i2c_addr)
    try:
        make_switch(i2c_addr=0xE6)          # > 7-bit range not accepted
        check("tca: out-of-range i2c_addr raises", False)
    except ValueError:
        check("tca: out-of-range i2c_addr raises", True)

    # --- channel operations ---------------------------------------------
    sw, bus = make_switch()
    bus.reg = 0x00

    sw.select_channel(2)
    check("tca: select_channel(2) writes 0x04", bus.reg == 0x04,
          "reg=0x%02X" % bus.reg)

    sw.enable_all()
    check("tca: enable_all writes 0xFF", bus.reg == 0xFF,
          "reg=0x%02X" % bus.reg)

    sw.deselect_channel(3)                 # read-modify-write
    check("tca: deselect_channel(3) clears bit 3 only", bus.reg == 0xF7,
          "reg=0x%02X" % bus.reg)
    check("tca: deselect_channel does read+write",
          bus.log[-2:] == [("read",), ("write", 0xF7)],
          "log tail=%r" % bus.log[-2:])

    sw.select_channel(0)
    sw.disable_all()
    check("tca: disable_all writes 0x00", bus.reg == 0x00,
          "reg=0x%02X" % bus.reg)

    # --- is_channel_selected ---------------------------------------------
    sw, bus = make_switch()
    sw.select_channel(5)                    # reg = 0x20
    check("tca: is_channel_selected(5) is True",
          sw.is_channel_selected(5) is True)
    check("tca: is_channel_selected(0) is False",
          sw.is_channel_selected(0) is False)

    # --- RMW on non-zero initial state ------------------------------------
    sw, bus = make_switch()
    bus.reg = 0x55
    sw.enable_all()
    check("tca: enable_all from 0x55 -> 0xFF", bus.reg == 0xFF)
    sw.deselect_channel(0)
    check("tca: deselect_channel(0) from 0xFF -> 0xFE", bus.reg == 0xFE)

    # --- out-of-range channel raises -------------------------------------
    sw, bus = make_switch()
    for fn in (sw.select_channel, sw.deselect_channel, sw.is_channel_selected):
        try:
            fn(8)
            check("tca: out-of-range raises (%s)" % fn.__name__, False)
        except ValueError:
            check("tca: out-of-range raises (%s)" % fn.__name__, True)

    # --- debug prints toggle ---------------------------------------------
    sw, bus = make_switch()
    tca9548a_module.DEBUG = 1
    tca9548a_module.DEBUG_LOW_LEVEL = 1
    buf = io.StringIO()
    with redirect_stdout(buf):
        sw.select_channel(1)
    out = buf.getvalue()
    check("tca: DEBUG prints to stdout", "[tca9548a]" in out,
          "output=%r" % out[:80])
    tca9548a_module.DEBUG = 0
    tca9548a_module.DEBUG_LOW_LEVEL = 0

    # ======================================================================
    # TCAL6416 16-bit I/O expander
    # ======================================================================
    # --- module constants / helpers -------------------------------------
    check("tcal: REG_OUTPUT_PORT_0 == 0x02",
          tcal6416_module.REG_OUTPUT_PORT_0 == 0x02)
    check("tcal: REG_CONFIG_1 == 0x07", tcal6416_module.REG_CONFIG_1 == 0x07)
    check("tcal: addr7_to_addr8(0x20) == 0x40",
          tcal6416_module.addr7_to_addr8(0x20) == 0x40)

    # --- address normalization (address is always the 7-bit form) --------
    for arg, expect in ((0x20, 0x40),   # AD=L
                        (0x21, 0x42)):  # AD=H
        dev, bus = make_expander(i2c_addr=arg)
        check("tcal: i2c_addr 0x%02X -> bus byte 0x%02X" % (arg, expect),
              dev.i2c_addr == expect and bus.i2c_addr == expect,
              "got 0x%02X" % dev.i2c_addr)
    try:
        make_expander(i2c_addr=0x80)    # > 7-bit range not accepted
        check("tcal: out-of-range i2c_addr raises", False)
    except ValueError:
        check("tcal: out-of-range i2c_addr raises", True)

    # --- power-up defaults -----------------------------------------------
    dev, bus = make_expander()
    check("tcal: read_output(0) defaults 0xFF", dev.read_output(0) == 0xFF)
    check("tcal: read_config(1) defaults 0xFF (inputs)",
          dev.read_config(1) == 0xFF)
    check("tcal: read_polarity(0) defaults 0x00",
          dev.read_polarity(0) == 0x00)

    # --- output writes hit the right command byte ------------------------
    dev, bus = make_expander()
    dev.write_output(0, 0xAA)                       # -> register 0x02
    dev.write_output(1, 0x55)                       # -> register 0x03
    check("tcal: write_output(0,0xAA) -> reg 0x02", bus.regs[0x02] == 0xAA)
    check("tcal: write_output(1,0x55) -> reg 0x03", bus.regs[0x03] == 0x55)
    check("tcal: output writes use command bytes 0x02/0x03",
          bus.log[-2:] == [("write", 0x02, 0xAA), ("write", 0x03, 0x55)],
          "log tail=%r" % bus.log[-2:])

    # --- input reads ------------------------------------------------------
    dev, bus = make_expander()
    bus.regs[0x00] = 0x0F                           # port-0 input pins
    bus.regs[0x01] = 0x30                           # port-1 input pins
    check("tcal: read_input(0) == 0x0F", dev.read_input(0) == 0x0F)
    check("tcal: read_input(1) == 0x30", dev.read_input(1) == 0x30)

    # --- configuration / pin direction -----------------------------------
    dev, bus = make_expander()
    dev.write_config(0, 0x00)                       # all port-0 pins output
    check("tcal: write_config(0,0x00) -> reg 0x06", bus.regs[0x06] == 0x00)

    dev, bus = make_expander()
    dev.set_pin_direction(9, is_input=False)        # P1.1 -> output
    check("tcal: pin 9 -> output clears config1 bit1", bus.regs[0x07] == 0xFD,
          "reg=0x%02X" % bus.regs[0x07])
    dev.set_pin_direction(9, is_input=True)         # back to input
    check("tcal: pin 9 -> input restores config1", bus.regs[0x07] == 0xFF)

    dev, bus = make_expander()
    dev.set_pin_direction(3, is_input=False)        # P0.3 -> output
    check("tcal: pin 3 -> output clears config0 bit3", bus.regs[0x06] == 0xF7)

    # --- output port configuration (0x4F, open-drain) --------------------
    dev, bus = make_expander()
    dev.write_output_config(1, open_drain=True)     # ODEN1 = bit1
    check("tcal: ODEN1 set in reg 0x4F", bus.regs[0x4F] == 0x02,
          "reg=0x%02X" % bus.regs[0x4F])
    dev.write_output_config(0, open_drain=True)     # ODEN0 = bit0
    check("tcal: ODEN0 set in reg 0x4F", bus.regs[0x4F] == 0x03)
    dev.write_output_config(0, open_drain=False)    # back to push-pull
    check("tcal: ODEN0 cleared in reg 0x4F", bus.regs[0x4F] == 0x02)

    # --- interrupt mask (default 0xFF: all masked) -----------------------
    dev, bus = make_expander()
    check("tcal: interrupt mask(0) defaults 0xFF", dev.read_interrupt_mask(0) == 0xFF)
    dev.enable_interrupt(0, 0x05)                   # enable P0.0, P0.2
    check("tcal: enable_interrupt(0,0x05) clears mask bits",
          bus.regs[0x4A] == 0xFA, "reg=0x%02X" % bus.regs[0x4A])
    dev.disable_interrupt(0, 0x01)                  # re-mask P0.0
    check("tcal: disable_interrupt(0,0x01) sets mask bit",
          bus.regs[0x4A] == 0xFB, "reg=0x%02X" % bus.regs[0x4A])
    dev.enable_interrupt(1, 0x80)                   # enable P1.7
    check("tcal: interrupt port-1 mask updated",
          bus.regs[0x4B] == 0x7F, "reg=0x%02X" % bus.regs[0x4B])

    dev, bus = make_expander()
    dev.set_pin_interrupt(9, enabled=True)          # P1.1 -> unmasked
    check("tcal: set_pin_interrupt(9,True) clears mask1 bit1",
          bus.regs[0x4B] == 0xFD, "reg=0x%02X" % bus.regs[0x4B])
    dev.set_pin_interrupt(9, enabled=False)         # P1.1 -> masked again
    check("tcal: set_pin_interrupt(9,False) sets mask1 bit1",
          bus.regs[0x4B] == 0xFF)

    dev, bus = make_expander()
    bus.regs[0x4C] = 0x08                           # P0.3 is interrupt source
    check("tcal: read_interrupt_status(0) == 0x08", dev.read_interrupt_status(0) == 0x08)

    # --- pull-up/pull-down enable/select ---------------------------------
    dev, bus = make_expander()
    check("tcal: pull_enable(0) defaults 0x00", dev.read_pull_enable(0) == 0x00)
    check("tcal: pull_select(1) defaults 0xFF (pull-up)",
          dev.read_pull_select(1) == 0xFF)
    dev.enable_pull(0, 0x03)                        # P0.0, P0.1 resistors on
    check("tcal: enable_pull(0,0x03) sets reg 0x46",
          bus.regs[0x46] == 0x03, "reg=0x%02X" % bus.regs[0x46])
    dev.disable_pull(0, 0x02)                       # P0.1 resistor off
    check("tcal: disable_pull(0,0x02) clears bit1",
          bus.regs[0x46] == 0x01, "reg=0x%02X" % bus.regs[0x46])
    dev.write_pull_select(0, 0x0F)                  # P0.0..P0.3 pull-down
    check("tcal: write_pull_select(0,0x0F) stored",
          bus.regs[0x48] == 0x0F)

    dev, bus = make_expander()
    dev.set_pin_pull(9, enabled=True, pull_up=False)  # P1.1 pull-down
    check("tcal: set_pin_pull(9,on,pull-down) -> en bit1 + sel cleared",
          bus.regs[0x47] == 0x02 and bus.regs[0x49] == 0xFD,
          "en=0x%02X sel=0x%02X" % (bus.regs[0x47], bus.regs[0x49]))
    dev.set_pin_pull(9, enabled=False)              # P1.1 resistor off
    check("tcal: set_pin_pull(9,off) clears en bit1",
          bus.regs[0x47] == 0x00)

    # --- drive strength (2 bits/pin, regs 0x40..0x43) --------------------
    dev, bus = make_expander()
    check("tcal: drive strength defaults to 1x (reg 0x40..0x43 = 0xFF)",
          all(bus.regs[r] == 0xFF for r in (0x40, 0x41, 0x42, 0x43)))
    check("tcal: get_drive_strength(3) default == 3 (1x)",
          dev.get_drive_strength(3) == 3)
    dev.set_drive_strength(3, 0)            # P03 0.25x: reg 0x40 bits[7:6]=0
    check("tcal: set_drive_strength(3,0) clears reg0x40 bits7:6",
          bus.regs[0x40] == 0x3F, "reg=0x%02X" % bus.regs[0x40])
    check("tcal: get_drive_strength(3) == 0", dev.get_drive_strength(3) == 0)
    dev.set_drive_strength(5, 1)            # P05 0.5x: reg 0x41 bits[3:2]
    check("tcal: set_drive_strength(5,1) -> reg0x41 bits[3:2]=01",
          bus.regs[0x41] == 0xF7, "reg=0x%02X" % bus.regs[0x41])
    check("tcal: get_drive_strength(5) == 1", dev.get_drive_strength(5) == 1)
    check("tcal: get_drive_strength(4) untouched == 3",
          dev.get_drive_strength(4) == 3)
    dev.write_drive_strength(0x43, 0x00)    # P17..P14 all 0.25x
    check("tcal: write_drive_strength(0x43,0x00) stored",
          bus.regs[0x43] == 0x00)
    check("tcal: get_drive_strength(15) == 0", dev.get_drive_strength(15) == 0)
    try:
        dev.set_drive_strength(16, 1)
        check("tcal: out-of-range drive pin raises", False)
    except ValueError:
        check("tcal: out-of-range drive pin raises", True)

    # --- input latch (0x44/0x45) ------------------------------------------
    dev, bus = make_expander()
    check("tcal: input_latch(0) defaults 0x00", dev.read_input_latch(0) == 0x00)
    dev.enable_input_latch(1, 0x06)         # latch P1.1, P1.2
    check("tcal: enable_input_latch(1,0x06) -> reg 0x45",
          bus.regs[0x45] == 0x06, "reg=0x%02X" % bus.regs[0x45])
    dev.disable_input_latch(1, 0x02)        # unlatch P1.1
    check("tcal: disable_input_latch(1,0x02) clears bit1",
          bus.regs[0x45] == 0x04, "reg=0x%02X" % bus.regs[0x45])
    dev.write_input_latch(0, 0xFF)          # latch whole port 0
    check("tcal: write_input_latch(0,0xFF) stored", bus.regs[0x44] == 0xFF)

    dev, bus = make_expander()
    dev.set_pin_input_latch(8, enabled=True)  # latch P1.0
    check("tcal: set_pin_input_latch(8,True) sets reg0x45 bit0",
          bus.regs[0x45] == 0x01, "reg=0x%02X" % bus.regs[0x45])
    dev.set_pin_input_latch(8, enabled=False)
    check("tcal: set_pin_input_latch(8,False) clears bit0",
          bus.regs[0x45] == 0x00)
    try:
        dev.set_pin_input_latch(16, enabled=True)
        check("tcal: out-of-range latch pin raises", False)
    except ValueError:
        check("tcal: out-of-range latch pin raises", True)

    # --- out-of-range port/pin raises ------------------------------------
    dev, bus = make_expander()
    try:
        dev.write_output(2, 0x00)
        check("tcal: out-of-range port raises (write_output)", False)
    except ValueError:
        check("tcal: out-of-range port raises (write_output)", True)
    try:
        dev.write_output_config(2, open_drain=True)
        check("tcal: out-of-range port raises (output_config)", False)
    except ValueError:
        check("tcal: out-of-range port raises (output_config)", True)
    try:
        dev.set_pin_direction(16, is_input=True)
        check("tcal: out-of-range pin raises", False)
    except ValueError:
        check("tcal: out-of-range pin raises", True)

    # --- debug prints toggle ---------------------------------------------
    dev, bus = make_expander()
    tcal6416_module.DEBUG = 1
    buf = io.StringIO()
    with redirect_stdout(buf):
        dev.write_output(0, 0x01)
    out = buf.getvalue()
    check("tcal: DEBUG prints to stdout", "[tcal6416]" in out,
          "output=%r" % out[:80])
    tcal6416_module.DEBUG = 0

    # ======================================================================
    # TCA9554A 8-bit I/O expander (address base 0x38..0x3F)
    # ======================================================================
    # --- addressing -------------------------------------------------------
    for arg, expect in ((0x38, 0x70), (0x3F, 0x7E)):
        dev, bus = make_tca9554a(i2c_addr=arg)
        check("t9554a: i2c_addr 0x%02X -> bus byte 0x%02X" % (arg, expect),
              dev.i2c_addr == expect and bus.i2c_addr == expect,
              "got 0x%02X" % dev.i2c_addr)
    try:
        make_tca9554a(i2c_addr=0x80)    # > 7-bit range not accepted
        check("t9554a: out-of-range i2c_addr raises", False)
    except ValueError:
        check("t9554a: out-of-range i2c_addr raises", True)

    # --- register behavior (same register set as TCA9554) ------------------
    dev, bus = make_tca9554a()
    bus.regs[0x01] = 0xFF
    bus.regs[0x03] = 0xFF
    check("t9554a: output default 0xFF", dev.read_output() == 0xFF)
    check("t9554a: config default 0xFF (inputs)", dev.read_config() == 0xFF)

    dev.write_output(0xAA)
    check("t9554a: write_output(0xAA) -> reg 0x01", bus.regs[0x01] == 0xAA)
    bus.regs[0x00] = 0x5A
    check("t9554a: read_input -> 0x5A", dev.read_input() == 0x5A)
    check("t9554a: read_pin(4) == 1", dev.read_pin(4) == 1)

    dev.write_polarity(0x55)
    check("t9554a: write_polarity(0x55) -> reg 0x02", bus.regs[0x02] == 0x55)

    dev, bus = make_tca9554a()
    bus.regs[0x03] = 0xFF
    dev.set_pin_direction(3, is_input=False)
    check("t9554a: pin3 -> output clears config bit3", bus.regs[0x03] == 0xF7)
    dev.set_pin_direction(3, is_input=True)
    check("t9554a: pin3 -> input restores config", bus.regs[0x03] == 0xFF)

    # ======================================================================
    # TMP4718 remote/local temperature sensor
    # ======================================================================
    # --- addressing -------------------------------------------------------
    for arg, expect in ((0x4C, 0x98), (0x4D, 0x9A)):
        dev, bus = make_temp_sensor(i2c_addr=arg)
        check("tmp: i2c_addr 0x%02X -> bus byte 0x%02X" % (arg, expect),
              dev.i2c_addr == expect and bus.i2c_addr == expect,
              "got 0x%02X" % dev.i2c_addr)
    try:
        make_temp_sensor(i2c_addr=0x98)     # > 7-bit range not accepted
        check("tmp: out-of-range i2c_addr raises", False)
    except ValueError:
        check("tmp: out-of-range i2c_addr raises", True)

    # --- data format (datasheet Table 8-2 / 8-3) --------------------------
    dev, bus = make_temp_sensor()
    bus.regs[0x00] = 0x19
    check("tmp: local 0x19 -> 25.0 C", dev.read_local_temp() == 25.0)
    bus.regs[0x00] = 0xE6
    check("tmp: local 0xE6 -> -26.0 C", dev.read_local_temp() == -26.0)

    bus.regs[0x01] = 0x19; bus.regs[0x10] = 0xC0
    check("tmp: remote 0x19/0xC0 -> 25.75 C",
          abs(dev.read_remote_temp() - 25.75) < 1e-9)
    bus.regs[0x01] = 0xE6; bus.regs[0x10] = 0x40
    check("tmp: remote 0xE6/0x40 -> -25.75 C",
          abs(dev.read_remote_temp() - (-25.75)) < 1e-9)

    bus.regs[0x02] = 0x04                    # remote disconnected flag
    check("tmp: remote returns None when disconnected",
          dev.read_remote_temp() is None)
    bus.regs[0x02] = 0x00

    # --- limits -----------------------------------------------------------
    dev, bus = make_temp_sensor()
    dev.write_local_high_limit(70.0)
    check("tmp: local high limit 70 C -> 0x46", bus.regs[0x05] == 0x46)
    dev.write_remote_high_limit(25.75)
    check("tmp: remote high limit -> msb/lsb 0x19/0xC0",
          bus.regs[0x07] == 0x19 and bus.regs[0x13] == 0xC0)
    dev.write_remote_low_limit(-40.0)
    check("tmp: remote low limit -40 C -> msb 0xD8", bus.regs[0x08] == 0xD8)
    check("tmp: read remote low limit -40.0", dev.read_remote_low_limit() == -40.0)

    # --- config / conv period / ids ---------------------------------------
    dev, bus = make_temp_sensor()
    bus.regs[0x04] = 0x08                    # power-up default
    check("tmp: conv period default 8", dev.read_conv_period() == 8)
    dev.write_conv_period(4)
    check("tmp: write_conv_period(4) stored", bus.regs[0x04] == 0x04)
    dev.set_shutdown(True)
    check("tmp: set_shutdown sets config bit6", bus.regs[0x03] & 0x40 != 0)
    bus.regs[0xFD] = 0x50
    check("tmp: chip id 0x50", dev.read_chip_id() == 0x50)
    bus.regs[0xFE] = 0x60
    check("tmp: vendor id 0x60", dev.read_vendor_id() == 0x60)

    # ======================================================================
    # ADS1114 16-bit ADC
    # ======================================================================
    # --- addressing -------------------------------------------------------
    for arg, expect in ((0x48, 0x90), (0x4B, 0x96)):
        dev, bus = make_adc(i2c_addr=arg)
        check("ads: i2c_addr 0x%02X -> bus byte 0x%02X" % (arg, expect),
              dev.i2c_addr == expect and bus.i2c_addr == expect,
              "got 0x%02X" % dev.i2c_addr)
    try:
        make_adc(i2c_addr=0x90)             # > 7-bit range not accepted
        check("ads: out-of-range i2c_addr raises", False)
    except ValueError:
        check("ads: out-of-range i2c_addr raises", True)

    # --- conversion scaling (Table 7-1) ------------------------------------
    dev, bus = make_adc()
    bus.regs[0x01] = 0x8583                  # default config: PGA ±2.048V
    bus.regs[0x00] = 0x7FFF
    check("ads: raw 0x7FFF at default PGA(2.048) -> ~2.04794 V",
          abs(dev.read_voltage() - 32767 * 2.048 / 32768) < 1e-9)
    bus.regs[0x00] = 0x8000
    check("ads: raw 0x8000 -> -2.048 V",
          abs(dev.read_voltage(pga=2) - (-2.048)) < 1e-9)

    # --- config field handling ---------------------------------------------
    dev, bus = make_adc()
    bus.regs[0x01] = 0x8583                  # reset value
    fields = dev.read_config_fields()
    check("ads: config 0x8583 -> pga 2, 128sps, single-shot",
          fields["pga"] == 2 and fields["data_rate"] == 4 and
          fields["mode"] == 1)
    dev.set_pga(5)                           # ±0.256V, code 5 -> bits << 9
    check("ads: set_pga(5) keeps other config bits",
          (bus.regs[0x01] & 0x0E00) == (5 << 9))
    dev.set_data_rate(7)                     # 860 SPS
    check("ads: set_data_rate(7) -> DR bits 111",
          (bus.regs[0x01] & 0x00E0) == 0x00E0)

    dev.set_mode(single_shot=True)
    dev.start_conversion()
    check("ads: start_conversion sets OS bit", bus.regs[0x01] & 0x8000 != 0)

    # --- thresholds --------------------------------------------------------
    dev, bus = make_adc()
    dev.write_lo_thresh(0x8000)
    dev.write_hi_thresh(0x7FFF)
    check("ads: thresholds stored 0x8000/0x7FFF",
          bus.regs[0x02] == 0x8000 and bus.regs[0x03] == 0x7FFF)
    dev.set_comparator(False)
    check("ads: disable comparator -> COMP_QUE 11",
          (bus.regs[0x01] & 0x0003) == 0x0003)

    # ======================================================================
    # INA745 power monitor
    # ======================================================================
    # --- addressing -------------------------------------------------------
    dev, bus = make_power_monitor(i2c_addr=0x40)
    check("ina: i2c_addr 0x40 -> bus byte 0x80", dev.i2c_addr == 0x80)
    dev, bus = make_power_monitor(i2c_addr=0x4F)
    check("ina: i2c_addr 0x4F -> bus byte 0x9E", dev.i2c_addr == 0x9E)

    # --- physical unit scaling --------------------------------------------
    dev, bus = make_power_monitor()
    bus.regs[0x05] = 0x14A0
    check("ina: VBUS 0x14A0 -> 16.5 V", abs(dev.read_bus_voltage() - 16.5) < 1e-9)
    bus.regs[0x06] = 0x0280
    check("ina: DIETEMP 0x0280 -> 5.0 C", abs(dev.read_die_temp() - 5.0) < 1e-9)
    bus.regs[0x06] = 0xFF80
    check("ina: DIETEMP 0xFF80 -> -1.0 C", abs(dev.read_die_temp() + 1.0) < 1e-9)
    bus.regs[0x07] = 0x0A8C
    check("ina: CURRENT 0x0A8C -> 3.24 A", abs(dev.read_current() - 3.24) < 1e-9)
    bus.regs[0x08] = 0x0F4240                # 1,000,000 * 240uW = 240 W
    check("ina: POWER -> 240 W", abs(dev.read_power() - 240.0) < 1e-6)
    bus.regs[0x09] = 10
    check("ina: ENERGY 10 -> 0.0384 J", abs(dev.read_energy() - 0.0384) < 1e-9)
    bus.regs[0x0A] = 10
    check("ina: CHARGE 10 -> 0.00075 C", abs(dev.read_charge() - 0.00075) < 1e-12)
    bus.regs[0x3E] = 0x5449
    check("ina: manufacturer id 'TI'", dev.read_manufacturer_id() == "TI")

    # --- threshold codec ----------------------------------------------------
    dev, bus = make_power_monitor()
    dev.write_col(-100)
    check("ina: COL -100 stored as 0xFF9C", bus.regs[0x0C] == 0xFF9C)
    dev.write_temp_limit(85.0)
    check("ina: temp limit 85 C -> 0x2A80", bus.regs[0x10] == 0x2A80)
    dev.write_temp_limit(-10.0)
    check("ina: temp limit -10 C -> 0xFB00", bus.regs[0x10] == 0xFB00)
    dev.write_pwr_limit(240.0)
    check("ina: pwr limit 240 W -> 0x0F42", bus.regs[0x11] == 0x0F42)

    # ======================================================================
    # TPL0401A-10 digital potentiometer
    # ======================================================================
    # --- addressing -------------------------------------------------------
    for arg, expect in ((0x2E, 0x5C), (0x2F, 0x5E)):
        dev, bus = make_potentiometer(i2c_addr=arg)
        check("tpl: i2c_addr 0x%02X -> bus byte 0x%02X" % (arg, expect),
              dev.i2c_addr == expect and bus.i2c_addr == expect,
              "got 0x%02X" % dev.i2c_addr)
    try:
        make_potentiometer(i2c_addr=0x80)   # > 7-bit range not accepted
        check("tpl: out-of-range i2c_addr raises", False)
    except ValueError:
        check("tpl: out-of-range i2c_addr raises", True)

    # --- wiper register -----------------------------------------------------
    dev, bus = make_potentiometer()
    bus.regs[0x00] = 0x40                    # power-up default mid-scale
    check("tpl: default wiper 64", dev.read_wiper() == 64)
    check("tpl: default resistance ~5039.4 ohm",
          abs(dev.read_resistance() - 64 * 10000 / 127) < 1e-6)
    dev.write_wiper(127)
    check("tpl: write_wiper(127) -> stored 0x7F", bus.regs[0x00] == 0x7F)
    dev.write_resistance(0)
    check("tpl: write_resistance(0) -> position 0", bus.regs[0x00] == 0x00)
    dev.write_resistance(10000)
    check("tpl: write_resistance(10k) -> position 127", bus.regs[0x00] == 0x7F)
    try:
        dev.write_wiper(128)
        check("tpl: out-of-range wiper raises", False)
    except ValueError:
        check("tpl: out-of-range wiper raises", True)

    print("\n%d passed, %d failed" % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
