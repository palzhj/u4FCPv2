# pytest support for the offline driver tests.
#
# The test suite (tests/test_drivers.py) is runnable on its own:
#     python3 tests/test_drivers.py
# and also works when the package is installed (`pip install -e .`).
#
# This file only makes the src/ layout importable for a bare checkout, so a
# future pytest run (`pytest tests/`) collects without an install step.
import os
import sys

SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "src")
if SRC not in sys.path:
    sys.path.insert(0, SRC)

# The stub transport/bus classes used instead of real hardware live in
# test_drivers.py; they need no fixtures because each driver module's bus class
# is replaced by the module itself (see _build()).
